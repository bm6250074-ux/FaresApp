package com.fareshelmy.auraglass.ui

import android.net.Uri
import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.compose.foundation.layout.Box
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.data.Store
import com.fareshelmy.auraglass.util.Auth
import com.fareshelmy.auraglass.util.AuthResult
import com.fareshelmy.auraglass.util.findActivity
import kotlinx.coroutines.launch

@Composable
fun AuraRoot() {
    if (!Store.onboardingDone || Store.showIntro) {
        // The approved start screen: rendered in its original (frozen) environment.
        LegacyDarkTheme { OnboardingScreen(onDone = { Store.finishOnboarding() }) }
    } else {
        AuraSurface {
            if (Auth.idToken == null) SignInGate() else MainScaffold()
        }
    }
}

/**
 * Mandatory sign-in screen (shown before the app can be used): [Create account] or [Sign in to an existing account].
 * Signing in with a Google account that was never registered asks "This account is not registered. Go to create account?".
 */
@Composable
fun SignInGate() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<Int?>(null) }
    var askRegister by remember { mutableStateOf(false) }

    fun handle(r: AuthResult) {
        busy = false
        when (r) {
            AuthResult.OK, AuthResult.CANCELLED -> message = null
            AuthResult.NOT_REGISTERED -> { message = null; askRegister = true }
            AuthResult.NO_ACCOUNT -> message = R.string.gate_no_account
            AuthResult.NETWORK -> message = R.string.gate_no_network
            AuthResult.NOT_CONFIGURED -> message = R.string.gate_not_configured
            AuthResult.ERROR -> message = R.string.signin_failed
        }
    }
    fun run(register: Boolean) {
        val act = ctx.findActivity() ?: return
        busy = true; message = null
        scope.launch { handle(Auth.enter(act, register = register)) }
    }

    // Returning users: silent sign-in with the account this app already used (no picker). Never creates an account.
    LaunchedEffect(Unit) {
        val act = ctx.findActivity()
        if (!Auth.configured) { busy = false; message = R.string.gate_not_configured }
        else if (act != null) {
            val r = Auth.enter(act, register = false, silent = true)
            busy = false
            if (r == AuthResult.NETWORK) message = R.string.gate_no_network
        } else busy = false
    }

    Column(
        Modifier.fillMaxSize().background(Pal.bg).padding(horizontal = 28.dp, vertical = 32.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(painterResource(R.drawable.aura_identity), null, Modifier.size(120.dp).clip(RoundedCornerShape(28.dp)))
        Text("Aura Glass", fontSize = 28.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = Modifier.padding(top = 18.dp))
        Text(stringResource(R.string.signin_title), fontSize = 18.sp, modifier = Modifier.padding(top = 6.dp), textAlign = TextAlign.Center)
        Text(stringResource(R.string.gate_body), modifier = Modifier.padding(top = 10.dp, bottom = 26.dp), textAlign = TextAlign.Center, color = Pal.muted, fontSize = 14.sp, lineHeight = 20.sp)
        message?.let { Text(stringResource(it), color = Pal.error, textAlign = TextAlign.Center, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(bottom = 14.dp)) }
        if (busy) androidx.compose.material3.CircularProgressIndicator(Modifier.padding(bottom = 16.dp).size(28.dp), strokeWidth = 3.dp)
        Button(enabled = !busy, onClick = { run(register = true) }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
            Text(stringResource(R.string.gate_create), fontSize = 16.sp)
        }
        androidx.compose.material3.OutlinedButton(
            enabled = !busy, onClick = { run(register = false) },
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp).height(54.dp),
        ) { Text(stringResource(R.string.gate_login), fontSize = 16.sp, textAlign = TextAlign.Center) }
    }

    if (askRegister) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { askRegister = false; Auth.discardPending() },
            text = { Text(stringResource(R.string.gate_not_registered)) },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    askRegister = false; busy = true; message = null
                    scope.launch { handle(Auth.registerPending()) }
                }) { Text(stringResource(R.string.gate_go_create)) }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { askRegister = false; Auth.discardPending() }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }
}

private fun tabFor(route: String?): String = when {
    route == null -> "home"
    route == "home" -> "home"
    route == "search" || route.startsWith("results") -> "search"
    route == "library" || route == "editor" -> "library"
    route == "profile" || route == "about" || route == "owner" -> "profile"
    route in setOf("studio", "clocks", "creator", "depth", "islamic", "widgets", "glass") -> "studio"
    else -> "home"
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MainScaffold() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val showBar = route != "detail" && route != "search" && route != "editor"
    val imeVisible = WindowInsets.isImeVisible
    val barVisible = showBar && !imeVisible
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val inset = if (barVisible) 92.dp + navBottom else 0.dp
    val backdrop = rememberGraphicsLayer()
    val dur = animMs(240)
    val useBackdrop = Store.liquid.on && Build.VERSION.SDK_INT >= 31

    CompositionLocalProvider(LocalBarInset provides inset) {
        Box(Modifier.fillMaxSize().background(Pal.bg)) {
          Box(Modifier.fillMaxSize().then(if (useBackdrop) Modifier.backdropSource(backdrop) else Modifier), contentAlignment = Alignment.TopCenter) {
            AppBackground()
            NavHost(
                nav, startDestination = "home",
                modifier = Modifier.widthIn(max = 960.dp).fillMaxSize(),
                enterTransition = {
                    when (Store.liquid.transition) {
                        1 -> slideInHorizontally(tween(dur)) { it / 5 } + fadeIn(tween(dur))
                        2 -> EnterTransition.None
                        else -> fadeIn(tween(dur)) + scaleIn(initialScale = 0.97f, animationSpec = tween(dur))
                    }
                },
                exitTransition = { if (Store.liquid.transition == 2) ExitTransition.None else fadeOut(tween(dur / 2)) },
                popEnterTransition = { if (Store.liquid.transition == 2) EnterTransition.None else fadeIn(tween(dur)) },
                popExitTransition = {
                    when (Store.liquid.transition) {
                        1 -> slideOutHorizontally(tween(dur)) { it / 5 } + fadeOut(tween(dur))
                        2 -> ExitTransition.None
                        else -> fadeOut(tween(dur)) + scaleOut(targetScale = 0.97f, animationSpec = tween(dur))
                    }
                },
            ) {
                composable("home") { HomeScreen(nav) }
                composable("search") { SearchScreen(nav) }
                composable("results/{q}", arguments = listOf(navArgument("q") { type = NavType.StringType })) {
                    ResultsScreen(nav, it.arguments?.getString("q").orEmpty())
                }
                composable("detail") { DetailScreen(nav) }
                composable("library") { LibraryScreen(nav) }
                composable("studio") { StudioScreen(nav) }
                composable("clocks") { ClocksScreen(nav) }
                composable("creator") { ClockCreatorScreen(nav) }
                composable("depth") { DepthScreen(nav) }
                composable("islamic") { IslamicScreen(nav) }
                composable("widgets") { WidgetStudioScreen(nav) }
                composable("glass") { CustomizeScreen(nav) }
                composable("profile") { ProfileScreen(nav) }
                composable("about") { AboutScreen(nav) }
                composable("owner") { OwnerScreen(nav) }
                composable("editor") { ImportEditorScreen(nav) }
            }
          }
            AnimatedVisibility(
                visible = barVisible,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = fadeIn(tween(dur)) + slideInVertically(tween(dur)) { it / 2 },
                exit = fadeOut(tween(dur)) + slideOutVertically(tween(dur)) { it / 2 },
            ) {
                GlassBar(
                    selected = tabFor(route),
                    backdrop = if (useBackdrop) backdrop else null,
                    onSelect = { r ->
                        nav.navigate(r) {
                            popUpTo("home") { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                )
            }
        }
    }
}

fun resultsRoute(q: String) = "results/${Uri.encode(q)}"
