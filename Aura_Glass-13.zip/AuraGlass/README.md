# Aura Glass v1.1.0 Beta

Kotlin + Jetpack Compose, minSdk 26, package `com.fareshelmy.auraglass`. Build with GitHub Actions (`.github/workflows/build.yml`);
the run **Summary** lists every Kotlin error. Never tested on a device by its author.

## Implemented
- Start screen untouched. Light/Dark/System, Liquid Glass ON/OFF, Aura Studio (theme, palettes, background, glass, fonts, layout, nav bar, animations, presets).
- Home: two-column masonry (varied heights, no titles). Floating glass bar with Search in the centre (equal slots, RTL/LTR safe, real backdrop blur on Android 12+).
- Search: Arabic/English query understanding + synonyms, results filtered by real title/category/description match and ranked by relevance (no unrelated filler),
  filters All/Images/Wallpapers, suggestions, history, saved searches, built-in category matches, pagination, error/empty states.
- Wallpapers: 132 built-in originals (11 categories) + Wikimedia Commons / Openverse (licence + author shown). Favorites, recents, downloads, offline copies,
  **personal collections**, imported photos, size editor (ratios, custom W×H, zoom, pan, Fit/Fill, rotation, no silent upscaling), "match app colours to wallpaper".
- Clocks: 35 designs + Clock Creator (free-form elements, saved designs) + preview on built-in wallpapers or your own photo + pixel-exact save / set-as-wallpaper
  (still image) + match colours to wallpaper. Depth Studio: on-device ML Kit subject segmentation (Google Play services) or your PNG cut-out, layers + parallax.
- Widgets: 20 real widget types (Islamic: Hijri, Gregorian, prayer + countdown, prayer list, verse, dua, tasbih, Islamic clock; General: digital/analog clock,
  weather (Open-Meteo, free), forecast, battery, big date, weekday, monthly calendar, custom text, notes, photo, gallery), 5 layouts each, exact in-app previews,
  colour/background/size/transparency.
- Mandatory Google Sign-In (Credential Manager) before the app can be used: Create account / Sign in to an existing account (an unregistered account gets "not registered, go to create account?"). Accounts are stored in a D1 database on the backend; the **first account to register becomes the owner** (decided once by the database, never changed, never sent by the app). Each new account gets a welcome email through Gmail (the owner gets the owner version); the owner also gets a short email with the new account's NAME only whenever someone new registers. Owner Settings (developer options: registered accounts, email test, source selection) are hidden from members and enforced on the server. About = developer + Telegram + version.
- Aura AI removed.

## NOT implemented (honest list)
Video/animated wallpapers (needs a licensed video source + WallpaperService), Premium/purchases, community uploads, Videos & Edits search, trending/popular rankings
(needs server data), calendar events widget (needs permission), Qibla compass, per-component styling of every button/card/dialog.

## External setup
- Google Sign-In: `GOOGLE_WEB_CLIENT_ID` (GitHub Variable) + fixed signing key secrets (`ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`); register the SHA-1 printed in the run Summary in Google Cloud (Android client) and create a Web client.
- Accounts, owner role and emails: deploy `backend/worker.js` with a D1 binding `DB` (see `backend/BACKEND_SETUP.md`): `GOOGLE_WEB_CLIENT_ID`, optional `OWNER_EMAIL`, Gmail secrets; set `AURA_BACKEND_URL`. Sign in yourself first: the first account to register is the owner.
