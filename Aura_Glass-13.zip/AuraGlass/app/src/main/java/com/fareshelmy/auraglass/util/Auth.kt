package com.fareshelmy.auraglass.util

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.NoCredentialException
import com.fareshelmy.auraglass.BuildConfig
import com.fareshelmy.auraglass.data.HttpException
import com.fareshelmy.auraglass.data.Net
import com.fareshelmy.auraglass.data.Store
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

fun Context.findActivity(): Activity? {
    var c = this
    while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }
    return null
}

/** Result of a sign-in / create-account attempt. */
enum class AuthResult { OK, NOT_REGISTERED, CANCELLED, NO_ACCOUNT, NETWORK, NOT_CONFIGURED, ERROR }

/**
 * Mandatory Google sign-in. Accounts live on YOUR backend (D1 database): "Create account" registers, "Sign in" only
 * accepts accounts that were registered before (otherwise NOT_REGISTERED). The Google ID token is kept in memory only
 * and is sent solely to your backend, which verifies it. The role (owner / member) comes ONLY from the backend.
 */
object Auth {
    /** Sign-in needs both a Google Web client id and the backend (which stores the accounts). */
    val enabled: Boolean get() = BuildConfig.GOOGLE_WEB_CLIENT_ID.isNotBlank()
    val configured: Boolean get() = BuildConfig.GOOGLE_WEB_CLIENT_ID.isNotBlank() && BuildConfig.AURA_BACKEND_URL.isNotBlank()
    private val base: String get() = BuildConfig.AURA_BACKEND_URL.trimEnd('/')

    var idToken by mutableStateOf<String?>(null)
    /** "owner" or "user". Comes ONLY from the backend. */
    var role by mutableStateOf("user")
        private set
    /** True once the backend has confirmed the account for the current sign-in. */
    var roleResolved by mutableStateOf(false)
        private set

    /** Token of a Google account the user picked that is NOT registered yet (kept in memory so "go to create account" needs no second picker). */
    private var pendingToken: String? = null
    private var pendingName: String = ""
    private var pendingEmail: String = ""

    private suspend fun pick(activity: Activity, silent: Boolean): GoogleIdTokenCredential {
        val option = GetGoogleIdOption.Builder()
            .setServerClientId(BuildConfig.GOOGLE_WEB_CLIENT_ID)
            .setFilterByAuthorizedAccounts(silent)
            .setAutoSelectEnabled(silent)
            .build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val cred = CredentialManager.create(activity).getCredential(activity, request).credential
        if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL)
            return GoogleIdTokenCredential.createFrom(cred.data)
        throw IllegalStateException("unsupported credential")
    }

    private suspend fun callBackend(path: String, token: String): JSONObject = withContext(Dispatchers.IO) {
        JSONObject(Net.postJson("$base$path", token, "{}", 20000))
    }

    private fun accept(token: String, name: String, email: String, j: JSONObject) {
        idToken = token
        Store.setAccount(name, email)
        role = if (j.optString("role") == "owner") "owner" else "user"
        roleResolved = true
        pendingToken = null
    }

    /**
     * @param register true = "Create account" (registers the account; if it already exists it simply signs in),
     *                 false = "Sign in" (existing accounts only: returns NOT_REGISTERED for an unknown account).
     * @param silent   true = no picker, only an account this app already used (automatic sign-in at app start).
     */
    suspend fun enter(activity: Activity, register: Boolean, silent: Boolean = false): AuthResult {
        if (!configured) return AuthResult.NOT_CONFIGURED
        val g = try { pick(activity, silent) }
        catch (e: GetCredentialCancellationException) { return AuthResult.CANCELLED }
        catch (e: NoCredentialException) { return if (silent) AuthResult.CANCELLED else AuthResult.NO_ACCOUNT }
        catch (e: Exception) { return AuthResult.ERROR }
        return finish(g.idToken, g.displayName ?: "", g.id, register)
    }

    /** "This account is not registered. Go to create account?" -> yes: registers the account the user already picked. */
    suspend fun registerPending(): AuthResult {
        val t = pendingToken ?: return AuthResult.ERROR
        return finish(t, pendingName, pendingEmail, register = true)
    }

    fun discardPending() { pendingToken = null }

    private suspend fun finish(token: String, name: String, email: String, register: Boolean): AuthResult = try {
        val j = callBackend(if (register) "/auth/register" else "/auth/login", token)
        accept(token, name, email, j)
        AuthResult.OK
    } catch (e: HttpException) {
        when (e.code) {
            404 -> { pendingToken = token; pendingName = name; pendingEmail = email; AuthResult.NOT_REGISTERED }
            401, 403 -> AuthResult.ERROR
            else -> AuthResult.NETWORK
        }
    } catch (e: Exception) { AuthResult.NETWORK }

    /** Asks the backend about the current (already signed-in) account. Returns false when the backend could not be reached. */
    suspend fun refreshRole(): Boolean {
        val token = idToken
        if (base.isBlank() || token == null) { role = "user"; roleResolved = false; return false }
        return try {
            val j = callBackend("/auth/login", token)
            role = if (j.optString("role") == "owner") "owner" else "user"
            roleResolved = true
            true
        } catch (e: Exception) { roleResolved = false; false }
    }

    /**
     * Runs a backend call with the Google ID token. Tokens expire after about an hour, so on HTTP 401 the app
     * silently signs in again and retries once.
     */
    suspend fun <T> authed(activity: Activity?, block: (token: String) -> T): T {
        suspend fun attempt(): T {
            val t = idToken ?: throw IllegalStateException("not signed in")
            return withContext(Dispatchers.IO) { block(t) }
        }
        return try { attempt() } catch (e: HttpException) {
            if (e.code == 401 && activity != null && enter(activity, register = false, silent = true) == AuthResult.OK) attempt() else throw e
        }
    }

    suspend fun signOut(ctx: Context) {
        try { CredentialManager.create(ctx).clearCredentialState(ClearCredentialStateRequest()) } catch (_: Exception) {}
        idToken = null
        role = "user"   // owner access disappears immediately on sign-out / account switch
        roleResolved = false
        pendingToken = null
        Store.clearAccount()
    }
}
