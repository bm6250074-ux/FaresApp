package com.fareshelmy.auraglass.ui

import android.appwidget.AppWidgetProvider
import android.content.Intent
import com.fareshelmy.auraglass.widgets.IslamicClockWidget
import com.fareshelmy.auraglass.widgets.PrayerListWidget
import com.fareshelmy.auraglass.widgets.GregorianWidget
import androidx.compose.foundation.layout.height
import androidx.compose.ui.viewinterop.AndroidView
import android.widget.FrameLayout
import android.text.format.DateFormat
import android.view.HapticFeedbackConstants
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.data.Store
import com.fareshelmy.auraglass.util.Hijri
import com.fareshelmy.auraglass.util.IslamicContent
import com.fareshelmy.auraglass.util.Prayer
import com.fareshelmy.auraglass.util.Quote
import com.fareshelmy.auraglass.widgets.DuaWidget
import com.fareshelmy.auraglass.widgets.HijriWidget
import com.fareshelmy.auraglass.widgets.PrayerWidget
import com.fareshelmy.auraglass.widgets.TasbihWidget
import com.fareshelmy.auraglass.widgets.VerseWidget
import com.fareshelmy.auraglass.widgets.Widgets
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalTime
import java.util.Locale

@Composable
internal fun PinButton(cls: Class<out AppWidgetProvider>) {
    val ctx = LocalContext.current
    OutlinedButton(onClick = { ctx.toast(if (Widgets.pin(ctx, cls)) R.string.pin_requested else R.string.pin_unsupported) }) { Text(stringResource(R.string.add_to_home)) }
}

@Composable
private fun QuoteCard(title: Int, list: List<Quote>, cls: Class<out AppWidgetProvider>?) {
    var shift by remember { mutableIntStateOf(0) }
    val q = IslamicContent.pick(list, shift)
    Section {
        Text(stringResource(title), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(q.ar, fontSize = 22.sp, textAlign = TextAlign.Center, lineHeight = 36.sp, modifier = Modifier.fillMaxWidth())
        if (q.ref.isNotBlank()) Text(q.ref, fontSize = 12.sp, color = Pal.muted, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { shift++ }) { Text(stringResource(R.string.next_one)) }
            if (cls != null) PinButton(cls)
        }
    }
}

@Composable
fun IslamicScreen(nav: NavController) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val is24 = remember { DateFormat.is24HourFormat(ctx) }
    val isAr = Locale.getDefault().language == "ar"
    val city = Prayer.cities[Store.cityIndex.coerceIn(0, Prayer.cities.lastIndex)]
    val method = Prayer.methods[Store.methodIndex.coerceIn(0, Prayer.methods.lastIndex)]
    val nowH by produceState(LocalTime.now().let { it.hour + it.minute / 60.0 }) {
        while (true) { value = LocalTime.now().let { it.hour + it.minute / 60.0 + it.second / 3600.0 }; delay(20_000) }
    }
    val times = remember(Store.cityIndex, Store.methodIndex, LocalDate.now()) { Prayer.forCity(LocalDate.now(), city, method) }
    val (nextIdx, left) = Prayer.next(city, method, nowH)
    val names = listOf(R.string.p_fajr, R.string.p_sunrise, R.string.p_dhuhr, R.string.p_asr, R.string.p_maghrib, R.string.p_isha)
    val values = listOf(times.fajr, times.sunrise, times.dhuhr, times.asr, times.maghrib, times.isha)
    // index into five() -> index into names/values
    val nextRow = listOf(0, 2, 3, 4, 5)[nextIdx]
    var cityMenu by remember { mutableStateOf(false) }
    var methodMenu by remember { mutableStateOf(false) }
    val ws = Store.widgetStyle

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { BackTitle(nav, stringResource(R.string.islamic_widgets)) }
        item {
            Section {
                Text(stringResource(R.string.prayer_times), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Box {
                    OutlinedButton(onClick = { cityMenu = true }) { Text(stringResource(R.string.city) + ": " + if (isAr) city.ar else city.en) }
                    DropdownMenu(expanded = cityMenu, onDismissRequest = { cityMenu = false }) {
                        Prayer.cities.forEachIndexed { i, c -> DropdownMenuItem(text = { Text(if (isAr) c.ar else c.en) }, onClick = { Store.setCity(i); cityMenu = false }) }
                    }
                }
                Box {
                    OutlinedButton(onClick = { methodMenu = true }) { Text(stringResource(R.string.method) + ": " + if (isAr) method.nameAr else method.nameEn) }
                    DropdownMenu(expanded = methodMenu, onDismissRequest = { methodMenu = false }) {
                        Prayer.methods.forEachIndexed { i, m -> DropdownMenuItem(text = { Text(if (isAr) m.nameAr else m.nameEn) }, onClick = { Store.setMethod(i); methodMenu = false }) }
                    }
                }
                names.forEachIndexed { i, r ->
                    Row(Modifier.fillMaxWidth().then(if (i == nextRow) Modifier.clip(androidx.compose.foundation.shape.RoundedCornerShape(12.dp)).background(Pal.accent.copy(alpha = 0.2f)) else Modifier).padding(horizontal = 10.dp, vertical = 8.dp)) {
                        Text(stringResource(r), Modifier.weight(1f), fontSize = 17.sp); Text(localizeDigits(Prayer.fmt(values[i], is24)), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                }
                val mins = (left * 60).toInt()
                Text(stringResource(R.string.next_prayer) + ": " + stringResource(names[nextRow]) + " — " + stringResource(R.string.in_hm, mins / 60, mins % 60), color = Pal.accent)
                Text(stringResource(R.string.prayer_note), fontSize = 12.sp, color = Pal.muted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { PinButton(PrayerWidget::class.java) }
            }
        }
        item {
            Section {
                Text(stringResource(R.string.dates), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(localizeDigits(Hijri.format()), fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text(java.time.format.DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy").format(LocalDate.now()), color = Pal.muted)
                Text(stringResource(R.string.hijri_note), fontSize = 12.sp, color = Pal.muted)
                PinButton(HijriWidget::class.java)
            }
        }
        item { QuoteCard(R.string.verse_of_day, IslamicContent.verses, VerseWidget::class.java) }
        item { QuoteCard(R.string.adhkar, IslamicContent.adhkar, null) }
        item { QuoteCard(R.string.dua_of_day, IslamicContent.duas, DuaWidget::class.java) }
        item {
            Section {
                Text(stringResource(R.string.tasbih), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Box(
                    Modifier.align(Alignment.CenterHorizontally).size(170.dp).clip(CircleShape).background(Pal.accent.copy(alpha = 0.18f))
                        .border(2.dp, Pal.accent, CircleShape)
                        .clickable { Store.incTasbih(); view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) },
                    contentAlignment = Alignment.Center,
                ) { Text(Store.tasbih.toString(), fontSize = 54.sp, fontWeight = FontWeight.Bold) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    listOf(33, 99, 100).forEach { t -> FilterChip(selected = Store.tasbihTarget == t, onClick = { Store.setTasbihTarget(t) }, label = { Text("$t") }) }
                    TextButton(onClick = { Store.resetTasbih() }) { Text(stringResource(R.string.reset)) }
                }
                if (Store.tasbih >= Store.tasbihTarget && Store.tasbih > 0) Text(stringResource(R.string.target_reached), color = Pal.accent)
                PinButton(TasbihWidget::class.java)
            }
        }
        item {
            Section {
                Text(stringResource(R.string.greetings), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(IslamicContent.greetings) { g ->
                        AssistChip(onClick = { ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, g), null)) }, label = { Text(g) })
                    }
                }
            }
        }
        item {
            Section {
                Text(stringResource(R.string.w_designs_title), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(stringResource(R.string.w_designs_note), fontSize = 12.sp, color = Pal.muted)
            }
        }
        widgetKinds.forEach { k -> item(key = "wk_" + k.key) { WidgetDesignCard(k) } }
        item {
            Section {
                Text(stringResource(R.string.combo_title), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                val now by rememberNow()
                Column(Modifier.fillMaxWidth().clip(androidx.compose.foundation.shape.RoundedCornerShape(20.dp)).background(Color.Black.copy(alpha = ws.bgAlpha)).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    ClockFace(Store.clockStyle.copy(design = 0, color = ws.textColor, scale = 0.7f * ws.scale), now)
                    Text(localizeDigits(Hijri.format()), color = Color(ws.textColor), fontSize = (18 * ws.scale).sp)
                    Text(IslamicContent.greetings[LocalDate.now().dayOfYear % IslamicContent.greetings.size], color = Color(ws.textColor), fontSize = (16 * ws.scale).sp)
                }
                Text(stringResource(R.string.widget_style), fontWeight = FontWeight.Bold)
                ColorRow(ws.textColor) { Store.updateWidgetStyle(ws.copy(textColor = it)) }
                Text(stringResource(R.string.clock_bg)); Slider(ws.bgAlpha, { Store.updateWidgetStyle(ws.copy(bgAlpha = it)) }, valueRange = 0f..1f)
                Text(stringResource(R.string.widget_bg_color)); HsvPicker(ws.bgColor) { Store.updateWidgetStyle(ws.copy(bgColor = it)) }
                Text(stringResource(R.string.clock_size)); Slider(ws.scale, { Store.updateWidgetStyle(ws.copy(scale = it)) }, valueRange = 0.7f..1.5f)
                Button(onClick = { Widgets.updateAll(ctx); ctx.toast(R.string.widgets_updated) }) { Text(stringResource(R.string.apply_widgets)) }
                Text(stringResource(R.string.islamic_verify_note), fontSize = 12.sp, color = Pal.muted)
            }
        }
    }
}


internal data class WidgetKind(val key: String, val nameRes: Int, val cls: Class<out AppWidgetProvider>, val variants: Boolean = true)

private val widgetKinds = listOf(
    WidgetKind("hijri", R.string.wk_hijri, HijriWidget::class.java),
    WidgetKind("gregorian", R.string.wk_greg, GregorianWidget::class.java),
    WidgetKind("prayer", R.string.wk_prayer, PrayerWidget::class.java),
    WidgetKind("prayerlist", R.string.wk_prayer_list, PrayerListWidget::class.java),
    WidgetKind("verse", R.string.wk_verse, VerseWidget::class.java),
    WidgetKind("dua", R.string.wk_dua, DuaWidget::class.java),
    WidgetKind("tasbih", R.string.wk_tasbih, TasbihWidget::class.java),
    WidgetKind("islamicclock", R.string.wk_islamic_clock, IslamicClockWidget::class.java, variants = false),
)

internal val variantNames = listOf(R.string.wv_0, R.string.wv_1, R.string.wv_2, R.string.wv_3, R.string.wv_4)

/** The exact RemoteViews the home screen will show, inflated inside the app (so what you see is what you get). */
@Composable
internal fun RemotePreview(cls: Class<out AppWidgetProvider>) {
    val ctx = LocalContext.current
    AndroidView(
        factory = { FrameLayout(it) },
        update = { frame ->
            frame.removeAllViews()
            try { Widgets.preview(ctx, cls)?.let { rv -> frame.addView(rv.apply(ctx, frame)) } } catch (e: Exception) { }
        },
        modifier = Modifier.fillMaxWidth().height(130.dp),
    )
}

@Composable
internal fun WidgetDesignCard(k: WidgetKind) {
    val ctx = LocalContext.current
    Section {
        Text(stringResource(k.nameRes), fontWeight = FontWeight.Bold)
        RemotePreview(k.cls)
        if (k.variants) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(variantNames.size) { i ->
                    FilterChip(selected = Store.widgetVariant(k.key) == i, onClick = { Store.setWidgetVariant(k.key, i); Widgets.updateAll(ctx) }, label = { Text(stringResource(variantNames[i])) })
                }
            }
        }
        PinButton(k.cls)
    }
}
