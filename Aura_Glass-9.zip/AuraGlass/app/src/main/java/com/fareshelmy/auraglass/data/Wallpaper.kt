package com.fareshelmy.auraglass.data

import org.json.JSONArray
import org.json.JSONObject

/** One wallpaper from any source: "commons", "openverse", "local" (built-in) or "imported" (user's own). */
data class Wallpaper(
    val id: String,
    val title: String,
    val thumb: String,
    val full: String,
    val creator: String = "",
    val license: String = "",
    val licenseUrl: String = "",
    val sourceUrl: String = "",
    val tags: List<String> = emptyList(),
    val source: String = "commons",
    val seed: Int = 0,
    val width: Int = 0,
    val height: Int = 0,
    /** Searchable text from the source (description + all categories). Used only for relevance. */
    val meta: String = "",
) {
    val isLocal get() = source == "local"
    val isGen get() = source == "gen"
    /** User photos and offline copies are plain files in app storage. */
    val isImported get() = source == "imported" || source == "offline"

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("title", title).put("thumb", thumb).put("full", full)
        .put("creator", creator).put("license", license).put("licenseUrl", licenseUrl)
        .put("sourceUrl", sourceUrl).put("tags", JSONArray(tags)).put("source", source)
        .put("seed", seed).put("width", width).put("height", height).put("meta", meta.take(160))

    companion object {
        fun fromJson(o: JSONObject): Wallpaper {
            val arr = o.optJSONArray("tags")
            val tags = if (arr == null) emptyList() else List(arr.length()) { arr.optString(it) }
            return Wallpaper(
                id = o.optString("id"), title = o.optString("title"),
                thumb = o.optString("thumb"), full = o.optString("full"),
                creator = o.optString("creator"), license = o.optString("license"),
                licenseUrl = o.optString("licenseUrl"), sourceUrl = o.optString("sourceUrl"),
                tags = tags, source = o.optString("source", "commons"),
                seed = o.optInt("seed"), width = o.optInt("width"), height = o.optInt("height"), meta = o.optString("meta"),
            )
        }
    }
}

/** Built-in, procedurally generated AMOLED wallpapers (original work, no download needed, work offline). */
data class LocalDesign(val c1: Int, val c2: Int, val cx: Float, val cy: Float, val kind: Int)

object LocalCatalog {
    private val names = listOf("Nebula", "Aurora", "Ember", "Lagoon", "Orchid", "Mint", "Solar", "Dusk")

    fun design(seed: Int): LocalDesign {
        val h1 = (seed * 15f) % 360f
        val h2 = (h1 + 40f + (seed % 5) * 20f) % 360f
        val c1 = android.graphics.Color.HSVToColor(floatArrayOf(h1, 0.8f, 0.95f))
        val c2 = android.graphics.Color.HSVToColor(floatArrayOf(h2, 0.7f, 0.65f))
        val cx = 0.2f + ((seed * 37) % 60) / 100f
        val cy = 0.15f + ((seed * 53) % 70) / 100f
        return LocalDesign(c1, c2, cx, cy, seed % 3)
    }

    val items: List<Wallpaper> = (0 until 24).map {
        Wallpaper(
            id = "local:$it", title = "${names[it % names.size]} ${it / names.size + 1}",
            thumb = "", full = "", creator = "Aura Glass", license = "Original (built-in)",
            tags = listOf("amoled", "gradient"), source = "local", seed = it,
            width = 1080, height = 1920,
        )
    }
}
