package com.fareshelmy.auraglass.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Build
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import com.fareshelmy.auraglass.MainActivity
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.data.Store
import com.fareshelmy.auraglass.ui.localizeDigits
import com.fareshelmy.auraglass.util.Hijri
import com.fareshelmy.auraglass.util.IslamicContent
import com.fareshelmy.auraglass.util.Prayer
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle as JTextStyle
import java.util.Locale

/** bodySp = 0 means "use the layout variant's default size". */
data class WidgetContent(val title: String, val body: String, val button: String? = null, val bodySp: Float = 0f)

private fun openAppIntent(ctx: Context): PendingIntent =
    PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

private fun withAlpha(color: Int, a: Float): Int = (color and 0x00FFFFFF) or ((a.coerceIn(0f, 1f) * 255).toInt() shl 24)

private fun bgRes(alpha: Float): Int = when (Math.round(alpha * 4f).coerceIn(0, 4)) {
    0 -> R.drawable.widget_bg_0
    1 -> R.drawable.widget_bg_1
    2 -> R.drawable.widget_bg_2
    3 -> R.drawable.widget_bg_3
    else -> R.drawable.widget_bg_4
}

/** Background colour + transparency. Android 12+ tints the rounded drawable with any colour; older versions use black steps. */
private fun applyBackground(rv: RemoteViews, viewId: Int, color: Int, alpha: Float) {
    if (Build.VERSION.SDK_INT >= 31) {
        rv.setInt(viewId, "setBackgroundResource", R.drawable.widget_bg_4)
        rv.setColorStateList(viewId, "setBackgroundTintList", ColorStateList.valueOf(withAlpha(color, alpha)))
    } else rv.setInt(viewId, "setBackgroundResource", bgRes(alpha))
}

val widgetLayouts = intArrayOf(R.layout.widget_text, R.layout.widget_v1_big, R.layout.widget_v2_card, R.layout.widget_v3_line, R.layout.widget_v4_frame)

/**
 * Base for the text-style home-screen widgets. Five genuinely different layouts (centered, big headline, card with bar,
 * single line, framed serif) x the user's colours/size/transparency, chosen per widget type in the Islamic section.
 */
abstract class TextWidget : AppWidgetProvider() {
    abstract val key: String
    abstract fun content(ctx: Context): WidgetContent
    open fun buttonIntent(ctx: Context): PendingIntent? = null

    fun build(ctx: Context): RemoteViews {
        Store.ensure(ctx)
        val c = content(ctx)
        val st = Store.widgetStyle
        val variant = Store.widgetVariant(key).coerceIn(0, widgetLayouts.lastIndex)
        val rv = RemoteViews(ctx.packageName, widgetLayouts[variant])
        rv.setTextViewText(R.id.wTitle, localizeDigits(c.title))
        rv.setTextViewText(R.id.wBody, localizeDigits(c.body))
        rv.setTextColor(R.id.wTitle, st.textColor)
        rv.setTextColor(R.id.wBody, st.textColor)
        val bodyBase = when {
            c.bodySp > 0f -> c.bodySp
            variant == 1 -> 32f
            variant == 3 -> 16f
            variant == 2 -> 17f
            else -> 18f
        }
        rv.setTextViewTextSize(R.id.wTitle, TypedValue.COMPLEX_UNIT_SP, 12f * st.scale)
        rv.setTextViewTextSize(R.id.wBody, TypedValue.COMPLEX_UNIT_SP, bodyBase * st.scale)
        if (variant == 2) rv.setInt(R.id.wBar, "setBackgroundColor", st.textColor)
        applyBackground(rv, R.id.wRoot, st.bgColor, st.bgAlpha)
        rv.setOnClickPendingIntent(R.id.wRoot, openAppIntent(ctx))
        if (c.button != null) {
            rv.setViewVisibility(R.id.wBtn, View.VISIBLE)
            rv.setTextViewText(R.id.wBtn, c.button)
            buttonIntent(ctx)?.let { rv.setOnClickPendingIntent(R.id.wBtn, it) }
        } else rv.setViewVisibility(R.id.wBtn, View.GONE)
        return rv
    }

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { mgr.updateAppWidget(it, build(ctx)) }
    }
}

private fun city() = Prayer.cities[Store.cityIndex.coerceIn(0, Prayer.cities.lastIndex)]
private fun method() = Prayer.methods[Store.methodIndex.coerceIn(0, Prayer.methods.lastIndex)]
private fun nowHours() = LocalTime.now().let { it.hour + it.minute / 60.0 }
private fun prayerNames(ctx: Context) = listOf(R.string.p_fajr, R.string.p_dhuhr, R.string.p_asr, R.string.p_maghrib, R.string.p_isha).map { ctx.getString(it) }

class HijriWidget : TextWidget() {
    override val key = "hijri"
    override fun content(ctx: Context) = WidgetContent(
        LocalDate.now().dayOfWeek.getDisplayName(JTextStyle.FULL, Locale.getDefault()),
        Hijri.format(),
    )
}

class GregorianWidget : TextWidget() {
    override val key = "gregorian"
    override fun content(ctx: Context) = WidgetContent(
        LocalDate.now().dayOfWeek.getDisplayName(JTextStyle.FULL, Locale.getDefault()),
        DateTimeFormatter.ofPattern("d MMMM yyyy", Locale.getDefault()).format(LocalDate.now()),
    )
}

class PrayerWidget : TextWidget() {
    override val key = "prayer"
    override fun content(ctx: Context): WidgetContent {
        val (i, left) = Prayer.next(city(), method(), nowHours())
        val today = Prayer.forCity(LocalDate.now(), city(), method()).five()
        val mins = (left * 60).toInt()
        return WidgetContent("${ctx.getString(R.string.next_prayer)}: ${prayerNames(ctx)[i]}", "${Prayer.fmt(today[i])}\n${ctx.getString(R.string.in_hm, mins / 60, mins % 60)}")
    }
}

class PrayerListWidget : TextWidget() {
    override val key = "prayerlist"
    override fun content(ctx: Context): WidgetContent {
        val t = Prayer.forCity(LocalDate.now(), city(), method())
        val names = prayerNames(ctx)
        val body = t.five().mapIndexed { i, h -> "${names[i]}  ${Prayer.fmt(h)}" }.joinToString("\n")
        return WidgetContent(ctx.getString(R.string.prayer_times), body, null, 13f)
    }
}

class VerseWidget : TextWidget() {
    override val key = "verse"
    override fun content(ctx: Context): WidgetContent {
        val q = IslamicContent.pick(IslamicContent.verses)
        return WidgetContent(q.ref, q.ar, null, 16f)
    }
}

class DuaWidget : TextWidget() {
    override val key = "dua"
    override fun content(ctx: Context): WidgetContent {
        val q = IslamicContent.pick(IslamicContent.duas)
        return WidgetContent(q.ref, q.ar, null, 16f)
    }
}

class TasbihWidget : TextWidget() {
    companion object { const val ACTION_INC = "com.fareshelmy.auraglass.TASBIH_INC" }
    override val key = "tasbih"
    override fun content(ctx: Context) = WidgetContent(ctx.getString(R.string.tasbih), Store.tasbih.toString(), ctx.getString(R.string.tap_count))
    override fun buttonIntent(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 7, Intent(ctx, TasbihWidget::class.java).setAction(ACTION_INC), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    override fun onReceive(context: Context, intent: Intent) {
        Store.ensure(context)
        if (intent.action == ACTION_INC) {
            Store.incTasbih()
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, TasbihWidget::class.java))
            onUpdate(context, mgr, ids)
        } else super.onReceive(context, intent)
    }
}

/** Live clock (system TextClock) + Hijri date + Gregorian date. */
class IslamicClockWidget : AppWidgetProvider() {
    fun build(ctx: Context): RemoteViews {
        Store.ensure(ctx)
        val st = Store.widgetStyle
        val rv = RemoteViews(ctx.packageName, R.layout.widget_islamic_clock)
        rv.setTextColor(R.id.wTime, st.textColor); rv.setTextColor(R.id.wBody, st.textColor); rv.setTextColor(R.id.wDate, st.textColor)
        rv.setTextViewTextSize(R.id.wTime, TypedValue.COMPLEX_UNIT_SP, 44f * st.scale)
        rv.setTextViewTextSize(R.id.wBody, TypedValue.COMPLEX_UNIT_SP, 15f * st.scale)
        rv.setTextViewTextSize(R.id.wDate, TypedValue.COMPLEX_UNIT_SP, 12f * st.scale)
        rv.setTextViewText(R.id.wBody, localizeDigits(Hijri.format()))
        applyBackground(rv, R.id.wRoot, st.bgColor, st.bgAlpha)
        rv.setOnClickPendingIntent(R.id.wRoot, openAppIntent(ctx))
        return rv
    }
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) { ids.forEach { mgr.updateAppWidget(it, build(ctx)) } }
}

class ClockDigitalWidget : AppWidgetProvider() {
    fun build(ctx: Context): RemoteViews {
        Store.ensure(ctx)
        val st = Store.clockStyle
        val rv = RemoteViews(ctx.packageName, R.layout.widget_clock_digital)
        rv.setTextColor(R.id.wTime, st.color); rv.setTextColor(R.id.wDate, st.accent)
        rv.setTextViewTextSize(R.id.wTime, TypedValue.COMPLEX_UNIT_SP, 48f * st.scale)
        rv.setTextViewTextSize(R.id.wDate, TypedValue.COMPLEX_UNIT_SP, 14f * st.scale)
        rv.setInt(R.id.wRoot, "setBackgroundResource", bgRes(st.bgAlpha))
        rv.setOnClickPendingIntent(R.id.wRoot, openAppIntent(ctx))
        return rv
    }
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) { ids.forEach { mgr.updateAppWidget(it, build(ctx)) } }
}

class ClockAnalogWidget : AppWidgetProvider() {
    fun build(ctx: Context): RemoteViews {
        Store.ensure(ctx)
        val rv = RemoteViews(ctx.packageName, R.layout.widget_clock_analog)
        rv.setInt(R.id.wRoot, "setBackgroundResource", bgRes(Store.clockStyle.bgAlpha))
        rv.setOnClickPendingIntent(R.id.wRoot, openAppIntent(ctx))
        return rv
    }
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) { ids.forEach { mgr.updateAppWidget(it, build(ctx)) } }
}

private fun gridMonth(): Pair<String, String> {
    val today = LocalDate.now()
    val first = today.withDayOfMonth(1)
    val len = today.lengthOfMonth()
    val title = DateTimeFormatter.ofPattern("LLLL yyyy", Locale.getDefault()).format(today)
    val head = (1..7).joinToString("") { i -> java.time.DayOfWeek.of(i).getDisplayName(JTextStyle.SHORT, Locale.getDefault()).take(2).padStart(3).padEnd(4) }
    val sb = StringBuilder(head).append('\n')
    var col = first.dayOfWeek.value - 1                       // Monday-first
    repeat(col) { sb.append("    ") }
    for (d in 1..len) {
        sb.append(if (d == today.dayOfMonth) "[" + d.toString().padStart(2) + "]" else " " + d.toString().padStart(2) + " ")
        col++
        if (col == 7) { col = 0; if (d < len) sb.append('\n') }
    }
    return title to localizeDigits(sb.toString())
}

class BatteryWidget : TextWidget() {
    override val key = "battery"
    override fun content(ctx: Context): WidgetContent {
        val i = ctx.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100) ?: 100
        val st = i?.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = st == android.os.BatteryManager.BATTERY_STATUS_CHARGING || st == android.os.BatteryManager.BATTERY_STATUS_FULL
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val title = ctx.getString(if (charging) R.string.battery_charging else R.string.battery_title)
        return WidgetContent(title, if (pct >= 0) "$pct%" else "—", null, 30f)
    }
}

class WeekdayWidget : TextWidget() {
    override val key = "weekday"
    override fun content(ctx: Context) = WidgetContent(
        DateTimeFormatter.ofPattern("d MMMM", Locale.getDefault()).format(LocalDate.now()),
        LocalDate.now().dayOfWeek.getDisplayName(JTextStyle.FULL, Locale.getDefault()), null, 26f)
}

class DayWidget : TextWidget() {
    override val key = "day"
    override fun content(ctx: Context) = WidgetContent(
        DateTimeFormatter.ofPattern("MMM", Locale.getDefault()).format(LocalDate.now()).uppercase(Locale.getDefault()),
        LocalDate.now().dayOfMonth.toString(), null, 54f)
}

class CustomTextWidget : TextWidget() {
    override val key = "customtext"
    override fun content(ctx: Context) = WidgetContent("", Store.widgetText.ifBlank { ctx.getString(R.string.widget_text_hint) }, null, 22f)
}

class NotesWidget : TextWidget() {
    override val key = "notes"
    override fun content(ctx: Context) = WidgetContent(ctx.getString(R.string.wk_notes), Store.widgetNote.ifBlank { ctx.getString(R.string.widget_note_hint) }, null, 14f)
}

/** Weather from Open-Meteo (free, no key). Uses the city chosen in the Islamic section; refreshed in the background. */
object WeatherRepo {
    fun refresh(ctx: Context) {
        Store.ensure(ctx)
        val c = Prayer.cities[Store.cityIndex.coerceIn(0, Prayer.cities.lastIndex)]
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${c.lat}&longitude=${c.lng}&current=temperature_2m,weather_code" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=4"
        val body = com.fareshelmy.auraglass.data.Net.get(url, 15000)
        org.json.JSONObject(body).getJSONObject("current")      // validate before saving
        Store.saveWeather(body)
    }
    fun codeText(ctx: Context, code: Int): String = ctx.getString(when (code) {
        0 -> R.string.w_clear; 1, 2, 3 -> R.string.w_cloudy; 45, 48 -> R.string.w_fog; in 51..57 -> R.string.w_drizzle
        in 61..67 -> R.string.w_rain; in 71..77, 85, 86 -> R.string.w_snow; in 80..82 -> R.string.w_showers; in 95..99 -> R.string.w_storm; else -> R.string.w_cloudy
    })
    fun current(): Triple<Int, Int, org.json.JSONObject>? = try {
        val o = org.json.JSONObject(Store.weatherJson); val cur = o.getJSONObject("current")
        Triple(Math.round(cur.getDouble("temperature_2m")).toInt(), cur.getInt("weather_code"), o)
    } catch (e: Exception) { null }
}

abstract class WeatherBase : TextWidget() {
    abstract fun weatherContent(ctx: Context): WidgetContent
    override fun content(ctx: Context): WidgetContent = weatherContent(ctx)
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val pending = goAsync()
        Thread {
            try { WeatherRepo.refresh(ctx) } catch (e: Exception) { /* keep the last cached data; shows "—" if none */ }
            try { ids.forEach { mgr.updateAppWidget(it, build(ctx)) } } finally { pending.finish() }
        }.start()
    }
}

class WeatherWidget : WeatherBase() {
    override val key = "weather"
    override fun weatherContent(ctx: Context): WidgetContent {
        val cur = WeatherRepo.current() ?: return WidgetContent(ctx.getString(R.string.wk_weather), "—", null, 30f)
        val city = Prayer.cities[Store.cityIndex.coerceIn(0, Prayer.cities.lastIndex)]
        val name = if (Locale.getDefault().language == "ar") city.ar else city.en
        return WidgetContent("$name · ${WeatherRepo.codeText(ctx, cur.second)}", "${cur.first}°", null, 38f)
    }
}

class ForecastWidget : WeatherBase() {
    override val key = "forecast"
    override fun weatherContent(ctx: Context): WidgetContent {
        val cur = WeatherRepo.current() ?: return WidgetContent(ctx.getString(R.string.wk_forecast), "—", null, 16f)
        return try {
            val d = cur.third.getJSONObject("daily"); val times = d.getJSONArray("time"); val mx = d.getJSONArray("temperature_2m_max"); val mn = d.getJSONArray("temperature_2m_min"); val codes = d.getJSONArray("weather_code")
            val lines = (0 until minOf(4, times.length())).joinToString("\n") { i ->
                val day = LocalDate.parse(times.getString(i)).dayOfWeek.getDisplayName(JTextStyle.SHORT, Locale.getDefault())
                "$day  ${Math.round(mx.getDouble(i)).toInt()}° / ${Math.round(mn.getDouble(i)).toInt()}°  ${WeatherRepo.codeText(ctx, codes.getInt(i))}"
            }
            WidgetContent("${ctx.getString(R.string.wk_forecast)} · ${cur.first}°", lines, null, 13f)
        } catch (e: Exception) { WidgetContent(ctx.getString(R.string.wk_forecast), "—", null, 16f) }
    }
}

/** Calendar month grid with a monospace layout so columns line up. */
class MonthWidget : AppWidgetProvider() {
    fun build(ctx: Context): RemoteViews {
        Store.ensure(ctx)
        val st = Store.widgetStyle
        val (title, grid) = gridMonth()
        val rv = RemoteViews(ctx.packageName, R.layout.widget_month)
        rv.setTextViewText(R.id.wTitle, localizeDigits(title)); rv.setTextViewText(R.id.wBody, grid)
        rv.setTextColor(R.id.wTitle, st.textColor); rv.setTextColor(R.id.wBody, st.textColor)
        rv.setTextViewTextSize(R.id.wTitle, TypedValue.COMPLEX_UNIT_SP, 13f * st.scale); rv.setTextViewTextSize(R.id.wBody, TypedValue.COMPLEX_UNIT_SP, 11f * st.scale)
        applyBackground(rv, R.id.wRoot, st.bgColor, st.bgAlpha)
        rv.setOnClickPendingIntent(R.id.wRoot, openAppIntent(ctx))
        return rv
    }
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) { ids.forEach { mgr.updateAppWidget(it, build(ctx)) } }
}

private fun decodeSmall(path: String, max: Int = 480): android.graphics.Bitmap? = try {
    val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    android.graphics.BitmapFactory.decodeFile(path, o)
    var sample = 1; while (maxOf(o.outWidth, o.outHeight) / sample > max) sample *= 2
    android.graphics.BitmapFactory.decodeFile(path, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
} catch (e: Exception) { null }

fun widgetPhotoFile(ctx: Context) = java.io.File(ctx.filesDir, "widget_photo.jpg")

abstract class ImageWidgetBase : AppWidgetProvider() {
    abstract fun pickPath(ctx: Context): String?
    fun build(ctx: Context): RemoteViews {
        Store.ensure(ctx)
        val st = Store.widgetStyle
        val rv = RemoteViews(ctx.packageName, R.layout.widget_photo)
        val bmp = pickPath(ctx)?.let { decodeSmall(it) }
        if (bmp != null) { rv.setImageViewBitmap(R.id.wImg, bmp); rv.setViewVisibility(R.id.wHint, View.GONE); rv.setViewVisibility(R.id.wImg, View.VISIBLE) }
        else { rv.setViewVisibility(R.id.wImg, View.GONE); rv.setViewVisibility(R.id.wHint, View.VISIBLE); rv.setTextViewText(R.id.wHint, ctx.getString(R.string.widget_photo_hint)); rv.setTextColor(R.id.wHint, st.textColor) }
        applyBackground(rv, R.id.wRoot, st.bgColor, st.bgAlpha.coerceAtLeast(0.2f))
        rv.setOnClickPendingIntent(R.id.wRoot, openAppIntent(ctx))
        return rv
    }
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) { ids.forEach { mgr.updateAppWidget(it, build(ctx)) } }
}

class PhotoWidget : ImageWidgetBase() {
    override fun pickPath(ctx: Context): String? = widgetPhotoFile(ctx).takeIf { it.exists() }?.absolutePath
}

/** Rotates through YOUR imported photos and offline wallpapers (changes about every 30 minutes). */
class GalleryWidget : ImageWidgetBase() {
    override fun pickPath(ctx: Context): String? {
        Store.ensure(ctx)
        val files = (Store.imported + Store.offline).mapNotNull { w -> android.net.Uri.parse(w.full).path?.let { java.io.File(it) }?.takeIf { it.exists() } }
        if (files.isEmpty()) return null
        return files[((System.currentTimeMillis() / (30 * 60 * 1000L)) % files.size).toInt()].absolutePath
    }
}

object Widgets {
    val all: List<Class<out AppWidgetProvider>> = listOf(
        ClockDigitalWidget::class.java, ClockAnalogWidget::class.java, HijriWidget::class.java, GregorianWidget::class.java,
        PrayerWidget::class.java, PrayerListWidget::class.java, VerseWidget::class.java, DuaWidget::class.java,
        TasbihWidget::class.java, IslamicClockWidget::class.java,
        BatteryWidget::class.java, MonthWidget::class.java, WeekdayWidget::class.java, DayWidget::class.java, CustomTextWidget::class.java,
        NotesWidget::class.java, WeatherWidget::class.java, ForecastWidget::class.java, PhotoWidget::class.java, GalleryWidget::class.java,
    )

    /** Builds the REAL RemoteViews of a widget type (used for the exact in-app preview). */
    fun preview(ctx: Context, cls: Class<out AppWidgetProvider>): RemoteViews? = try {
        when (cls) {
            HijriWidget::class.java -> HijriWidget().build(ctx)
            GregorianWidget::class.java -> GregorianWidget().build(ctx)
            PrayerWidget::class.java -> PrayerWidget().build(ctx)
            PrayerListWidget::class.java -> PrayerListWidget().build(ctx)
            VerseWidget::class.java -> VerseWidget().build(ctx)
            DuaWidget::class.java -> DuaWidget().build(ctx)
            TasbihWidget::class.java -> TasbihWidget().build(ctx)
            IslamicClockWidget::class.java -> IslamicClockWidget().build(ctx)
            BatteryWidget::class.java -> BatteryWidget().build(ctx)
            MonthWidget::class.java -> MonthWidget().build(ctx)
            WeekdayWidget::class.java -> WeekdayWidget().build(ctx)
            DayWidget::class.java -> DayWidget().build(ctx)
            CustomTextWidget::class.java -> CustomTextWidget().build(ctx)
            NotesWidget::class.java -> NotesWidget().build(ctx)
            WeatherWidget::class.java -> WeatherWidget().build(ctx)
            ForecastWidget::class.java -> ForecastWidget().build(ctx)
            PhotoWidget::class.java -> PhotoWidget().build(ctx)
            GalleryWidget::class.java -> GalleryWidget().build(ctx)
            ClockDigitalWidget::class.java -> ClockDigitalWidget().build(ctx)
            ClockAnalogWidget::class.java -> ClockAnalogWidget().build(ctx)
            else -> null
        }
    } catch (e: Exception) { null }

    /** Re-draws every placed widget with the latest saved style. */
    fun updateAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        all.forEach { cls ->
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, cls))
            if (ids.isNotEmpty()) ctx.sendBroadcast(
                Intent(ctx, cls).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE).putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            )
        }
    }

    /** Asks the launcher to pin the widget. Returns false when the launcher doesn't support pinning (add it manually). */
    fun pin(ctx: Context, cls: Class<out AppWidgetProvider>): Boolean {
        val mgr = AppWidgetManager.getInstance(ctx)
        return if (mgr.isRequestPinAppWidgetSupported) mgr.requestPinAppWidget(ComponentName(ctx, cls), null, null) else false
    }
}
