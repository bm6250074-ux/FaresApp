package com.fareshelmy.auraglass.util

import android.app.WallpaperManager
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.Shader
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import com.fareshelmy.auraglass.data.LocalCatalog
import com.fareshelmy.auraglass.data.Net
import com.fareshelmy.auraglass.data.Wallpaper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import kotlin.math.max

object Images {
    private fun alpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

    /** Same recipe as the Compose LocalArt composable, rendered to a real bitmap. */
    fun renderLocal(seed: Int, w: Int = 1080, h: Int = 1920): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.BLACK)
        val d = LocalCatalog.design(seed)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val full = floatArrayOf(0f, 0f, w.toFloat(), h.toFloat())
        p.shader = RadialGradient(w * d.cx, h * d.cy, w * 1.1f, alpha(d.c1, 220), alpha(d.c1, 0), Shader.TileMode.CLAMP)
        c.drawRect(full[0], full[1], full[2], full[3], p)
        if (d.kind >= 1) {
            p.shader = RadialGradient(w * (1f - d.cx), h * (1f - d.cy * 0.8f), w * 0.95f, alpha(d.c2, 200), alpha(d.c2, 0), Shader.TileMode.CLAMP)
            c.drawRect(full[0], full[1], full[2], full[3], p)
        }
        if (d.kind == 2) {
            p.shader = android.graphics.LinearGradient(0f, h.toFloat(), w.toFloat(), 0f, alpha(d.c2, 110), alpha(d.c2, 0), Shader.TileMode.CLAMP)
            c.drawRect(full[0], full[1], full[2], full[3], p)
        }
        return b
    }

    fun decodeBytes(b: ByteArray, maxSide: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        var s = 1
        while (max(o.outWidth, o.outHeight) / s > maxSide) s *= 2
        return BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s })
    }

    suspend fun load(ctx: Context, wp: Wallpaper, maxSide: Int = 2400): Bitmap? = withContext(Dispatchers.IO) {
        try {
            when {
                wp.isGen -> com.fareshelmy.auraglass.data.Walls.render(wp.seed, 1080, 1920)
                wp.isLocal -> renderLocal(wp.seed)
                wp.isImported -> decodeBytes(File(Uri.parse(wp.full).path ?: "").readBytes(), maxSide)
                else -> decodeBytes(Net.bytes(wp.full), maxSide)
            }
        } catch (e: Exception) { null }
    }

    suspend fun loadUri(ctx: Context, uri: Uri, maxSide: Int = 2400): Bitmap? = withContext(Dispatchers.IO) {
        try {
            val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@withContext null
            if (bytes.size > 60_000_000) null else decodeBytes(bytes, maxSide)
        } catch (e: Exception) { null }
    }

    /** Copies the picked image into app-private storage (downscaled). Never uploaded anywhere. */
    suspend fun importToLibrary(ctx: Context, uri: Uri): Wallpaper? = withContext(Dispatchers.IO) {
        try {
            val bmp = loadUri(ctx, uri, 2560) ?: return@withContext null
            val dir = File(ctx.filesDir, "imported").apply { mkdirs() }
            val id = UUID.randomUUID().toString()
            val file = File(dir, "$id.png".takeIf { bmp.hasAlpha() } ?: "$id.jpg")
            file.outputStream().use {
                if (bmp.hasAlpha()) bmp.compress(Bitmap.CompressFormat.PNG, 100, it) else bmp.compress(Bitmap.CompressFormat.JPEG, 92, it)
            }
            var name = "Imported"
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0)?.substringBeforeLast('.') ?: name
            }
            val u = Uri.fromFile(file).toString()
            Wallpaper("imp:$id", name, u, u, "You", "Personal (local only)", "", "", emptyList(), "imported", 0, bmp.width, bmp.height)
        } catch (e: Exception) { null }
    }

    /** Saves a full-size copy of an online wallpaper in app-private storage so it works without internet. */
    suspend fun saveOffline(ctx: Context, bmp: Bitmap, wp: Wallpaper): Wallpaper? = withContext(Dispatchers.IO) {
        try {
            val dir = File(ctx.filesDir, "offline").apply { mkdirs() }
            val file = File(dir, wp.id.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".jpg")
            file.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 93, it) }
            val u = Uri.fromFile(file).toString()
            wp.copy(id = "off:" + wp.id, thumb = u, full = u, source = "offline", width = bmp.width, height = bmp.height)
        } catch (e: Exception) { null }
    }

    /** Stores an edited bitmap in the app-private library (never uploaded). */
    suspend fun addBitmapToLibrary(ctx: Context, bmp: Bitmap, name: String): Wallpaper? = withContext(Dispatchers.IO) {
        try {
            val dir = File(ctx.filesDir, "imported").apply { mkdirs() }
            val id = UUID.randomUUID().toString()
            val file = File(dir, if (bmp.hasAlpha()) "$id.png" else "$id.jpg")
            file.outputStream().use { if (bmp.hasAlpha()) bmp.compress(Bitmap.CompressFormat.PNG, 100, it) else bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            val u = Uri.fromFile(file).toString()
            Wallpaper("imp:$id", name, u, u, "You", "Personal (local only)", "", "", emptyList(), "imported", 0, bmp.width, bmp.height)
        } catch (e: Exception) { null }
    }

    /** Crop to [aspect] (w/h); [pos] 0..1 moves the crop window along the cropped axis. */
    fun cropToAspect(bmp: Bitmap, aspect: Float, pos: Float): Bitmap {
        val ba = bmp.width.toFloat() / bmp.height
        return if (ba > aspect) {
            val nw = (bmp.height * aspect).toInt().coerceIn(1, bmp.width)
            Bitmap.createBitmap(bmp, ((bmp.width - nw) * pos).toInt(), 0, nw, bmp.height)
        } else {
            val nh = (bmp.width / aspect).toInt().coerceIn(1, bmp.height)
            Bitmap.createBitmap(bmp, 0, ((bmp.height - nh) * pos).toInt(), bmp.width, nh)
        }
    }

    /** Draw [bmp] center-cropped into a w x h canvas with an offset (px) and zoom. */
    fun drawCover(c: Canvas, bmp: Bitmap, w: Int, h: Int, dx: Float = 0f, dy: Float = 0f, zoom: Float = 1f) {
        val scale = max(w.toFloat() / bmp.width, h.toFloat() / bmp.height) * zoom
        val sw = w / scale; val sh = h / scale
        val left = ((bmp.width - sw) / 2f - dx / scale).toInt()
        val top = ((bmp.height - sh) / 2f - dy / scale).toInt()
        c.drawBitmap(bmp, Rect(left, top, (left + sw).toInt(), (top + sh).toInt()), Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))
    }

    /** flags: 0 home, 1 lock, 2 both. Returns false if the system refuses (e.g. disabled by policy). */
    fun setWallpaper(ctx: Context, bmp: Bitmap, target: Int): Boolean = try {
        val wm = WallpaperManager.getInstance(ctx)
        if (!wm.isWallpaperSupported || !wm.isSetWallpaperAllowed) false else {
            val flags = when (target) {
                0 -> WallpaperManager.FLAG_SYSTEM
                1 -> WallpaperManager.FLAG_LOCK
                else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
            }
            wm.setBitmap(bmp, null, true, flags); true
        }
    } catch (e: Exception) { false }

    @Suppress("DEPRECATION")
    fun saveToGallery(ctx: Context, bmp: Bitmap, title: String): Boolean = try {
        val safe = title.replace(Regex("[^A-Za-z0-9 _-]"), "").trim().ifBlank { "wallpaper" }.take(40) + "_" + System.currentTimeMillis()
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "$safe.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AuraGlass")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
            if (uri == null) false else {
                ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                true
            }
        } else {
            MediaStore.Images.Media.insertImage(ctx.contentResolver, bmp, safe, "Aura Glass") != null
        }
    } catch (e: Exception) { false }
}
