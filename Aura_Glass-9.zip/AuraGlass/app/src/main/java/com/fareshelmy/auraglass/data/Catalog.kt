package com.fareshelmy.auraglass.data

import android.text.Html
import com.fareshelmy.auraglass.BuildConfig
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.util.Auth
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Real remote catalogs. Nothing here is mocked:
 *  - Wikimedia Commons (default): free, no API key, every file carries a license + author.
 *  - Openverse: aggregator of openly licensed images; anonymous use is rate limited.
 * Only portrait images (height >= 1.2 x width) are kept so they suit phone wallpapers.
 */
object Catalog {
    data class Page(val items: List<Wallpaper>, val next: String?)

    /** Drops filler words ("wallpaper", "خلفيات") so "BMW wallpaper" searches for BMW. */
    fun normalize(q: String): String {
        val cleaned = q.trim().split(' ').filter { w -> w.lowercase() !in setOf("wallpaper", "wallpapers", "background", "backgrounds", "hd", "4k", "خلفية", "خلفيات") }.joinToString(" ").trim()
        return cleaned.ifBlank { q.trim() }
    }

    /**
     * Understands the query (Arabic/English, synonyms), asks the source with a clean English query, then KEEPS only results
     * that really match (title / categories / description) and ranks them by relevance. Loops over a few pages so a strict
     * filter still yields a useful page instead of unrelated filler.
     */
    suspend fun search(source: String, rawQuery: String, cursor: String?, portraitOnly: Boolean = true): Page = withContext(Dispatchers.IO) {
        val parsed = QueryParser.parse(rawQuery)
        val q = parsed.query
        val out = ArrayList<Wallpaper>()
        var next = cursor
        var tries = 0
        do {
            val page = when (source) {
                "openverse" -> Openverse.search(q, next, portraitOnly)
                "aura" -> AuraLibrary.search(q, next)
                else -> Commons.search(q, next, portraitOnly)
            }
            val scored = page.items.mapNotNull { w -> val sc = Relevance.score(w, parsed.groups); if (sc > 0) w to sc else null }
            out.addAll(scored.sortedByDescending { it.second }.map { it.first })
            next = page.next
            tries++
        } while (out.size < 8 && next != null && tries < 4)
        Page(out, next)
    }
}

private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

object Commons {
    private val noise = listOf(
        "cc-", "cc by", "files", "uploaded", "self-published", "quality image", "featured", "valued",
        "pages with", "media needing", "commons", "photos by", "images from", "taken with", "unknown",
        "wiki", "flickr", "pictures of the day", "license", "gfdl", "pd-", "public domain", "media of the day",
        "images by", "photographs by", "needing", "category", "(category)", "scans", "jpeg", "jpg", "raw",
    )

    fun search(q: String, cursor: String?, portraitOnly: Boolean = true): Catalog.Page {
        var offset = cursor?.toIntOrNull() ?: 0
        val out = ArrayList<Wallpaper>()
        var next: String?
        var tries = 0
        do {
            val url = "https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search" +
                "&gsrnamespace=6&gsrlimit=40&gsroffset=$offset&gsrsearch=${enc("$q filetype:bitmap")}" +
                "&prop=imageinfo&iiprop=url%7Csize%7Cmime%7Cextmetadata&iiurlwidth=600" +
                "&iiextmetadatafilter=LicenseShortName%7CLicenseUrl%7CArtist%7CCategories%7CImageDescription%7CObjectName"
            val root = JSONObject(Net.get(url))
            val pages = root.optJSONObject("query")?.optJSONObject("pages")
            val list = ArrayList<JSONObject>()
            if (pages != null) {
                val keys = pages.keys()
                while (keys.hasNext()) list.add(pages.getJSONObject(keys.next()))
            }
            list.sortBy { it.optInt("index") }
            for (p in list) parse(p, portraitOnly)?.let { out.add(it) }
            val cont = root.optJSONObject("continue")?.optInt("gsroffset", -1) ?: -1
            next = if (cont >= 0) cont.toString() else null
            offset = cont
            tries++
        } while (out.size < 10 && next != null && tries < 4)
        return Catalog.Page(out, next)
    }

    private fun parse(p: JSONObject, portraitOnly: Boolean): Wallpaper? {
        val ii = p.optJSONArray("imageinfo")?.optJSONObject(0) ?: return null
        val w = ii.optInt("width"); val h = ii.optInt("height")
        if (portraitOnly) { if (h < 1000 || h < w * 1.2) return null } else { if (maxOf(w, h) < 1200) return null }
        val mime = ii.optString("mime")
        if (mime != "image/jpeg" && mime != "image/png" && mime != "image/webp") return null
        val thumb = ii.optString("thumburl")
        if (thumb.isBlank()) return null
        val em = ii.optJSONObject("extmetadata")
        fun ev(k: String) = em?.optJSONObject(k)?.optString("value").orEmpty()
        val size = ii.optLong("size")
        val orig = ii.optString("url")
        val full = if (size in 1..12_000_000 && orig.startsWith("https")) orig else thumb.replace("/600px-", "/1600px-")
        val artist = Html.fromHtml(ev("Artist"), Html.FROM_HTML_MODE_LEGACY).toString().trim().take(80)
        val tags = ev("Categories").split('|').map { it.trim() }.filter { c ->
            c.length in 3..40 && !c[0].isDigit() && noise.none { c.lowercase().contains(it) }
        }.take(10)
        val title = p.optString("title").removePrefix("File:").substringBeforeLast('.').replace('_', ' ')
        val desc = Html.fromHtml(ev("ImageDescription"), Html.FROM_HTML_MODE_LEGACY).toString().trim()
        val meta = (ev("ObjectName") + " " + desc + " " + ev("Categories").replace('|', ' ')).trim().take(600)
        return Wallpaper(
            id = "commons:${p.optLong("pageid")}", title = title.ifBlank { "Untitled" }, thumb = thumb, full = full,
            creator = artist, license = ev("LicenseShortName"), licenseUrl = ev("LicenseUrl"),
            sourceUrl = ii.optString("descriptionurl"), tags = tags, source = "commons", width = w, height = h, meta = meta,
        )
    }
}

object Openverse {
    fun search(q: String, cursor: String?, portraitOnly: Boolean = true): Catalog.Page {
        val page = cursor?.toIntOrNull() ?: 1
        val url = "https://api.openverse.org/v1/images/?q=${enc(q)}&page=$page&page_size=20&mature=false" + (if (portraitOnly) "&aspect_ratio=tall" else "")
        val root = try { JSONObject(Net.get(url)) } catch (e: HttpException) {
            if (e.code == 400 && page > 1) return Catalog.Page(emptyList(), null) else throw e
        }
        val arr = root.optJSONArray("results") ?: JSONArray()
        val out = ArrayList<Wallpaper>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.optString("id")
            val thumb = o.optString("thumbnail").ifBlank { "https://api.openverse.org/v1/images/$id/thumb/" }
            val raw = o.optString("url")
            val full = if (raw.startsWith("https")) raw else thumb
            val tagArr = o.optJSONArray("tags")
            val tags = if (tagArr == null) emptyList() else List(tagArr.length()) { tagArr.getJSONObject(it).optString("name") }
            val ver = o.optString("license_version")
            out.add(Wallpaper(
                id = "openverse:$id", title = o.optString("title").ifBlank { "Untitled" }, thumb = thumb, full = full,
                creator = o.optString("creator"), license = ("CC " + o.optString("license").uppercase() + " " + ver).trim(),
                licenseUrl = o.optString("license_url"), sourceUrl = o.optString("foreign_landing_url"),
                tags = tags.filter { it.length in 3..30 }.take(10), source = "openverse",
                width = o.optInt("width"), height = o.optInt("height"), meta = tags.joinToString(" "),
            ))
        }
        val pageCount = root.optInt("page_count", page)
        return Catalog.Page(out, if (page < pageCount && page < 20) (page + 1).toString() else null)
    }
}

/**
 * "Aura Library": curated portrait photos served by YOUR backend (/wallpapers), which proxies Pexels with a
 * server-side key. Returns exact 9:16 (1080x1920) images. Needs AURA_BACKEND_URL and a PEXELS_API_KEY on the backend.
 */
object AuraLibrary {
    fun search(q: String, cursor: String?): Catalog.Page {
        val base = BuildConfig.AURA_BACKEND_URL.trimEnd('/')
        if (base.isBlank()) throw HttpException(503)
        val page = cursor?.toIntOrNull() ?: 1
        val root = JSONObject(Net.getJson("$base/wallpapers?q=${enc(q)}&page=$page", Auth.idToken))
        val arr = root.optJSONArray("items") ?: JSONArray()
        val out = ArrayList<Wallpaper>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val tagArr = o.optJSONArray("tags")
            out.add(Wallpaper(
                id = "aura:" + o.optString("id"), title = o.optString("title").ifBlank { "Untitled" },
                thumb = o.optString("thumb"), full = o.optString("full"), creator = o.optString("creator"),
                license = o.optString("license"), licenseUrl = o.optString("licenseUrl"), sourceUrl = o.optString("sourceUrl"),
                tags = if (tagArr == null) emptyList() else List(tagArr.length()) { tagArr.optString(it) },
                source = "aura", width = o.optInt("width"), height = o.optInt("height"),
            ))
        }
        return Catalog.Page(out, root.optString("next").ifBlank { null })
    }
}

/** Incrementally loaded, de-duplicated result list for one query. Survives rotation. */
class PagedSource(val query: String, private val sourceId: String, private val portraitOnly: Boolean = true) {
    val items = mutableStateListOf<Wallpaper>()
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<ErrKind?>(null); private set
    var end by mutableStateOf(false); private set
    var loaded by mutableStateOf(false); private set
    private var cursor: String? = null
    private val seen = HashSet<String>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private fun accept(w: Wallpaper): Boolean {
        if (!seen.add(w.id)) return false
        val key = dedupKey(w)
        return key.isEmpty() || seen.add(key)
    }

    suspend fun load() {
        if (loading || end) return
        loading = true; error = null
        try {
            val r = Catalog.search(sourceId, query, cursor, portraitOnly)
            r.items.forEach { if (accept(it)) items.add(it) }
            cursor = r.next
            if (r.next == null) end = true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = ErrKind.from(e)
        } finally { loading = false; loaded = true }
    }

    fun loadMore() { scope.launch { load() } }
    fun retry() { scope.launch { load() } }

    companion object {
        /** Exact-id + title/creator based near-duplicate detection (no perceptual hashing). */
        fun dedupKey(w: Wallpaper): String {
            val t = w.title.lowercase().filter { it.isLetter() }
            return if (t.length > 6) "t:$t|${w.creator.lowercase()}" else ""
        }
    }
}

object Sources {
    private val map = object : LinkedHashMap<String, PagedSource>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, PagedSource>?) = size > 30
    }
    fun get(query: String, portraitOnly: Boolean = true): PagedSource {
        val src = Store.activeSource
        return map.getOrPut("$src|$portraitOnly|${query.lowercase()}") { PagedSource(query, src, portraitOnly) }
    }
}

/** Selected wallpaper for the detail screen (kept in memory). */
object Session {
    var selected by mutableStateOf<Wallpaper?>(null)
    /** Gallery image waiting to be edited in the import editor. */
    var importUri by mutableStateOf<android.net.Uri?>(null)
    /** Wallpaper (online / offline / built-in) opened in the size editor. */
    var editWallpaper by mutableStateOf<Wallpaper?>(null)
}

/** Discovery queries. Edit these to change the home page content. */
object Discovery {
    data class Topic(val titleRes: Int, val query: String)
    const val carouselQuery = "landscape"
    const val feedQuery = "mobile wallpaper"
    val topics = listOf(
        Topic(R.string.t_nature, "nature"),
        Topic(R.string.t_landscape, "landscape"),
        Topic(R.string.t_space, "galaxy night sky"),
        Topic(R.string.t_cars, "car"),
        Topic(R.string.t_auto, "automotive photography"),
        Topic(R.string.t_tech, "technology"),
        Topic(R.string.t_arch, "architecture"),
        Topic(R.string.t_city, "city night"),
        Topic(R.string.t_abstract, "abstract"),
        Topic(R.string.t_minimal, "minimal"),
        Topic(R.string.t_amoled, "amoled dark"),
        Topic(R.string.t_black, "black background"),
        Topic(R.string.t_illus, "illustration anime"),
        Topic(R.string.t_gradient, "gradient"),
        Topic(R.string.t_dark, "dark"),
        Topic(R.string.t_luxury, "luxury"),
        Topic(R.string.t_islamic, "islamic architecture"),
        Topic(R.string.t_device, "smartphone"),
    )
}
