package com.fareshelmy.auraglass.data

import org.json.JSONArray
import org.json.JSONObject

/** One independent element of a user-built clock (hours, minutes, date, ...). x,y = centre as a fraction of the canvas. */
data class ClockEl(
    val id: Int,
    val type: String,               // HOURS MINUTES SECONDS DATE DAY HIJRI AMPM TIME
    val x: Float = 0.5f,
    val y: Float = 0.3f,
    val size: Float = 64f,
    val weight: Int = 500,
    val font: Int = 0,
    val color: Int = 0xFFFFFFFF.toInt(),
    val alpha: Float = 1f,
    val spacing: Float = 0f,
    val rotation: Float = 0f,
    val glow: Float = 0f,
    val visible: Boolean = true,
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("type", type).put("x", x.toDouble()).put("y", y.toDouble()).put("size", size.toDouble())
        .put("weight", weight).put("font", font).put("color", color).put("alpha", alpha.toDouble()).put("spacing", spacing.toDouble())
        .put("rotation", rotation.toDouble()).put("glow", glow.toDouble()).put("visible", visible)

    companion object {
        fun fromJson(o: JSONObject) = ClockEl(
            o.optInt("id"), o.optString("type", "TIME"), o.optDouble("x", 0.5).toFloat().coerceIn(0f, 1f), o.optDouble("y", 0.3).toFloat().coerceIn(0f, 1f),
            o.optDouble("size", 64.0).toFloat().coerceIn(8f, 400f), o.optInt("weight", 500).coerceIn(100, 900), o.optInt("font").coerceIn(0, 4),
            o.optInt("color", 0xFFFFFFFF.toInt()), o.optDouble("alpha", 1.0).toFloat().coerceIn(0f, 1f), o.optDouble("spacing", 0.0).toFloat(),
            o.optDouble("rotation", 0.0).toFloat(), o.optDouble("glow", 0.0).toFloat().coerceIn(0f, 60f), o.optBoolean("visible", true),
        )
    }
}

/** A saved Clock Creator design. */
data class ClockDesign(val name: String, val els: List<ClockEl>, val bgCat: Int, val bgVar: Int, val hour24: Boolean) {
    fun toJson(): JSONObject = JSONObject().put("name", name).put("bgCat", bgCat).put("bgVar", bgVar).put("hour24", hour24)
        .put("els", JSONArray(els.map { it.toJson() }))

    companion object {
        fun fromJson(o: JSONObject): ClockDesign {
            val a = o.optJSONArray("els") ?: JSONArray()
            return ClockDesign(o.optString("name"), List(a.length()) { ClockEl.fromJson(a.getJSONObject(it)) }, o.optInt("bgCat"), o.optInt("bgVar"), o.optBoolean("hour24", true))
        }
    }
}
