package com.fareshelmy.auraglass.util

import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tan

/**
 * Offline prayer-time calculation (astronomical formulas as popularised by praytimes.org).
 * No network and no GPS needed: the user picks a city. Asr uses the standard (Shafi'i/Maliki/Hanbali) shadow factor 1.
 * Accuracy: usually within a couple of minutes of official tables; official local timetables can differ
 * (rounding, elevation, local adjustments). City coordinates are approximate city-centre values.
 */
object Prayer {
    data class Method(val key: String, val nameEn: String, val nameAr: String, val fajr: Double, val isha: Double, val ishaMinutes: Int = 0)
    data class City(val en: String, val ar: String, val lat: Double, val lng: Double, val zone: String)
    data class Times(val fajr: Double, val sunrise: Double, val dhuhr: Double, val asr: Double, val maghrib: Double, val isha: Double) {
        /** The five obligatory prayers in order (sunrise excluded). */
        fun five() = listOf(fajr, dhuhr, asr, maghrib, isha)
    }

    val methods = listOf(
        Method("mwl", "Muslim World League", "رابطة العالم الإسلامي", 18.0, 17.0),
        Method("egypt", "Egyptian General Authority", "الهيئة المصرية العامة للمساحة", 19.5, 17.5),
        Method("makkah", "Umm al-Qura (Makkah)", "أم القرى (مكة المكرمة)", 18.5, 0.0, 90),
        Method("karachi", "University of Islamic Sciences, Karachi", "جامعة العلوم الإسلامية بكراتشي", 18.0, 18.0),
        Method("isna", "ISNA (North America)", "أمريكا الشمالية (ISNA)", 15.0, 15.0),
    )

    val cities = listOf(
        City("Mecca", "مكة المكرمة", 21.4225, 39.8262, "Asia/Riyadh"),
        City("Medina", "المدينة المنورة", 24.4686, 39.6142, "Asia/Riyadh"),
        City("Riyadh", "الرياض", 24.7136, 46.6753, "Asia/Riyadh"),
        City("Jeddah", "جدة", 21.4858, 39.1925, "Asia/Riyadh"),
        City("Dammam", "الدمام", 26.4207, 50.0888, "Asia/Riyadh"),
        City("Cairo", "القاهرة", 30.0444, 31.2357, "Africa/Cairo"),
        City("Alexandria", "الإسكندرية", 31.2001, 29.9187, "Africa/Cairo"),
        City("Dubai", "دبي", 25.2048, 55.2708, "Asia/Dubai"),
        City("Abu Dhabi", "أبو ظبي", 24.4539, 54.3773, "Asia/Dubai"),
        City("Doha", "الدوحة", 25.2854, 51.5310, "Asia/Qatar"),
        City("Kuwait City", "مدينة الكويت", 29.3759, 47.9774, "Asia/Kuwait"),
        City("Manama", "المنامة", 26.2285, 50.5860, "Asia/Bahrain"),
        City("Muscat", "مسقط", 23.5880, 58.3829, "Asia/Muscat"),
        City("Baghdad", "بغداد", 33.3152, 44.3661, "Asia/Baghdad"),
        City("Amman", "عمّان", 31.9454, 35.9284, "Asia/Amman"),
        City("Damascus", "دمشق", 33.5138, 36.2765, "Asia/Damascus"),
        City("Beirut", "بيروت", 33.8938, 35.5018, "Asia/Beirut"),
        City("Jerusalem", "القدس", 31.7683, 35.2137, "Asia/Jerusalem"),
        City("Sanaa", "صنعاء", 15.3694, 44.1910, "Asia/Aden"),
        City("Aden", "عدن", 12.7855, 45.0187, "Asia/Aden"),
        City("Khartoum", "الخرطوم", 15.5007, 32.5599, "Africa/Khartoum"),
        City("Tripoli", "طرابلس", 32.8872, 13.1913, "Africa/Tripoli"),
        City("Tunis", "تونس", 36.8065, 10.1815, "Africa/Tunis"),
        City("Algiers", "الجزائر", 36.7538, 3.0588, "Africa/Algiers"),
        City("Casablanca", "الدار البيضاء", 33.5731, -7.5898, "Africa/Casablanca"),
        City("Rabat", "الرباط", 34.0209, -6.8416, "Africa/Casablanca"),
        City("Istanbul", "إسطنبول", 41.0082, 28.9784, "Europe/Istanbul"),
        City("Ankara", "أنقرة", 39.9334, 32.8597, "Europe/Istanbul"),
        City("Karachi", "كراتشي", 24.8607, 67.0011, "Asia/Karachi"),
        City("Lahore", "لاهور", 31.5204, 74.3587, "Asia/Karachi"),
        City("Dhaka", "دكا", 23.8103, 90.4125, "Asia/Dhaka"),
        City("Jakarta", "جاكرتا", -6.2088, 106.8456, "Asia/Jakarta"),
        City("Kuala Lumpur", "كوالالمبور", 3.1390, 101.6869, "Asia/Kuala_Lumpur"),
        City("London", "لندن", 51.5072, -0.1276, "Europe/London"),
        City("Paris", "باريس", 48.8566, 2.3522, "Europe/Paris"),
        City("Berlin", "برلين", 52.5200, 13.4050, "Europe/Berlin"),
        City("New York", "نيويورك", 40.7128, -74.0060, "America/New_York"),
        City("Toronto", "تورنتو", 43.6532, -79.3832, "America/Toronto"),
        City("Los Angeles", "لوس أنجلوس", 34.0522, -118.2437, "America/Los_Angeles"),
        City("Sydney", "سيدني", -33.8688, 151.2093, "Australia/Sydney"),
    )

    private fun rad(d: Double) = Math.toRadians(d)
    private fun deg(r: Double) = Math.toDegrees(r)
    private fun fixAngle(a: Double): Double { var x = a % 360.0; if (x < 0) x += 360.0; return x }
    private fun fixHour(h: Double): Double { var x = h % 24.0; if (x < 0) x += 24.0; return x }

    private class Sun(val decl: Double, val eqt: Double)

    private fun sunPos(jd: Double): Sun {
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sin(rad(g)) + 0.020 * sin(rad(2 * g)))
        val e = 23.439 - 0.00000036 * d
        val ra = fixHour(deg(atan2(cos(rad(e)) * sin(rad(l)), cos(rad(l)))) / 15.0)
        return Sun(deg(asin(sin(rad(e)) * sin(rad(l)))), q / 15.0 - ra)
    }

    private fun julian(y0: Int, m0: Int, d: Int): Double {
        var y = y0; var m = m0
        if (m <= 2) { y -= 1; m += 12 }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + d + b - 1524.5
    }

    /** All results are local clock hours (0..24) for the given UTC offset [tz] in hours. */
    fun compute(date: LocalDate, lat: Double, lng: Double, tz: Double, m: Method): Times {
        val jd = julian(date.year, date.monthValue, date.dayOfMonth) - lng / (15.0 * 24.0)
        fun midDay(t: Double) = fixHour(12 - sunPos(jd + t).eqt)
        fun angleTime(angle: Double, t: Double, ccw: Boolean): Double {
            val decl = sunPos(jd + t).decl
            val x = (-sin(rad(angle)) - sin(rad(decl)) * sin(rad(lat))) / (cos(rad(decl)) * cos(rad(lat)))
            val tt = deg(acos(x.coerceIn(-1.0, 1.0))) / 15.0
            return midDay(t) + if (ccw) -tt else tt
        }
        fun asrTime(factor: Double, t: Double): Double {
            val decl = sunPos(jd + t).decl
            val angle = -deg(atan(1.0 / (factor + tan(rad(abs(lat - decl))))))
            return angleTime(angle, t, false)
        }
        var t = doubleArrayOf(5.0, 6.0, 12.0, 13.0, 18.0, 18.0)
        repeat(2) {
            val f = t.map { it / 24.0 }
            t = doubleArrayOf(
                angleTime(m.fajr, f[0], true),
                angleTime(0.833, f[1], true),
                midDay(f[2]),
                asrTime(1.0, f[3]),
                angleTime(0.833, f[4], false),
                if (m.ishaMinutes > 0) 0.0 else angleTime(m.isha, f[5], false),
            )
        }
        val adj = tz - lng / 15.0
        val maghrib = t[4] + adj
        val isha = if (m.ishaMinutes > 0) maghrib + m.ishaMinutes / 60.0 else t[5] + adj
        return Times(t[0] + adj, t[1] + adj, t[2] + adj, t[3] + adj, maghrib, isha)
    }

    fun forCity(date: LocalDate, city: City, m: Method): Times {
        val offsetHours = ZoneId.of(city.zone).rules.getOffset(date.atTime(12, 0).atZone(ZoneId.of(city.zone)).toInstant()).totalSeconds / 3600.0
        return compute(date, city.lat, city.lng, offsetHours, m)
    }

    /** Returns (index 0..4 into [Times.five], hours-from-now) of the next prayer, rolling to tomorrow's Fajr after Isha. */
    fun next(city: City, m: Method, nowHours: Double, today: LocalDate = LocalDate.now()): Pair<Int, Double> {
        val five = forCity(today, city, m).five()
        for (i in five.indices) if (five[i] > nowHours) return i to (five[i] - nowHours)
        val tomorrow = forCity(today.plusDays(1), city, m).five()
        return 0 to (tomorrow[0] + 24 - nowHours)
    }

    fun fmt(hours: Double, is24: Boolean = true): String {
        val total = ((hours * 60).roundToInt() % 1440 + 1440) % 1440
        val h = total / 60; val min = total % 60
        return if (is24) "%02d:%02d".format(h, min) else {
            val h12 = if (h % 12 == 0) 12 else h % 12
            "%d:%02d %s".format(h12, min, if (h < 12) "AM" else "PM")
        }
    }
}
