package com.fareshelmy.auraglass.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.painter.ColorPainter
import androidx.navigation.NavController
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.data.ErrKind
import com.fareshelmy.auraglass.data.LocalCatalog
import com.fareshelmy.auraglass.data.Session
import com.fareshelmy.auraglass.data.Store
import com.fareshelmy.auraglass.data.Wallpaper

/** Compose version of the built-in procedural wallpapers (same recipe as Images.renderLocal). */
@Composable
fun LocalArt(seed: Int, modifier: Modifier = Modifier) {
    val d = LocalCatalog.design(seed)
    Canvas(modifier.background(Color.Black)) {
        val w = size.width; val h = size.height
        drawRect(Brush.radialGradient(listOf(Color(d.c1).copy(alpha = 0.86f), Color.Transparent), Offset(w * d.cx, h * d.cy), w * 1.1f))
        if (d.kind >= 1) drawRect(Brush.radialGradient(listOf(Color(d.c2).copy(alpha = 0.78f), Color.Transparent), Offset(w * (1f - d.cx), h * (1f - d.cy * 0.8f)), w * 0.95f))
        if (d.kind == 2) drawRect(Brush.linearGradient(listOf(Color(d.c2).copy(alpha = 0.43f), Color.Transparent), Offset(0f, h), Offset(w, 0f)))
    }
}

/** Built-in generated wallpaper (cached render; 270x480 for cards, 720x1280 for the big preview). */
@Composable
fun GenArt(seed: Int, modifier: Modifier = Modifier, big: Boolean = false) {
    val bmp by androidx.compose.runtime.produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, seed, big) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
            (if (big) com.fareshelmy.auraglass.data.Walls.render(seed, 720, 1280) else com.fareshelmy.auraglass.data.Walls.thumb(seed)).asImageBitmap()
        }
    }
    val img = bmp
    if (img != null) androidx.compose.foundation.Image(img, null, modifier, contentScale = ContentScale.Crop) else Box(modifier.background(Color(0xFF111114)))
}

@Composable
fun WallpaperImage(wp: Wallpaper, modifier: Modifier = Modifier, full: Boolean = false) {
    if (wp.isGen) {
        GenArt(wp.seed, modifier, big = full)
    } else if (wp.isLocal) {
        LocalArt(wp.seed, modifier)
    } else {
        val ctx = LocalContext.current
        val url = if (full && wp.full.isNotBlank()) wp.full else wp.thumb
        AsyncImage(
            model = ImageRequest.Builder(ctx).data(url).crossfade(true).build(),
            contentDescription = wp.title,
            modifier = modifier,
            contentScale = ContentScale.Crop,
            placeholder = ColorPainter(Color(0xFF151515)),
            error = ColorPainter(Color(0xFF241A1A)),
        )
    }
}

fun openWallpaper(nav: NavController, wp: Wallpaper) {
    Session.selected = wp
    Store.addRecent(wp)
    nav.navigate("detail")
}

/** Every wallpaper card is 9:16 portrait; the image is center-cropped, never stretched. */
@Composable
fun WallCard(wp: Wallpaper, modifier: Modifier = Modifier, showTitle: Boolean = false, onClick: (Wallpaper) -> Unit) {
    Column(modifier) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(9f / 16f)
                .clip(RoundedCornerShape(Store.layout.cardCorner.dp))
                .background(Color(0xFF151515))
                .pressClickable { onClick(wp) }
                .semantics { contentDescription = wp.title },
        ) {
            WallpaperImage(wp, Modifier.fillMaxSize())
            if (Store.isFav(wp.id)) {
                Icon(Icons.Default.Favorite, null, tint = Color(0xFFFF5C7A), modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).size(18.dp))
            }
        }
        if (showTitle && Store.layout.showTitles) {
            Text(wp.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp, start = 4.dp, end = 4.dp))
        }
    }
}

@Composable
fun SkeletonCard(modifier: Modifier = Modifier) {
    Box(modifier.aspectRatio(9f / 16f).clip(RoundedCornerShape(18.dp)).background(Color(0xFF17171A)))
}

@Composable
fun ErrorBlock(kind: ErrKind, onRetry: () -> Unit, modifier: Modifier = Modifier) {
    val msg = when (kind) {
        ErrKind.OFFLINE -> R.string.err_offline
        ErrKind.RATE -> R.string.err_rate
        ErrKind.SERVER -> R.string.err_server
    }
    Column(modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(stringResource(msg), textAlign = TextAlign.Center, color = Pal.error)
        Button(onClick = onRetry, modifier = Modifier.padding(top = 10.dp)) { Text(stringResource(R.string.retry)) }
    }
}

@Composable
fun SectionHeader(kicker: String, title: String, onSearch: (() -> Unit)?) {
    Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(kicker, fontSize = 14.sp, color = Pal.muted)
            Text(title, fontSize = 24.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        }
        if (onSearch != null) {
            IconButton(onClick = onSearch, modifier = Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF3A3A36))) {
                Icon(Icons.Default.Search, stringResource(R.string.search))
            }
        }
    }
}

@Composable
fun ScreenTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, fontSize = 28.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = modifier.padding(vertical = 14.dp))
}

@Composable
fun Section(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().liquidGlass().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
}
