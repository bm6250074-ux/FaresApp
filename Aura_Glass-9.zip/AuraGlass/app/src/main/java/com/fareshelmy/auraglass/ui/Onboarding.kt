package com.fareshelmy.auraglass.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.data.Store
import kotlinx.coroutines.launch
import kotlin.math.abs

private data class IntroPage(val title: Int, val body: Int, val a: Color, val b: Color)

private val pages = listOf(
    IntroPage(R.string.intro1_title, R.string.intro1_body, Color(0xFF1B1464), Color(0xFF0F7B6C)),
    IntroPage(R.string.intro2_title, R.string.intro2_body, Color(0xFF4A148C), Color(0xFFAD1457)),
    IntroPage(R.string.intro3_title, R.string.intro3_body, Color(0xFF004D40), Color(0xFF1B5E20)),
    IntroPage(R.string.intro4_title, R.string.intro4_body, Color(0xFF0D47A1), Color(0xFF6A1B9A)),
)

@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    val state = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()
    val reduced = rememberReducedMotion()
    val t = if (reduced) 0.5f else {
        val inf = rememberInfiniteTransition(label = "bg")
        val v by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(5000, easing = LinearEasing), RepeatMode.Reverse), label = "t")
        v
    }
    val cur = pages[state.currentPage]
    Box(
        Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(lerp(cur.a, cur.b, t), lerp(cur.b, cur.a, t), Color.Black))
        )
    ) {
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Row {
                TextButton(onClick = { Store.setLanguage("ar"); com.fareshelmy.auraglass.ui.applyLanguage("ar") }) { Text("العربية") }
                TextButton(onClick = { Store.setLanguage("en"); com.fareshelmy.auraglass.ui.applyLanguage("en") }) { Text("English") }
            }
            if (state.currentPage < pages.lastIndex) {
                TextButton(onClick = { scope.launch { state.animateScrollToPage(pages.lastIndex) } }) { Text(stringResource(R.string.skip)) }
            }
        }
        HorizontalPager(state, Modifier.fillMaxSize()) { page ->
            val offset = (state.currentPage - page) + state.currentPageOffsetFraction
            Column(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 28.dp)
                    .graphicsLayer {
                        val f = 1f - abs(offset).coerceIn(0f, 1f)
                        alpha = 0.3f + 0.7f * f; scaleX = 0.92f + 0.08f * f; scaleY = 0.92f + 0.08f * f
                    },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
            ) {
                Box(Modifier.height(260.dp), contentAlignment = Alignment.Center) { Illustration(page, t) }
                Text(stringResource(pages[page].title), fontSize = 30.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 28.dp))
                Text(stringResource(pages[page].body), fontSize = 16.sp, textAlign = TextAlign.Center, color = Color(0xFFE0E0E8), modifier = Modifier.padding(top = 12.dp))
                Box(Modifier.height(120.dp))
            }
        }
        Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 16.dp)) {
                repeat(pages.size) { i ->
                    val sel = i == state.currentPage
                    Box(Modifier.height(8.dp).width(if (sel) 26.dp else 8.dp).clip(CircleShape).background(if (sel) Color.White else Color.White.copy(alpha = 0.4f)))
                }
            }
            if (state.currentPage == pages.lastIndex) {
                Button(onClick = onDone, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                    Text(stringResource(R.string.intro_enter), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                Button(onClick = { scope.launch { state.animateScrollToPage(state.currentPage + 1) } }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                    Text(stringResource(R.string.next), fontSize = 17.sp)
                }
            }
        }
    }
}

@Composable
private fun Illustration(page: Int, t: Float) {
    when (page) {
        0 -> Image(painterResource(R.drawable.aura_identity), null, Modifier.size(230.dp).graphicsLayer { rotationZ = (t - 0.5f) * 6f }.clip(RoundedCornerShape(32.dp)))
        1 -> Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf(3, 10, 17).forEachIndexed { i, seed ->
                LocalArt(seed, Modifier.width(88.dp).height(156.dp).graphicsLayer { translationY = (if (i == 1) -1 else 1) * (t - 0.5f) * 30f }.clip(RoundedCornerShape(18.dp)).border(1.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(18.dp)))
            }
        }
        2 -> Box(Modifier.size(220.dp).glass(CircleShape), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("☪", fontSize = 64.sp)
                Text(com.fareshelmy.auraglass.util.Hijri.format(), fontSize = 16.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 16.dp))
            }
        }
        else -> Column(Modifier.width(260.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(stringResource(R.string.intro4_q), modifier = Modifier.align(Alignment.End).glass(RoundedCornerShape(20.dp)).padding(14.dp))
            Text(stringResource(R.string.intro4_a), modifier = Modifier.glass(RoundedCornerShape(20.dp)).padding(14.dp).graphicsLayer { alpha = 0.6f + 0.4f * t })
        }
    }
}
