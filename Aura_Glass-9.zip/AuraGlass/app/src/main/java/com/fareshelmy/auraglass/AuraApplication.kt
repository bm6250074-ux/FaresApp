package com.fareshelmy.auraglass

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.fareshelmy.auraglass.data.Store
import okhttp3.OkHttpClient

/**
 * Wikimedia and Openverse reject requests without a descriptive User-Agent (HTTP 403/429),
 * which is why wallpaper thumbnails showed as empty dark tiles. Every image request now sends one.
 */
class AuraApplication : Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
    }

    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .okHttpClient {
            OkHttpClient.Builder().addInterceptor { chain ->
                chain.proceed(
                    chain.request().newBuilder()
                        .header("User-Agent", "AuraGlass/1.1 (Android; https://t.me/izxmy)")
                        .header("Accept", "image/*")
                        .build()
                )
            }.build()
        }
        .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.22).build() }
        .diskCache { DiskCache.Builder().directory(cacheDir.resolve("aura_img")).maxSizePercent(0.02).build() }
        .respectCacheHeaders(false)
        .crossfade(true)
        .build()
}
