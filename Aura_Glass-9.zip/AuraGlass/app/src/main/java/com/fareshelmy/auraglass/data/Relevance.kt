package com.fareshelmy.auraglass.data

/**
 * Query understanding + relevance filtering, applied to REAL results of every source.
 * A result is kept only if it genuinely matches the query (title, categories/tags, description);
 * unrelated items are dropped instead of filling the screen.
 */
object QueryParser {
    /** One group = one concept of the query with its accepted spellings/synonyms (any one may match). */
    data class Group(val variants: List<String>, val mandatory: Boolean)
    data class Parsed(val query: String, val groups: List<Group>)

    private val stop = setOf("wallpaper", "wallpapers", "background", "backgrounds", "hd", "4k", "8k", "uhd", "for", "the", "of", "and", "in", "with", "a", "an",
        "photo", "photos", "image", "images", "picture", "pictures", "pic", "pics", "خلفية", "خلفيات", "صورة", "صور", "عن", "في", "مع", "و", "من")

    private val phrases = listOf(
        "بي ام دبليو" to "bmw", "بي إم دبليو" to "bmw", "ريدمي نوت" to "redmi note", "نوت 14" to "note 14", "سامسونج جالكسي" to "samsung galaxy",
        "ايفون" to "iphone", "آيفون" to "iphone", "جالكسي" to "galaxy", "بيكسل" to "pixel", "ون بلس" to "oneplus", "لامبورجيني" to "lamborghini",
    )

    private val arEn = mapOf(
        "سيارة" to "car", "سيارات" to "car", "طبيعة" to "nature", "فضاء" to "space", "مجرة" to "galaxy", "مجرات" to "galaxy", "بحر" to "sea", "محيط" to "ocean",
        "جبل" to "mountain", "جبال" to "mountain", "غروب" to "sunset", "شروق" to "sunrise", "مسجد" to "mosque", "جامع" to "mosque", "كعبة" to "kaaba", "الكعبة" to "kaaba",
        "مكة" to "mecca", "المدينة" to "medina", "قمر" to "moon", "نجوم" to "stars", "نجمة" to "star", "ورد" to "flower", "زهور" to "flower", "زهرة" to "flower",
        "سماء" to "sky", "مدينة" to "city", "ليل" to "night", "ليلي" to "night", "اسود" to "black", "أسود" to "black", "ابيض" to "white", "أبيض" to "white",
        "احمر" to "red", "أحمر" to "red", "ازرق" to "blue", "أزرق" to "blue", "اخضر" to "green", "أخضر" to "green", "اصفر" to "yellow", "أصفر" to "yellow",
        "بنفسجي" to "purple", "وردي" to "pink", "برتقالي" to "orange", "ذهبي" to "gold", "فضي" to "silver", "رمادي" to "gray",
        "تقنية" to "technology", "تكنولوجيا" to "technology", "انمي" to "anime", "أنمي" to "anime", "حيوان" to "animal", "حيوانات" to "animal", "قطة" to "cat", "قط" to "cat",
        "كلب" to "dog", "اسد" to "lion", "أسد" to "lion", "نمر" to "tiger", "صقر" to "falcon", "حصان" to "horse", "صحراء" to "desert", "غابة" to "forest", "شلال" to "waterfall",
        "ثلج" to "snow", "مطر" to "rain", "شتاء" to "winter", "صيف" to "summer", "ربيع" to "spring", "خريف" to "autumn", "عمارة" to "architecture", "مبنى" to "building",
        "جسر" to "bridge", "برج" to "tower", "ناطحة" to "skyscraper", "كوكب" to "planet", "ارض" to "earth", "أرض" to "earth", "شمس" to "sun", "غيوم" to "clouds", "سحاب" to "clouds",
        "بحيرة" to "lake", "نهر" to "river", "شاطئ" to "beach", "جزيرة" to "island", "وادي" to "valley", "فن" to "art", "تجريدي" to "abstract", "بسيط" to "minimal",
        "تدرج" to "gradient", "فاخر" to "luxury", "فخم" to "luxury", "اسلامي" to "islamic", "إسلامي" to "islamic", "زجاج" to "glass", "رياضة" to "sports", "كرة" to "ball",
        "لعبة" to "game", "العاب" to "game", "ألعاب" to "game", "طائرة" to "airplane", "دراجة" to "motorcycle", "قطار" to "train", "سفينة" to "ship", "قلعة" to "castle",
        "شاومي" to "xiaomi", "ريدمي" to "redmi", "سامسونج" to "samsung", "هواوي" to "huawei", "مرسيدس" to "mercedes", "فيراري" to "ferrari", "تسلا" to "tesla",
        "بورش" to "porsche", "اودي" to "audi", "أودي" to "audi", "تويوتا" to "toyota", "نيسان" to "nissan", "فورد" to "ford", "لامبورغيني" to "lamborghini",
    )

    private val syn = mapOf(
        "car" to listOf("car", "cars", "automobile", "vehicle", "sedan", "coupe", "supercar"), "cars" to listOf("car", "cars", "automobile", "vehicle"),
        "sea" to listOf("sea", "ocean", "beach", "coast", "waves"), "ocean" to listOf("ocean", "sea", "waves"), "mountain" to listOf("mountain", "mountains", "peak", "alps"),
        "mountains" to listOf("mountain", "mountains", "peak"), "flower" to listOf("flower", "flowers", "floral", "blossom", "bloom"), "flowers" to listOf("flower", "flowers", "floral", "blossom"),
        "mosque" to listOf("mosque", "masjid", "minaret"), "kaaba" to listOf("kaaba", "kaba", "mecca", "makkah", "masjid al-haram"), "moon" to listOf("moon", "lunar"),
        "space" to listOf("space", "galaxy", "nebula", "cosmos", "astronomy", "milky way"), "galaxy" to listOf("galaxy", "milky way", "nebula"), "city" to listOf("city", "urban", "skyline", "downtown"),
        "night" to listOf("night", "nocturnal", "dusk"), "anime" to listOf("anime", "manga"), "technology" to listOf("technology", "tech", "circuit", "robot", "computer"), "tech" to listOf("technology", "tech", "circuit"),
        "sunset" to listOf("sunset", "sunrise", "dusk", "twilight"), "sunrise" to listOf("sunrise", "sunset", "dawn"), "forest" to listOf("forest", "woods", "woodland", "trees"),
        "desert" to listOf("desert", "dunes", "sahara"), "snow" to listOf("snow", "snowy", "winter"), "rain" to listOf("rain", "rainy", "raindrops"), "architecture" to listOf("architecture", "building", "buildings", "facade"),
        "building" to listOf("building", "buildings", "architecture"), "skyscraper" to listOf("skyscraper", "skyscrapers", "tower"), "clouds" to listOf("clouds", "cloud", "sky"), "waterfall" to listOf("waterfall", "falls", "cascade"),
        "abstract" to listOf("abstract", "abstraction"), "minimal" to listOf("minimal", "minimalist", "minimalism"), "black" to listOf("black"), "dark" to listOf("dark", "night"),
        "islamic" to listOf("islamic", "islam", "muslim", "arabesque"), "motorcycle" to listOf("motorcycle", "motorbike", "bike"), "airplane" to listOf("airplane", "aircraft", "plane", "jet"),
    )

    fun parse(raw: String): Parsed {
        var s = raw.trim().lowercase()
        for ((a, b) in phrases) s = s.replace(a, b)
        val tokens = s.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotBlank() }.filter { it !in stop }
        val en = tokens.map { t ->
            val noAl = if (t.startsWith("ال") && t.length > 3) t.removePrefix("ال") else t
            arEn[t] ?: arEn[noAl] ?: noAl
        }.filter { it.length >= 2 || it.any { ch -> ch.isDigit() } }
        if (en.isEmpty()) return Parsed(raw.trim(), emptyList())
        val groups = en.map { t -> Group((syn[t] ?: listOf(t)).distinct(), mandatory = t.any { it.isDigit() }) }
        return Parsed(en.joinToString(" "), groups)
    }
}

object Relevance {
    private fun hit(hay: String, v: String): Boolean {
        val i = hay.indexOf(v)
        if (i < 0) return false
        // avoid matching "car" inside "cartoon"/"scarf": require a word start; the end may extend (plurals)
        return i == 0 || !hay[i - 1].isLetterOrDigit()
    }

    /** 0 = unrelated (drop). Higher = better. */
    fun score(w: Wallpaper, groups: List<QueryParser.Group>): Int {
        if (groups.isEmpty()) return 1
        val title = w.title.lowercase()
        val tags = w.tags.joinToString(" ").lowercase()
        val meta = w.meta.lowercase()
        var matched = 0; var score = 0
        for (g in groups) {
            val s = when {
                g.variants.any { hit(title, it) } -> 3
                g.variants.any { hit(tags, it) } -> 2
                g.variants.any { hit(meta, it) } -> 1
                else -> 0
            }
            if (s == 0) { if (g.mandatory) return 0 } else { matched++; score += s }
        }
        val required = if (groups.size <= 2) groups.size else groups.size - 1
        if (matched < required) return 0
        val phrase = groups.joinToString(" ") { it.variants.first() }
        if (groups.size > 1 && title.contains(phrase)) score += 5
        return score
    }
}
