package com.fareshelmy.auraglass.ui

import android.content.Context
import android.provider.Settings
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.absoluteOffset
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.data.Store

@Composable
fun AuraTheme(content: @Composable () -> Unit) {
    val ap = Store.appearance
    val dark = resolveDark()
    val tint = Color(Store.glass.tint)
    val pal = makePalette(dark, ap.amoled, tint)
    val scheme = if (dark) darkColorScheme(
        primary = pal.accent, onPrimary = Color.Black, secondary = pal.accent,
        background = pal.bg, surface = Color(0xFF0E0E10), surfaceVariant = Color(0xFF1B1B1F), surfaceContainerHigh = Color(0xFF202024),
        onSurface = pal.onSurface, onBackground = pal.onSurface, onSurfaceVariant = pal.muted, outline = pal.outline,
    ) else lightColorScheme(
        primary = pal.accent, onPrimary = Color.White, secondary = pal.accent,
        background = pal.bg, surface = Color.White, surfaceVariant = Color(0xFFE6E7EC), surfaceContainerHigh = Color.White,
        onSurface = pal.onSurface, onBackground = pal.onSurface, onSurfaceVariant = pal.muted, outline = pal.outline,
    )
    MaterialTheme(colorScheme = scheme, typography = Typography().withFamily(AppFonts[ap.fontIdx.coerceIn(0, AppFonts.lastIndex)])) {
        CompositionLocalProvider(LocalPalette provides pal) { content() }
    }
}

/** Translucent glass surface: gradient fill, subtle border, rounded corners; all driven by Store.glass. */
fun Modifier.glass(shape: Shape? = null): Modifier = composed {
    val g = Store.glass
    val s = shape ?: RoundedCornerShape(g.corner.dp)
    this
        .clip(s)
        .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = g.alpha), Color.White.copy(alpha = g.alpha * 0.45f))))
        .border(1.dp, Color.White.copy(alpha = g.border), s)
}

@Composable
fun rememberReducedMotion(): Boolean {
    val ctx = LocalContext.current
    return remember {
        Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    }
}

/** Android's reduced-motion setting OR the in-app "Reduce motion" switch. (The start screen keeps using the system-only check above.) */
@Composable
fun rememberAppReducedMotion(): Boolean = rememberReducedMotion() || Store.liquid.reduceMotion

fun Context.toast(@StringRes id: Int) = Toast.makeText(this, id, Toast.LENGTH_SHORT).show()

/** Layers / glass-stack icon used for Aura Studio. */
val LayersIcon: androidx.compose.ui.graphics.vector.ImageVector by lazy {
    androidx.compose.ui.graphics.vector.ImageVector.Builder("AuraLayers", 24.dp, 24.dp, 24f, 24f).addPath(
        pathData = androidx.compose.ui.graphics.vector.PathParser()
            .parsePathString("M11.99,18.54l-7.37,-5.73L3,14.07l9,7l9,-7l-1.63,-1.27 -7.38,5.74zM12,16l7.36,-5.73L21,9l-9,-7 -9,7 1.63,1.27L12,16z").toNodes(),
        fill = SolidColor(Color.Black),
    ).build()
}

/** Fixed, tuned strength of the bar's liquid-glass lens (not user-adjustable). */
private const val BAR_LENS_STRENGTH = 0.72f

data class BarItem(val route: String, @StringRes val label: Int, val icon: ImageVector)

val barItems = listOf(
    BarItem("home", R.string.tab_home, Icons.Default.Home),
    BarItem("library", R.string.tab_library, Icons.Default.Favorite),
    BarItem("search", R.string.tab_search, Icons.Default.Search),   // centre
    BarItem("studio", R.string.tab_studio, LayersIcon),
    BarItem("profile", R.string.tab_profile, Icons.Default.Person),
)

/**
 * Floating glass capsule (reference: supplied KernelSU video + liquid-glass bar images).
 * Liquid Glass ON : real backdrop blur (Android 12+), dark glass tint, bright rim light, sliding lens bubble.
 * Liquid Glass OFF: solid dark capsule, solid indicator, no blur/transparency.
 */
@Composable
fun GlassBar(selected: String, onSelect: (String) -> Unit, backdrop: GraphicsLayer?, modifier: Modifier = Modifier) {
    val pal = LocalPalette.current
    val accent = pal.accent
    val l = Store.liquid
    val density = LocalDensity.current
    val n = barItems.size
    val xs = remember { mutableStateListOf<Float>().also { list -> repeat(n) { list.add(0f) } } }
    val ws = remember { mutableStateListOf<Float>().also { list -> repeat(n) { list.add(0f) } } }
    val hs = remember { mutableStateListOf<Float>().also { list -> repeat(n) { list.add(0f) } } }
    val selIdx = barItems.indexOfFirst { it.route == selected }.coerceAtLeast(0)
    val ax by animateFloatAsState(xs[selIdx], spring(dampingRatio = 0.72f, stiffness = 380f), label = "bubbleX")
    val aw by animateFloatAsState(ws[selIdx], spring(dampingRatio = 0.72f, stiffness = 380f), label = "bubbleW")
    val pill = RoundedCornerShape(34.dp)
    val bubbleShape = RoundedCornerShape(28.dp)
    val rim = if (pal.dark) Brush.linearGradient(listOf(Color.White.copy(alpha = 0.15f + 0.5f * l.reflect), Color.White.copy(alpha = 0.05f), Color.White.copy(alpha = 0.12f + 0.3f * l.reflect)))
        else Brush.linearGradient(listOf(Color.White.copy(alpha = 0.6f + 0.4f * l.reflect), Color.Black.copy(alpha = 0.08f), Color.White.copy(alpha = 0.4f + 0.4f * l.reflect)))
    val idle = pal.onSurface.copy(alpha = 0.85f)

    // Force LTR inside the bar so sizes/positions are identical in Arabic and English (labels stay Arabic).
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
    Box(
        modifier
            .navigationBarsPadding()
            .padding(bottom = 14.dp)
            .fillMaxWidth(0.94f).widthIn(max = 460.dp),
    ) {
        // Glass in its own SIBLING layer so the moving bubble never forces the lens to re-render.
        if (l.on) {
            Box(Modifier.matchParentSize().liquidLens(backdrop, pill, BAR_LENS_STRENGTH, pal.dark))
            Box(Modifier.matchParentSize().border(l.borderWidth.dp, rim, pill))
        } else {
            Box(
                Modifier.matchParentSize().clip(pill)
                    .background(if (pal.dark) Color(0xFF1B1B1F) else Color.White)
                    .border(1.dp, pal.onSurface.copy(alpha = 0.18f), pill)
            )
        }
        Box(Modifier.fillMaxWidth().padding(6.dp)) {
        if (Store.layout.indicator != 2 && aw > 0f && hs[selIdx] > 0f && barItems[selIdx].route != "search") {
            Box(
                Modifier
                    .absoluteOffset { IntOffset(ax.roundToInt(), 0) }
                    .size(with(density) { aw.toDp() }, with(density) { hs[selIdx].toDp() })
                    .clip(bubbleShape)
                    .background(accent.copy(alpha = if (l.on) 0.20f else 0.22f))
                    .then(
                        if (l.on && Store.layout.indicator == 0) Modifier.border(1.dp, Brush.verticalGradient(listOf((if (pal.dark) Color.White else Color.Black).copy(alpha = (if (pal.dark) 0.5f else 0.18f) * (0.4f + l.reflect)), Color.Transparent)), bubbleShape)
                        else Modifier
                    ),
            )
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            barItems.forEachIndexed { i, item ->
                val sel = i == selIdx
                val label = stringResource(item.label)
                if (item.route == "search") {
                    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { Box(
                        Modifier
                            .onGloballyPositioned { xs[i] = it.positionInParent().x; ws[i] = it.size.width.toFloat(); hs[i] = it.size.height.toFloat() }
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(accent.copy(alpha = if (sel) 0.95f else 0.78f))
                            .border(1.dp, Color.White.copy(alpha = 0.55f), CircleShape)
                            .pressClickable { onSelect(item.route) }
                            .semantics(mergeDescendants = true) { contentDescription = label; this.selected = sel },
                        contentAlignment = Alignment.Center,
                    ) { Icon(item.icon, null, tint = if (pal.dark) Color.Black else Color.White, modifier = Modifier.size(Store.layout.barIcon.dp + 2.dp)) } }
                    return@forEachIndexed
                }
                Column(
                    Modifier
                        .weight(1f)
                        .onGloballyPositioned {
                            xs[i] = it.positionInParent().x
                            ws[i] = it.size.width.toFloat()
                            hs[i] = it.size.height.toFloat()
                        }
                        .clip(bubbleShape)
                        .pressClickable { onSelect(item.route) }
                        .padding(horizontal = 2.dp, vertical = 8.dp)
                        .semantics(mergeDescendants = true) { contentDescription = label; this.selected = sel },
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(item.icon, null, tint = if (sel) accent else idle, modifier = Modifier.size(Store.layout.barIcon.dp))
                    if (Store.layout.barLabels) Text(label, fontSize = 10.sp, lineHeight = 12.sp, color = if (sel) accent else idle, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                }
            }
        }
        }
    }
    }
}
