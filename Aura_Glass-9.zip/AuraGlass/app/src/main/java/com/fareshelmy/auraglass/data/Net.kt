package com.fareshelmy.auraglass.data

import java.io.IOException
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

class RateLimitException : IOException("rate limited")
class HttpException(val code: Int) : IOException("HTTP $code")

enum class ErrKind {
    OFFLINE, RATE, SERVER;
    companion object {
        fun from(e: Throwable): ErrKind = when (e) {
            is UnknownHostException, is ConnectException, is SocketTimeoutException -> OFFLINE
            is RateLimitException -> RATE
            else -> SERVER
        }
    }
}

object Net {
    private const val UA = "AuraGlass/1.0 (Android; https://t.me/izxmy)"

    private fun open(url: String, timeout: Int): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = timeout; c.readTimeout = timeout
        c.setRequestProperty("User-Agent", UA)
        return c
    }

    private fun check(c: HttpURLConnection) {
        val code = c.responseCode
        if (code == 429) throw RateLimitException()
        if (code !in 200..299) throw HttpException(code)
    }

    fun get(url: String, timeout: Int = 15000): String {
        val c = open(url, timeout)
        try {
            c.setRequestProperty("Accept", "application/json")
            check(c)
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    fun getJson(url: String, bearer: String?, timeout: Int = 30000): String {
        val c = open(url, timeout)
        try {
            c.setRequestProperty("Accept", "application/json")
            if (!bearer.isNullOrBlank()) c.setRequestProperty("Authorization", "Bearer $bearer")
            check(c)
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    fun bytes(url: String, timeout: Int = 30000, maxBytes: Int = 40_000_000): ByteArray {
        val c = open(url, timeout)
        try {
            check(c)
            val out = java.io.ByteArrayOutputStream()
            c.inputStream.use { input ->
                val buf = ByteArray(16 * 1024); var total = 0
                while (true) {
                    val n = input.read(buf); if (n < 0) break
                    total += n; if (total > maxBytes) throw IOException("too large")
                    out.write(buf, 0, n)
                }
            }
            return out.toByteArray()
        } finally { c.disconnect() }
    }

}
