package com.fareshelmy.auraglass.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.data.Store
import com.fareshelmy.auraglass.util.Images
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalTime
import java.time.format.DateTimeFormatter

/**
 * Depth Studio = REAL layered parallax from layers the user supplies:
 *   background photo  ->  clock (middle layer)  ->  foreground cut-out (PNG with transparency).
 * There is NO automatic subject segmentation in this build (that needs an ML model such as ML Kit Subject
 * Segmentation, ~tens of MB through Google Play services). Parallax runs in the preview (accelerometer or
 * finger drag); applying it to the system/lock screen as a static composite is supported, live parallax as
 * a system wallpaper is not (that would require a WallpaperService).
 */
@Composable
fun DepthScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var bg by remember { mutableStateOf<Bitmap?>(null) }
    var fg by remember { mutableStateOf<Bitmap?>(null) }
    var depth by remember { mutableFloatStateOf(0.5f) }
    var tx by remember { mutableFloatStateOf(0f) }
    var ty by remember { mutableFloatStateOf(0f) }
    var useSensor by remember { mutableStateOf(false) }
    var clockMid by remember { mutableStateOf(true) }
    var clockInImage by remember { mutableStateOf(false) }
    var showSet by remember { mutableStateOf(false) }
    var segmenting by remember { mutableStateOf(false) }
    val timeText = remember { DateTimeFormatter.ofPattern("HH:mm").format(LocalTime.now()) }

    val pickBg = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch { val b = Images.loadUri(ctx, uri, 2048); if (b == null) ctx.toast(R.string.import_invalid) else bg = b }
    }
    val pickFg = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val b = Images.loadUri(ctx, uri, 2048)
            when {
                b == null -> ctx.toast(R.string.import_invalid)
                !b.hasAlpha() -> { ctx.toast(R.string.depth_no_alpha) }
                else -> fg = b
            }
        }
    }

    DisposableEffect(useSensor) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val nx = (-e.values[0] / 6f).coerceIn(-1f, 1f); val ny = (e.values[1] / 6f - 1f).coerceIn(-1f, 1f)
                tx += (nx - tx) * 0.15f; ty += (ny - ty) * 0.15f
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (useSensor && sensor != null) sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_GAME)
        onDispose { sm.unregisterListener(l) }
    }

    fun composite(): Bitmap? {
        val b = bg ?: return null
        val w = 1080; val h = 1920
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        Images.drawCover(c, b, w, h, zoom = 1.08f)
        if (clockMid && clockInImage) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE; textSize = 300f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); textAlign = Paint.Align.CENTER; setShadowLayer(18f, 0f, 4f, 0x88000000.toInt()) }
            c.drawText(timeText, w / 2f, h * 0.30f, p)
        }
        fg?.let { Images.drawCover(c, it, w, h, zoom = 1.08f) }
        return out
    }

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { BackTitle(nav, stringResource(R.string.depth_studio)) }
        item {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.fillMaxWidth(0.66f).aspectRatio(9f / 16f).clip(RoundedCornerShape(24.dp)).background(Color(0xFF111114))
                        .pointerInput(useSensor) {
                            if (!useSensor) detectDragGestures { _, d -> tx = (tx + d.x / 250f).coerceIn(-1f, 1f); ty = (ty + d.y / 250f).coerceIn(-1f, 1f) }
                        },
                ) {
                    val shift = 36f * depth
                    bg?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize().graphicsLayer { translationX = -tx * shift * 0.4f; translationY = -ty * shift * 0.4f; scaleX = 1.12f; scaleY = 1.12f }, contentScale = ContentScale.Crop) }
                    if (bg == null) Text(stringResource(R.string.depth_pick_bg), Modifier.align(Alignment.Center).padding(16.dp))
                    if (clockMid && bg != null) Text(timeText, Modifier.align(Alignment.TopCenter).padding(top = 60.dp).graphicsLayer { translationX = tx * shift * 0.5f; translationY = ty * shift * 0.5f }, fontSize = 64.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    fg?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize().graphicsLayer { translationX = tx * shift * 1.2f; translationY = ty * shift * 1.2f; scaleX = 1.12f; scaleY = 1.12f }, contentScale = ContentScale.Crop) }
                }
            }
        }
        item {
            Section {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { pickBg.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text(stringResource(R.string.depth_bg)) }
                    OutlinedButton(onClick = { pickFg.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text(stringResource(R.string.depth_fg)) }
                }
                Button(enabled = bg != null && !segmenting, onClick = {
                    val src = bg ?: return@Button
                    segmenting = true
                    scope.launch {
                        val cut = com.fareshelmy.auraglass.util.Segmentation.foreground(src)
                        segmenting = false
                        if (cut != null) { fg = cut; ctx.toast(R.string.depth_seg_ok) } else ctx.toast(R.string.depth_seg_fail)
                    }
                }) { Text(stringResource(if (segmenting) R.string.depth_seg_busy else R.string.depth_auto)) }
                Text(stringResource(R.string.depth_strength)); Slider(depth, { depth = it })
                Row(verticalAlignment = Alignment.CenterVertically) { Text(stringResource(R.string.depth_sensor), Modifier.weight(1f)); Switch(useSensor, { useSensor = it; tx = 0f; ty = 0f }) }
                Row(verticalAlignment = Alignment.CenterVertically) { Text(stringResource(R.string.depth_clock_mid), Modifier.weight(1f)); Switch(clockMid, { clockMid = it }) }
                Row(verticalAlignment = Alignment.CenterVertically) { Text(stringResource(R.string.depth_clock_in_image), Modifier.weight(1f)); Switch(clockInImage, { clockInImage = it }) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = bg != null, onClick = { showSet = true }) { Text(stringResource(R.string.set_wallpaper)) }
                    OutlinedButton(enabled = bg != null, onClick = {
                        scope.launch {
                            val ok = withContext(Dispatchers.Default) { composite() }?.let { withContext(Dispatchers.IO) { Images.saveToGallery(ctx, it, "depth") } } ?: false
                            ctx.toast(if (ok) R.string.saved_gallery else R.string.save_failed)
                        }
                    }) { Text(stringResource(R.string.download)) }
                }
                Text(stringResource(R.string.depth_honest_note), fontSize = 12.sp, color = Pal.muted)
            }
        }
    }

    if (showSet) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showSet = false },
            title = { Text(stringResource(R.string.set_wallpaper)) },
            text = { Text(stringResource(R.string.depth_set_note)) },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    showSet = false
                    scope.launch {
                        val ok = withContext(Dispatchers.Default) { composite() }?.let { withContext(Dispatchers.IO) { Images.setWallpaper(ctx, it, 2) } } ?: false
                        ctx.toast(if (ok) R.string.wallpaper_set else R.string.wallpaper_failed)
                    }
                }) { Text(stringResource(R.string.apply)) }
            },
            dismissButton = { androidx.compose.material3.TextButton(onClick = { showSet = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}
