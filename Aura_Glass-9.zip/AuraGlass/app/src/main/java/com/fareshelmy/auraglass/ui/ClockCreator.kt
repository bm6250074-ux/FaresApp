package com.fareshelmy.auraglass.ui

import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.data.ClockDesign
import com.fareshelmy.auraglass.data.ClockEl
import com.fareshelmy.auraglass.data.Store
import com.fareshelmy.auraglass.data.Walls
import com.fareshelmy.auraglass.util.Hijri
import com.fareshelmy.auraglass.util.Images
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

private val elTypes = listOf("HOURS", "MINUTES", "SECONDS", "DATE", "DAY", "HIJRI", "AMPM", "TIME")
private fun elName(t: String) = when (t) {
    "HOURS" -> R.string.el_hours; "MINUTES" -> R.string.el_minutes; "SECONDS" -> R.string.el_seconds; "DATE" -> R.string.el_date
    "DAY" -> R.string.el_day; "HIJRI" -> R.string.el_hijri; "AMPM" -> R.string.el_ampm; else -> R.string.el_time
}

private fun elText(e: ClockEl, now: LocalDateTime, h24: Boolean): String = localizeDigits(when (e.type) {
    "HOURS" -> DateTimeFormatter.ofPattern(if (h24) "HH" else "hh").format(now)
    "MINUTES" -> DateTimeFormatter.ofPattern("mm").format(now)
    "SECONDS" -> DateTimeFormatter.ofPattern("ss").format(now)
    "DATE" -> DateTimeFormatter.ofPattern("d MMM").format(now)
    "DAY" -> DateTimeFormatter.ofPattern("EEEE").format(now)
    "HIJRI" -> Hijri.format(now.toLocalDate())
    "AMPM" -> if (now.hour < 12) "AM" else "PM"
    else -> DateTimeFormatter.ofPattern(if (h24) "HH:mm" else "hh:mm").format(now)
})

private fun template(i: Int): List<ClockEl> = when (i) {
    1 -> listOf(ClockEl(1, "HOURS", 0.5f, 0.22f, 150f, 800), ClockEl(2, "MINUTES", 0.5f, 0.38f, 150f, 300, color = 0xFF7CF4C8.toInt()), ClockEl(3, "DATE", 0.5f, 0.52f, 22f, 500, spacing = 4f))
    2 -> listOf(ClockEl(1, "TIME", 0.5f, 0.28f, 84f, 200), ClockEl(2, "DAY", 0.5f, 0.38f, 20f, 500, spacing = 6f), ClockEl(3, "HIJRI", 0.5f, 0.43f, 16f, 400, alpha = 0.8f))
    3 -> listOf(ClockEl(1, "HOURS", 0.32f, 0.3f, 120f, 900, font = 2), ClockEl(2, "MINUTES", 0.68f, 0.3f, 120f, 200, font = 2), ClockEl(3, "DATE", 0.5f, 0.42f, 18f, 400, spacing = 8f))
    else -> emptyList()
}

/**
 * Clock Creator: start empty or from a template, add independent elements, drag them on the preview, restyle each one,
 * save several designs and reopen them. The preview is the real composition; "Save image" exports it as a STILL picture
 * (a still image cannot keep a live clock). Home-screen widgets and the system lock-screen clock are separate things.
 */
@Composable
fun ClockCreatorScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val now by rememberNow()
    var els by remember { mutableStateOf(template(1)) }
    var sel by remember { mutableIntStateOf(els.firstOrNull()?.id ?: -1) }
    var bgCat by remember { mutableIntStateOf(0) }
    var bgVar by remember { mutableIntStateOf(2) }
    var h24 by remember { mutableStateOf(true) }
    var large by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    val dens = LocalDensity.current
    var prevW by remember { mutableIntStateOf(1) }
    val cur = els.firstOrNull { it.id == sel }

    fun upd(f: (ClockEl) -> ClockEl) { els = els.map { if (it.id == sel) f(it) else it } }
    fun nextId() = (els.maxOfOrNull { it.id } ?: 0) + 1

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { BackTitle(nav, stringResource(R.string.creator_title)) }
        item {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.fillMaxWidth(if (large) 1f else 0.66f).aspectRatio(9f / 16f).clip(RoundedCornerShape(22.dp))
                        .onSizeChanged { prevW = it.width.coerceAtLeast(1) }
                        .pointerInput(sel) {
                            detectDragGestures { _, drag ->
                                if (sel != -1) els = els.map { if (it.id == sel) it.copy(x = (it.x + drag.x / size.width).coerceIn(0f, 1f), y = (it.y + drag.y / size.height).coerceIn(0f, 1f)) else it }
                            }
                        },
                ) {
                    GenArt((bgCat * 100) + bgVar, Modifier.fillMaxSize(), big = true)
                    els.filter { it.visible }.forEach { e ->
                        Text(
                            elText(e, now, h24),
                            style = TextStyle(
                                color = Color(e.color).copy(alpha = e.alpha), fontSize = e.size.sp, fontWeight = FontWeight(e.weight),
                                fontFamily = AppFonts[e.font.coerceIn(0, AppFonts.lastIndex)], letterSpacing = e.spacing.sp,
                                shadow = if (e.glow > 0f) Shadow(Color(e.color), Offset.Zero, e.glow) else null,
                            ),
                            modifier = Modifier
                                .layout { m, c ->
                                    val p = m.measure(c.copy(minWidth = 0, minHeight = 0))
                                    layout(c.maxWidth, c.maxHeight) { p.place((e.x * c.maxWidth - p.width / 2f).toInt(), (e.y * c.maxHeight - p.height / 2f).toInt()) }
                                }
                                .graphicsLayer { rotationZ = e.rotation },
                        )
                    }
                }
            }
        }
        item { Text(stringResource(R.string.creator_hint), fontSize = 12.sp, color = Pal.muted) }

        item {
            Section {
                Text(stringResource(R.string.creator_start), fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(R.string.tpl_empty, R.string.tpl_stacked, R.string.tpl_line, R.string.tpl_split).forEachIndexed { i, r ->
                        OutlinedButton(onClick = { els = template(i); sel = els.firstOrNull()?.id ?: -1 }) { Text(stringResource(r), fontSize = 12.sp) }
                    }
                }
                Text(stringResource(R.string.creator_add), color = Pal.muted)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(elTypes) { t -> OutlinedButton(onClick = { val id = nextId(); els = els + ClockEl(id, t, 0.5f, 0.6f, if (t == "TIME" || t == "HOURS" || t == "MINUTES") 72f else 22f); sel = id }) { Text("+ " + stringResource(elName(t)), fontSize = 12.sp) } }
                }
                Text(stringResource(R.string.creator_elements), color = Pal.muted)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(els, key = { it.id }) { e -> FilterChip(selected = sel == e.id, onClick = { sel = e.id }, label = { Text(stringResource(elName(e.type))) }) }
                }
            }
        }

        if (cur != null) item {
            Section {
                Text(stringResource(elName(cur.type)), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Row(verticalAlignment = Alignment.CenterVertically) { Text(stringResource(R.string.el_visible), Modifier.weight(1f)); Switch(cur.visible, { v -> upd { it.copy(visible = v) } }) }
                Text(stringResource(R.string.el_size)); Slider(cur.size, { v -> upd { it.copy(size = v) } }, valueRange = 10f..320f)
                Text(stringResource(R.string.el_weight) + ": " + cur.weight); Slider(cur.weight / 100f, { v -> upd { it.copy(weight = (Math.round(v) * 100).coerceIn(100, 900)) } }, valueRange = 1f..9f, steps = 7)
                Text(stringResource(R.string.clock_font))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf(R.string.font_default, R.string.font_sans, R.string.font_serif, R.string.font_mono, R.string.font_cursive).withIndex().toList()) { (i, r) ->
                        FilterChip(selected = cur.font == i, onClick = { upd { it.copy(font = i) } }, label = { Text(stringResource(r), fontFamily = AppFonts[i]) })
                    }
                }
                Text(stringResource(R.string.clock_color)); HsvPicker(cur.color) { c -> upd { it.copy(color = c) } }
                Text(stringResource(R.string.el_alpha)); Slider(cur.alpha, { v -> upd { it.copy(alpha = v) } }, valueRange = 0.05f..1f)
                Text(stringResource(R.string.el_spacing)); Slider(cur.spacing, { v -> upd { it.copy(spacing = v) } }, valueRange = -4f..30f)
                Text(stringResource(R.string.el_rotation)); Slider(cur.rotation, { v -> upd { it.copy(rotation = v) } }, valueRange = -90f..90f)
                Text(stringResource(R.string.el_glow)); Slider(cur.glow, { v -> upd { it.copy(glow = v) } }, valueRange = 0f..40f)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { upd { it.copy(x = 0.5f) } }) { Text(stringResource(R.string.el_center_x)) }
                    OutlinedButton(onClick = { val id = nextId(); els = els + cur.copy(id = id, y = (cur.y + 0.06f).coerceAtMost(0.95f)); sel = id }) { Text(stringResource(R.string.el_duplicate)) }
                    OutlinedButton(onClick = { els = els.filter { it.id != sel }; sel = els.firstOrNull()?.id ?: -1 }) { Text(stringResource(R.string.remove)) }
                }
            }
        }

        item {
            Section {
                Text(stringResource(R.string.creator_canvas), fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(Walls.cats.withIndex().toList()) { (i, c) -> FilterChip(selected = bgCat == i, onClick = { bgCat = i }, label = { Text(stringResource(c.titleRes)) }) }
                }
                Text(stringResource(R.string.creator_variant) + ": " + (bgVar + 1)); Slider(bgVar.toFloat(), { v -> bgVar = v.toInt().coerceIn(0, Walls.PER - 1) }, valueRange = 0f..(Walls.PER - 1).toFloat(), steps = Walls.PER - 2)
                Row(verticalAlignment = Alignment.CenterVertically) { Text(stringResource(R.string.clock_24h), Modifier.weight(1f)); Switch(h24, { h24 = it }) }
                Row(verticalAlignment = Alignment.CenterVertically) { Text(stringResource(R.string.creator_large), Modifier.weight(1f)); Switch(large, { large = it }) }
            }
        }

        item {
            Section {
                Text(stringResource(R.string.creator_save_title), fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text(stringResource(R.string.preset_name)) })
                    Button(onClick = {
                        val n = name.trim().ifBlank { "Clock " + (Store.clockDesigns.size + 1) }
                        Store.saveClockDesign(ClockDesign(n, els, bgCat, bgVar, h24)); name = ""; ctx.toast(R.string.creator_saved)
                    }) { Text(stringResource(R.string.save_preset)) }
                }
                Store.clockDesigns.toList().forEach { d ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(d.name, Modifier.weight(1f))
                        TextButton(onClick = { els = d.els; sel = d.els.firstOrNull()?.id ?: -1; bgCat = d.bgCat.coerceIn(0, Walls.cats.lastIndex); bgVar = d.bgVar.coerceIn(0, Walls.PER - 1); h24 = d.hour24 }) { Text(stringResource(R.string.creator_open)) }
                        TextButton(onClick = { Store.deleteClockDesign(d) }) { Text(stringResource(R.string.remove)) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        scope.launch {
                            val bmp = try {
                                withContext(Dispatchers.Default) { renderClock(els, java.time.LocalDateTime.now(), h24, bgCat * 100 + bgVar, 1080f / prevW, dens.density, dens.fontScale) }
                            } catch (e: Exception) { null }
                            val ok = bmp != null && withContext(Dispatchers.IO) { Images.saveToGallery(ctx, bmp, "clock") }
                            ctx.toast(if (ok) R.string.saved_gallery else R.string.save_failed)
                        }
                    }) { Text(stringResource(R.string.creator_export)) }
                }
                Text(stringResource(R.string.creator_note), fontSize = 12.sp, color = Pal.muted)
            }
        }
    }
}


/** Draws the same composition as the preview at 1080x1920 with the Android canvas (a still image: the time is frozen). */
private fun renderClock(els: List<ClockEl>, now: LocalDateTime, h24: Boolean, seed: Int, k: Float, density: Float, fontScale: Float): Bitmap {
    val w = 1080; val h = 1920
    val bmp = Walls.render(seed, w, h)
    val c = Canvas(bmp)
    els.filter { it.visible }.forEach { e ->
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val base = when (e.font) {
            1 -> Typeface.SANS_SERIF; 2 -> Typeface.SERIF; 3 -> Typeface.MONOSPACE
            4 -> Typeface.create("cursive", Typeface.NORMAL); else -> Typeface.DEFAULT
        }
        paint.typeface = if (Build.VERSION.SDK_INT >= 28) Typeface.create(base, e.weight, false)
        else Typeface.create(base, if (e.weight >= 600) Typeface.BOLD else Typeface.NORMAL)
        paint.textSize = e.size * density * fontScale * k
        paint.color = e.color
        paint.alpha = (e.alpha * 255).toInt().coerceIn(0, 255)
        paint.textAlign = Paint.Align.CENTER
        paint.letterSpacing = if (e.size > 0f) e.spacing / e.size else 0f
        if (e.glow > 0f) paint.setShadowLayer(e.glow * density * k, 0f, 0f, e.color)
        val x = e.x * w
        val cy = e.y * h
        val y = cy - (paint.ascent() + paint.descent()) / 2f
        c.save(); c.rotate(e.rotation, x, cy)
        c.drawText(elText(e, now, h24), x, y, paint)
        c.restore()
    }
    return bmp
}
