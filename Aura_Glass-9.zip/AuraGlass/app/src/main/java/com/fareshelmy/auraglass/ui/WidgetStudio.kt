package com.fareshelmy.auraglass.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.data.Store
import com.fareshelmy.auraglass.util.Images
import com.fareshelmy.auraglass.widgets.BatteryWidget
import com.fareshelmy.auraglass.widgets.ClockAnalogWidget
import com.fareshelmy.auraglass.widgets.ClockDigitalWidget
import com.fareshelmy.auraglass.widgets.CustomTextWidget
import com.fareshelmy.auraglass.widgets.DayWidget
import com.fareshelmy.auraglass.widgets.ForecastWidget
import com.fareshelmy.auraglass.widgets.GalleryWidget
import com.fareshelmy.auraglass.widgets.MonthWidget
import com.fareshelmy.auraglass.widgets.NotesWidget
import com.fareshelmy.auraglass.widgets.PhotoWidget
import com.fareshelmy.auraglass.widgets.WeatherRepo
import com.fareshelmy.auraglass.widgets.WeatherWidget
import com.fareshelmy.auraglass.widgets.WeekdayWidget
import com.fareshelmy.auraglass.widgets.Widgets
import com.fareshelmy.auraglass.widgets.widgetPhotoFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val studioKinds = listOf(
    WidgetKind("weather", R.string.wk_weather, WeatherWidget::class.java),
    WidgetKind("forecast", R.string.wk_forecast, ForecastWidget::class.java),
    WidgetKind("battery", R.string.wk_battery, BatteryWidget::class.java),
    WidgetKind("day", R.string.wk_day, DayWidget::class.java),
    WidgetKind("weekday", R.string.wk_weekday, WeekdayWidget::class.java),
    WidgetKind("month", R.string.wk_month, MonthWidget::class.java, variants = false),
    WidgetKind("customtext", R.string.wk_text, CustomTextWidget::class.java),
    WidgetKind("notes", R.string.wk_notes, NotesWidget::class.java),
    WidgetKind("photo", R.string.wk_photo, PhotoWidget::class.java, variants = false),
    WidgetKind("gallery", R.string.wk_gallery, GalleryWidget::class.java, variants = false),
)

/**
 * Widget Studio: real home-screen widgets (clock, weather, calendar, battery, text, notes, photo, gallery).
 * Every card shows the actual widget; colours/size/transparency come from the shared style below.
 */
@Composable
fun WidgetStudioScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var weatherMsg by remember { mutableStateOf<Int?>(null) }
    val ws = Store.widgetStyle

    // Fresh weather for the previews (network; failure just keeps the last cached data)
    LaunchedEffect(Store.cityIndex) {
        weatherMsg = try { withContext(Dispatchers.IO) { WeatherRepo.refresh(ctx) }; null } catch (e: Exception) { R.string.weather_offline }
    }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val bmp = Images.loadUri(ctx, uri, 1200)
            val ok = bmp != null && withContext(Dispatchers.IO) {
                try { widgetPhotoFile(ctx).outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }; true } catch (e: Exception) { false }
            }
            if (ok) { Widgets.updateAll(ctx); ctx.toast(R.string.widget_photo_saved) } else ctx.toast(R.string.import_invalid)
        }
    }

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { BackTitle(nav, stringResource(R.string.widget_studio)) }
        item { Text(stringResource(R.string.widget_studio_note), fontSize = 12.sp, color = Pal.muted) }
        item {
            Section {
                Text(stringResource(R.string.widget_style), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(stringResource(R.string.clock_color)); ColorRow(ws.textColor) { Store.updateWidgetStyle(ws.copy(textColor = it)) }
                Text(stringResource(R.string.widget_bg_color)); HsvPicker(ws.bgColor) { Store.updateWidgetStyle(ws.copy(bgColor = it)) }
                Text(stringResource(R.string.clock_bg)); Slider(ws.bgAlpha, { Store.updateWidgetStyle(ws.copy(bgAlpha = it)) }, valueRange = 0f..1f)
                Text(stringResource(R.string.clock_size)); Slider(ws.scale, { Store.updateWidgetStyle(ws.copy(scale = it)) }, valueRange = 0.7f..1.5f)
                Button(onClick = { Widgets.updateAll(ctx); ctx.toast(R.string.widgets_updated) }) { Text(stringResource(R.string.apply_widgets)) }
            }
        }
        weatherMsg?.let { m -> item { Text(stringResource(m), fontSize = 12.sp, color = Pal.warn) } }
        item {
            Section {
                Text(stringResource(R.string.wk_text), fontWeight = FontWeight.Bold)
                OutlinedTextField(Store.widgetText, { Store.setWidgetText(it) }, Modifier.fillMaxWidth(), placeholder = { Text(stringResource(R.string.widget_text_hint)) }, maxLines = 3)
                Text(stringResource(R.string.wk_notes), fontWeight = FontWeight.Bold)
                OutlinedTextField(Store.widgetNote, { Store.setWidgetNote(it) }, Modifier.fillMaxWidth(), placeholder = { Text(stringResource(R.string.widget_note_hint)) }, maxLines = 6)
                Button(onClick = { Widgets.updateAll(ctx); ctx.toast(R.string.widgets_updated) }) { Text(stringResource(R.string.apply_widgets)) }
                Button(onClick = { pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text(stringResource(R.string.widget_pick_photo)) }
            }
        }
        item { WidgetDesignCard(WidgetKind("clockdigital", R.string.wk_clock_digital, ClockDigitalWidget::class.java, variants = false)) }
        item { WidgetDesignCard(WidgetKind("clockanalog", R.string.wk_clock_analog, ClockAnalogWidget::class.java, variants = false)) }
        studioKinds.forEach { k -> item(key = "sk_" + k.key) { WidgetDesignCard(k) } }
    }
}
