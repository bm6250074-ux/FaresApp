package com.fareshelmy.auraglass.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import com.fareshelmy.auraglass.util.Images
import com.fareshelmy.auraglass.util.ScreenCapture
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.setValue
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.data.ClockStyle
import com.fareshelmy.auraglass.data.Store
import com.fareshelmy.auraglass.util.Hijri
import com.fareshelmy.auraglass.widgets.ClockAnalogWidget
import com.fareshelmy.auraglass.widgets.ClockDigitalWidget
import com.fareshelmy.auraglass.widgets.Widgets
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.cos
import kotlin.math.sin

val clockNames = listOf(
    R.string.clock_d0, R.string.clock_d1, R.string.clock_d2, R.string.clock_d3, R.string.clock_d4, R.string.clock_d5,
    R.string.clock_d6, R.string.clock_d7, R.string.clock_d8, R.string.clock_d9, R.string.clock_d10,
    R.string.clock_d11, R.string.clock_d12, R.string.clock_d13, R.string.clock_d14, R.string.clock_d15, R.string.clock_d16,
    R.string.clock_d17, R.string.clock_d18, R.string.clock_d19, R.string.clock_d20, R.string.clock_d21, R.string.clock_d22, R.string.clock_d23,
    R.string.clock_d24, R.string.clock_d25, R.string.clock_d26, R.string.clock_d27, R.string.clock_d28, R.string.clock_d29,
    R.string.clock_d30, R.string.clock_d31, R.string.clock_d32, R.string.clock_d33, R.string.clock_d34, R.string.clock_d35,
)
private val fonts = listOf(FontFamily.Default, FontFamily.SansSerif, FontFamily.Serif, FontFamily.Monospace, FontFamily.Cursive)
private val fontNames = listOf(R.string.font_default, R.string.font_sans, R.string.font_serif, R.string.font_mono, R.string.font_cursive)

@Composable
fun rememberNow(): State<LocalDateTime> = produceState(LocalDateTime.now()) {
    while (true) { value = LocalDateTime.now(); delay(1000) }
}

private fun arabicDigits(s: String) = s.map { if (it in '0'..'9') '٠' + (it - '0') else it }.joinToString("")

/** Eleven structurally different designs (layout, drawing and content differ, not just colours). */
@Composable
fun ClockFace(st: ClockStyle, now: LocalDateTime, modifier: Modifier = Modifier) {
    val s = st.scale
    val col = Color(st.color); val acc = Color(st.accent)
    val ff = fonts[st.font.coerceIn(0, fonts.lastIndex)]
    val hmRaw = DateTimeFormatter.ofPattern(if (st.hour24) "HH:mm" else "hh:mm").format(now)
    val hm = localizeDigits(hmRaw)
    val hh = hm.substringBefore(':'); val mm = hm.substringAfter(':')
    val date = localizeDigits(DateTimeFormatter.ofPattern("EEE, d MMM").format(now))
    val ha = when (st.align) { 0 -> Alignment.Start; 2 -> Alignment.End; else -> Alignment.CenterHorizontally }
    val ta = when (st.align) { 0 -> TextAlign.Start; 2 -> TextAlign.End; else -> TextAlign.Center }
    Column(modifier, horizontalAlignment = ha, verticalArrangement = Arrangement.Center) {
        when (st.design) {
            0 -> { Text(hm, color = col, fontFamily = ff, fontSize = (64 * s).sp, fontWeight = FontWeight.Light); Text(date, color = acc, fontFamily = ff, fontSize = (16 * s).sp) }
            1 -> { Text(hh, color = col, fontFamily = ff, fontSize = (110 * s).sp, fontWeight = FontWeight.Black, lineHeight = (96 * s).sp, textAlign = ta); Text(mm, color = acc, fontFamily = ff, fontSize = (110 * s).sp, fontWeight = FontWeight.Black, lineHeight = (96 * s).sp, textAlign = ta) }
            2, 3 -> {
                val classic = st.design == 2
                Canvas(Modifier.size((220 * s).dp)) {
                    val c = center; val r = size.minDimension / 2f
                    if (classic) {
                        drawCircle(col, r, style = Stroke(3f))
                        for (i in 0 until 12) {
                            val a = Math.toRadians(i * 30.0 - 90)
                            drawLine(col, c + Offset(cos(a).toFloat(), sin(a).toFloat()) * (r * 0.86f), c + Offset(cos(a).toFloat(), sin(a).toFloat()) * (r * 0.96f), if (i % 3 == 0) 5f else 2f)
                        }
                    } else drawCircle(col.copy(alpha = 0.9f), 7f, c - Offset(0f, r * 0.9f))
                    val sec = now.second; val min = now.minute + sec / 60.0; val hr = (now.hour % 12) + min / 60.0
                    fun hand(deg: Double, len: Float, w: Float, color: Color) {
                        val a = Math.toRadians(deg - 90)
                        drawLine(color, c, c + Offset(cos(a).toFloat(), sin(a).toFloat()) * (r * len), w, StrokeCap.Round)
                    }
                    hand(hr * 30, 0.5f, if (classic) 8f else 14f, col)
                    hand(min * 6, 0.78f, if (classic) 5f else 9f, col)
                    if (classic) hand(sec * 6.0, 0.88f, 2f, acc) else drawCircle(acc, 9f, c)
                }
            }
            4 -> Row(horizontalArrangement = Arrangement.spacedBy((8 * s).dp)) {
                (hh + mm).forEach { ch ->
                    Box(Modifier.size((52 * s).dp, (78 * s).dp).clip(RoundedCornerShape(14.dp)).background(acc.copy(alpha = 0.28f)).border(1.dp, acc, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                        Text(ch.toString(), color = col, fontFamily = ff, fontSize = (44 * s).sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            5 -> Box(contentAlignment = Alignment.Center) {
                Canvas(Modifier.size((230 * s).dp)) {
                    val sw = 10f * s
                    drawArc(col.copy(alpha = 0.18f), 0f, 360f, false, style = Stroke(sw))
                    drawArc(acc, -90f, 360f * (now.second + 1) / 60f, false, style = Stroke(sw, cap = StrokeCap.Round))
                }
                Text(hm, color = col, fontFamily = ff, fontSize = (46 * s).sp, fontWeight = FontWeight.Medium)
            }
            6 -> Row(horizontalArrangement = Arrangement.spacedBy((10 * s).dp)) {
                listOf(hh, mm).forEach { part ->
                    Box(Modifier.size((96 * s).dp, (124 * s).dp).clip(RoundedCornerShape(18.dp)).background(Color(0xFF1E1E22)), contentAlignment = Alignment.Center) {
                        Text(part, color = col, fontFamily = ff, fontSize = (64 * s).sp, fontWeight = FontWeight.Bold)
                        Box(Modifier.fillMaxWidth().height(2.dp).background(Color.Black))
                    }
                }
            }
            7 -> { Text(arabicDigits(hm), color = col, fontFamily = ff, fontSize = (60 * s).sp, fontWeight = FontWeight.Bold); Text(Hijri.format(now.toLocalDate()), color = acc, fontSize = (17 * s).sp) }
            8 -> Text(DateTimeFormatter.ofPattern(if (st.hour24) "HH:mm:ss" else "hh:mm:ss").format(now), color = col,
                style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = (40 * s).sp, shadow = Shadow(acc, Offset.Zero, 28f)))
            9 -> {
                val pct = ((now.hour * 60 + now.minute) / 14.4f).toInt()
                Text(hm, color = col, fontFamily = ff, fontSize = (54 * s).sp, fontWeight = FontWeight.Light)
                Box(Modifier.width((200 * s).dp).height(8.dp).clip(RoundedCornerShape(4.dp)).background(col.copy(alpha = 0.2f))) {
                    Box(Modifier.fillMaxHeight().fillMaxWidth((pct / 100f).coerceIn(0f, 1f)).background(acc))
                }
                Text("$pct%", color = acc, fontSize = (14 * s).sp, modifier = Modifier.padding(top = 4.dp))
            }
            10 -> {
                Text(localizeDigits(now.dayOfMonth.toString()), color = acc, fontFamily = ff, fontSize = (120 * s).sp, fontWeight = FontWeight.Black, lineHeight = (110 * s).sp)
                Text(DateTimeFormatter.ofPattern("EEEE").format(now), color = col, fontFamily = ff, fontSize = (22 * s).sp)
                Text(hm, color = col.copy(alpha = 0.8f), fontFamily = ff, fontSize = (22 * s).sp)
            }
            // ---- 11..23: original layouts inspired by the general look of popular Android clock styles (no brand assets)
            11 -> { // HyperOS-inspired split
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(hh, color = col, fontFamily = ff, fontSize = (96 * s).sp, fontWeight = FontWeight.Bold)
                    Box(Modifier.padding(horizontal = (10 * s).dp).size((3 * s).dp, (90 * s).dp).clip(RoundedCornerShape(2.dp)).background(acc))
                    Text(mm, color = col.copy(alpha = 0.8f), fontFamily = ff, fontSize = (96 * s).sp, fontWeight = FontWeight.Light)
                }
                Text(DateTimeFormatter.ofPattern("EEEE").format(now).uppercase(), color = acc, fontSize = (14 * s).sp, letterSpacing = 3.sp)
            }
            12 -> { // One UI-inspired capsule
                Row(Modifier.clip(RoundedCornerShape(50)).background(acc.copy(alpha = 0.22f)).border(1.dp, acc, RoundedCornerShape(50)).padding(horizontal = (22 * s).dp, vertical = (10 * s).dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(hm, color = col, fontFamily = ff, fontSize = (44 * s).sp, fontWeight = FontWeight.Bold)
                    Text(date, color = acc, fontSize = (14 * s).sp, modifier = Modifier.padding(start = (12 * s).dp))
                }
            }
            13 -> { // Pixel-inspired date-first glance
                Text(date, color = acc, fontFamily = ff, fontSize = (18 * s).sp)
                Text(hm, color = col, fontFamily = ff, fontSize = (78 * s).sp, fontWeight = FontWeight.Normal)
            }
            14 -> { // OnePlus-inspired two-tone heavy
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(hh, color = col, fontFamily = ff, fontSize = (88 * s).sp, fontWeight = FontWeight.Black)
                    Text(mm, color = acc, fontFamily = ff, fontSize = (88 * s).sp, fontWeight = FontWeight.Black)
                    if (!st.hour24) Text(if (now.hour < 12) "AM" else "PM", color = col, fontSize = (14 * s).sp, modifier = Modifier.padding(start = 6.dp, bottom = (14 * s).dp))
                }
            }
            15 -> { // OPPO-inspired hour ring
                Box(contentAlignment = Alignment.Center) {
                    Canvas(Modifier.size((230 * s).dp)) {
                        val r = size.minDimension / 2f - 10f
                        for (i in 0 until 12) {
                            val ang = Math.toRadians(i * 30.0 - 90)
                            val on = i == now.hour % 12
                            drawCircle(if (on) acc else col.copy(alpha = 0.35f), if (on) 9f * s else 4f * s, center + Offset(cos(ang).toFloat(), sin(ang).toFloat()) * r)
                        }
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(hm, color = col, fontFamily = ff, fontSize = (46 * s).sp, fontWeight = FontWeight.Medium)
                        Text(date, color = acc, fontSize = (13 * s).sp)
                    }
                }
            }
            16 -> { // vivo-inspired vertical digits
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    (hh + mm).forEachIndexed { i, ch ->
                        Text(ch.toString(), color = if (i < 2) col else acc, fontFamily = ff, fontSize = (54 * s).sp, fontWeight = FontWeight.Bold, lineHeight = (52 * s).sp)
                    }
                }
            }
            17 -> { // Nothing-inspired dot matrix
                val glyph = mapOf(
                    '0' to listOf("01110", "10001", "10011", "10101", "11001", "10001", "01110"), '1' to listOf("00100", "01100", "00100", "00100", "00100", "00100", "01110"),
                    '2' to listOf("01110", "10001", "00001", "00010", "00100", "01000", "11111"), '3' to listOf("11110", "00001", "00001", "01110", "00001", "00001", "11110"),
                    '4' to listOf("00010", "00110", "01010", "10010", "11111", "00010", "00010"), '5' to listOf("11111", "10000", "11110", "00001", "00001", "10001", "01110"),
                    '6' to listOf("00110", "01000", "10000", "11110", "10001", "10001", "01110"), '7' to listOf("11111", "00001", "00010", "00100", "01000", "01000", "01000"),
                    '8' to listOf("01110", "10001", "10001", "01110", "10001", "10001", "01110"), '9' to listOf("01110", "10001", "10001", "01111", "00001", "00010", "01100"),
                )
                val chars = hmRaw.replace(":", "")
                val cell = 7f * s
                Canvas(Modifier.size((cell * 25f).dp, (cell * 7f).dp)) {
                    val unit = size.width / 25f
                    var x = 0
                    fun digit(ch: Char) {
                        val g = glyph[ch] ?: return
                        for (row in 0 until 7) for (c in 0 until 5) {
                            val on = g[row][c] == '1'
                            drawCircle(if (on) col else col.copy(alpha = 0.12f), unit * 0.36f, Offset((x + c + 0.5f) * unit, (row + 0.5f) * unit))
                        }
                        x += 6
                    }
                    digit(chars[0]); digit(chars[1])
                    drawCircle(acc, unit * 0.4f, Offset((x + 0.5f) * unit, 2.5f * unit)); drawCircle(acc, unit * 0.4f, Offset((x + 0.5f) * unit, 4.5f * unit)); x += 2
                    digit(chars[2]); digit(chars[3])
                }
            }
            18 -> { // Motorola-inspired bar between hour and minute
                Column(horizontalAlignment = ha) {
                    Text(hh, color = col, fontFamily = ff, fontSize = (100 * s).sp, fontWeight = FontWeight.Light, lineHeight = (90 * s).sp)
                    Box(Modifier.size((110 * s).dp, (5 * s).dp).clip(RoundedCornerShape(3.dp)).background(acc))
                    Text(mm, color = col, fontFamily = ff, fontSize = (100 * s).sp, fontWeight = FontWeight.Light, lineHeight = (90 * s).sp)
                }
            }
            19 -> { // Realme-inspired analog with 12-3-6-9 numerals
                Canvas(Modifier.size((220 * s).dp)) {
                    val c = center; val r = size.minDimension / 2f
                    drawCircle(col.copy(alpha = 0.12f), r)
                    drawCircle(col, r, style = Stroke(2f))
                    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = col.toArgb(); textSize = 30f * s; textAlign = android.graphics.Paint.Align.CENTER; isFakeBoldText = true }
                    val nums = listOf(12 to -90.0, 3 to 0.0, 6 to 90.0, 9 to 180.0)
                    nums.forEach { (n, deg) ->
                        val a = Math.toRadians(deg)
                        drawContext.canvas.nativeCanvas.drawText(localizeDigits(n.toString()), c.x + (r * 0.74f) * cos(a).toFloat(), c.y + (r * 0.74f) * sin(a).toFloat() + 10f * s, paint)
                    }
                    val min = now.minute + now.second / 60.0; val hr = (now.hour % 12) + min / 60.0
                    fun hand(deg: Double, len: Float, w: Float, color: Color) {
                        val a = Math.toRadians(deg - 90)
                        drawLine(color, c, c + Offset(cos(a).toFloat(), sin(a).toFloat()) * (r * len), w, StrokeCap.Round)
                    }
                    hand(hr * 30, 0.45f, 9f, col); hand(min * 6, 0.68f, 6f, col); hand(now.second * 6.0, 0.8f, 2f, acc)
                    drawCircle(acc, 8f, c)
                }
            }
            20 -> { // POCO-inspired heavy italic with slanted underline
                Column(horizontalAlignment = ha) {
                    Text(hm, color = col, fontFamily = ff, fontSize = (80 * s).sp, fontWeight = FontWeight.Black, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                    Canvas(Modifier.size((200 * s).dp, (14 * s).dp)) {
                        val path = androidx.compose.ui.graphics.Path().apply { moveTo(size.height * 1.4f, 0f); lineTo(size.width, 0f); lineTo(size.width - size.height * 1.4f, size.height); lineTo(0f, size.height); close() }
                        drawPath(path, acc)
                    }
                }
            }
            21 -> { // Samsung-inspired date tile + time
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy((14 * s).dp)) {
                    Box(Modifier.size((84 * s).dp).clip(RoundedCornerShape(22.dp)).background(acc), contentAlignment = Alignment.Center) {
                        Text(localizeDigits(now.dayOfMonth.toString()), color = Color.Black, fontSize = (44 * s).sp, fontWeight = FontWeight.Black)
                    }
                    Column {
                        Text(hm, color = col, fontFamily = ff, fontSize = (46 * s).sp, fontWeight = FontWeight.Bold)
                        Text(DateTimeFormatter.ofPattern("EEEE").format(now), color = acc, fontSize = (15 * s).sp)
                    }
                }
            }
            22 -> { // binary-coded decimal clock
                val digits = (hmRaw.replace(":", "")).map { it - '0' }
                Row(horizontalArrangement = Arrangement.spacedBy((16 * s).dp)) {
                    digits.forEachIndexed { i, d ->
                        Column(verticalArrangement = Arrangement.spacedBy((8 * s).dp)) {
                            for (bit in 3 downTo 0) {
                                val on = ((d shr bit) and 1) == 1
                                Box(Modifier.size((26 * s).dp).clip(CircleShape).background(if (on) (if (i < 2) col else acc) else col.copy(alpha = 0.12f)))
                            }
                        }
                    }
                }
                Text(hm, color = col.copy(alpha = 0.7f), fontSize = (14 * s).sp, modifier = Modifier.padding(top = (8 * s).dp))
            }
            23 -> { // large expandable (tap to expand)
                var expanded by remember { mutableStateOf(false) }
                Column(Modifier.clickable { expanded = !expanded }, horizontalAlignment = ha) {
                    Text(hm, color = col, fontFamily = ff, fontSize = (92 * s).sp, fontWeight = FontWeight.Thin)
                    androidx.compose.animation.AnimatedVisibility(expanded) {
                        Column(horizontalAlignment = ha) {
                            Text(localizeDigits(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy").format(now)), color = acc, fontSize = (16 * s).sp)
                            Text(Hijri.format(now.toLocalDate()).let { localizeDigits(it) }, color = col.copy(alpha = 0.8f), fontSize = (15 * s).sp)
                            Text(localizeDigits(DateTimeFormatter.ofPattern(if (st.hour24) "HH:mm:ss" else "hh:mm:ss").format(now)), color = col.copy(alpha = 0.6f), fontSize = (14 * s).sp)
                        }
                    }
                }
            }
            24 -> Column(horizontalAlignment = ha) { // tall stacked numerals
                TallText(hh, (84 * s), 1.7f, col, FontWeight.Black, ff)
                TallText(mm, (84 * s), 1.7f, acc, FontWeight.Black, ff)
            }
            25 -> Column(verticalArrangement = Arrangement.spacedBy((2 * s).dp), horizontalAlignment = ha) { // quad grid
                listOf(hh, mm).forEachIndexed { r, pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy((10 * s).dp)) {
                        pair.forEachIndexed { c, ch -> Text(ch.toString(), color = if ((r + c) % 2 == 0) col else acc, fontFamily = ff, fontSize = (74 * s).sp, fontWeight = FontWeight.Bold) }
                    }
                }
            }
            26 -> Column(horizontalAlignment = ha) { // monospaced bracket
                Text("[ $hm ]", color = col, fontFamily = FontFamily.Monospace, fontSize = (46 * s).sp, fontWeight = FontWeight.Light)
                Box(Modifier.size((190 * s).dp, (2 * s).dp).background(acc))
                Text(date, color = acc, fontFamily = FontFamily.Monospace, fontSize = (13 * s).sp, letterSpacing = 2.sp)
            }
            27 -> Box(Modifier.size((240 * s).dp, (190 * s).dp).clip(RoundedCornerShape(26.dp)).background(acc.copy(alpha = 0.16f))) { // oversize clipped hours
                Text(hh, color = col.copy(alpha = 0.92f), fontFamily = ff, fontSize = (250 * s).sp, fontWeight = FontWeight.Black, softWrap = false, modifier = Modifier.align(Alignment.TopStart).offset(x = (-8 * s).dp, y = (-46 * s).dp))
                Text(mm, color = acc, fontFamily = ff, fontSize = (64 * s).sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.BottomEnd).padding(end = (14 * s).dp, bottom = (8 * s).dp))
            }
            28 -> Column(horizontalAlignment = ha) { // weight ramp (dynamic typography)
                Row {
                    listOf(100, 300, 600, 900).forEachIndexed { i, w -> Text((hh + mm)[i].toString(), color = if (i < 2) col else acc, fontFamily = ff, fontSize = (80 * s).sp, fontWeight = FontWeight(w)) }
                }
                Text(date, color = acc, fontSize = (14 * s).sp)
            }
            29 -> Row(verticalAlignment = Alignment.CenterVertically) { // wave baseline
                (hh + mm).forEachIndexed { i, ch -> Text(ch.toString(), color = if (i % 2 == 0) col else acc, fontFamily = ff, fontSize = (70 * s).sp, fontWeight = FontWeight.Bold, modifier = Modifier.offset(y = (if (i % 2 == 0) -14 else 14).times(s).dp)) }
            }
            30 -> Column(horizontalAlignment = ha) { // gradient fill
                Text(hm, style = TextStyle(brush = androidx.compose.ui.graphics.Brush.verticalGradient(listOf(col, acc)), fontSize = (88 * s).sp, fontWeight = FontWeight.Black, fontFamily = ff))
                Text(date, color = col.copy(alpha = 0.8f), fontSize = (15 * s).sp)
            }
            31 -> Row(verticalAlignment = Alignment.Bottom) { // editorial serif
                Text(hh, color = col, fontFamily = FontFamily.Serif, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic, fontSize = (112 * s).sp, fontWeight = FontWeight.Light)
                Column(Modifier.padding(start = (8 * s).dp, bottom = (18 * s).dp)) {
                    Text(mm, color = acc, fontFamily = FontFamily.Serif, fontSize = (42 * s).sp)
                    Text(DateTimeFormatter.ofPattern("EEEE").format(now).uppercase(), color = col.copy(alpha = 0.8f), fontSize = (11 * s).sp, letterSpacing = 3.sp)
                }
            }
            32 -> Column(horizontalAlignment = Alignment.CenterHorizontally) { // calligraphic gold, Arabic-Indic numerals
                Text(arabicDigits(hmRaw), style = TextStyle(brush = androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color(0xFFF5E6A8), Color(0xFFD4AF37))), fontSize = (72 * s).sp, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold))
                Text(localizeDigits(Hijri.format(now.toLocalDate())), color = Color(0xFFF5E6A8), fontSize = (16 * s).sp)
            }
            33 -> Column(horizontalAlignment = ha, verticalArrangement = Arrangement.spacedBy((6 * s).dp)) { // compact chips
                Text(hm, color = Color.Black, fontFamily = ff, fontSize = (34 * s).sp, fontWeight = FontWeight.Bold, modifier = Modifier.clip(RoundedCornerShape(50)).background(acc).padding(horizontal = (18 * s).dp, vertical = (6 * s).dp))
                Row(horizontalArrangement = Arrangement.spacedBy((6 * s).dp)) {
                    Text(DateTimeFormatter.ofPattern("EEE").format(now), color = col, fontSize = (13 * s).sp, modifier = Modifier.clip(RoundedCornerShape(50)).background(col.copy(alpha = 0.18f)).padding(horizontal = (12 * s).dp, vertical = (4 * s).dp))
                    Text(localizeDigits(DateTimeFormatter.ofPattern("d MMM").format(now)), color = col, fontSize = (13 * s).sp, modifier = Modifier.clip(RoundedCornerShape(50)).background(col.copy(alpha = 0.18f)).padding(horizontal = (12 * s).dp, vertical = (4 * s).dp))
                }
            }
            34 -> Box(Modifier.size((250 * s).dp, (150 * s).dp)) { // geometric overlapping circles
                Box(Modifier.size((140 * s).dp).clip(CircleShape).background(acc.copy(alpha = 0.28f)).border(2.dp, acc, CircleShape).align(Alignment.CenterStart), contentAlignment = Alignment.Center) { Text(hh, color = col, fontFamily = ff, fontSize = (60 * s).sp, fontWeight = FontWeight.Bold) }
                Box(Modifier.size((140 * s).dp).clip(CircleShape).background(col.copy(alpha = 0.18f)).border(2.dp, col, CircleShape).align(Alignment.CenterEnd), contentAlignment = Alignment.Center) { Text(mm, color = col, fontFamily = ff, fontSize = (60 * s).sp, fontWeight = FontWeight.Light) }
            }
            35 -> Box(Modifier.size((250 * s).dp, (260 * s).dp), contentAlignment = Alignment.Center) { // depth-ready: giant hours behind, minutes in front
                Text(hh, color = col.copy(alpha = 0.85f), fontFamily = ff, fontSize = (230 * s).sp, fontWeight = FontWeight.Black, softWrap = false)
                Text(mm, color = acc, fontFamily = ff, fontSize = (110 * s).sp, fontWeight = FontWeight.Black, modifier = Modifier.offset(y = (70 * s).dp))
            }
            else -> Text(hm, color = col, fontFamily = ff, fontSize = (64 * s).sp)
        }
    }
}

@Composable
fun ClocksScreen(nav: NavController) {
    val ctx = LocalContext.current
    val now by rememberNow()
    val st = Store.clockStyle
    val scope = rememberCoroutineScope()
    var bgCat by remember { mutableIntStateOf(0) }
    var bgVar by remember { mutableIntStateOf(2) }
    var photo by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var bounds by remember { mutableStateOf<android.graphics.Rect?>(null) }
    var busy by remember { mutableStateOf(false) }
    val pickBg = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch { photo = Images.loadUri(ctx, uri, 1600) ?: run { ctx.toast(R.string.import_invalid); null } }
    }
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { BackTitle(nav, stringResource(R.string.clock_universe)) }
        item { Button(onClick = { nav.navigate("creator") }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.creator_open_btn)) } }
        item {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(Modifier.fillMaxWidth(0.62f).aspectRatio(9f / 16f).clip(RoundedCornerShape(24.dp)).onGloballyPositioned { c -> val r = c.boundsInWindow(); bounds = android.graphics.Rect(r.left.toInt(), r.top.toInt(), r.right.toInt(), r.bottom.toInt()) }, contentAlignment = Alignment.Center) {
                    val ph = photo
                    if (ph != null) androidx.compose.foundation.Image(ph.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                    else GenArt(bgCat * 100 + bgVar, Modifier.fillMaxSize(), big = true)
                    Box(Modifier.padding(8.dp).clip(RoundedCornerShape(20.dp)).background(Color.Black.copy(alpha = st.bgAlpha)).padding(8.dp)) {
                        ClockFace(st.copy(scale = st.scale * 0.55f), now)
                    }
                }
            }
        }
        item {
            Section {
                Text(stringResource(R.string.creator_canvas), fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(com.fareshelmy.auraglass.data.Walls.cats) { i, c -> FilterChip(selected = photo == null && bgCat == i, onClick = { photo = null; bgCat = i }, label = { Text(stringResource(c.titleRes)) }) }
                }
                Slider(bgVar.toFloat(), { v -> photo = null; bgVar = v.toInt().coerceIn(0, com.fareshelmy.auraglass.data.Walls.PER - 1) }, valueRange = 0f..(com.fareshelmy.auraglass.data.Walls.PER - 1).toFloat(), steps = com.fareshelmy.auraglass.data.Walls.PER - 2)
                OutlinedButton(onClick = { pickBg.launch(androidx.activity.result.PickVisualMediaRequest(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text(stringResource(R.string.clock_preview_on_photo)) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(enabled = !busy && bounds != null, onClick = {
                        busy = true
                        scope.launch {
                            val bmp = ScreenCapture.capture(ctx, bounds)
                            val ok = bmp != null && withContext(kotlinx.coroutines.Dispatchers.IO) { Images.saveToGallery(ctx, bmp, "clock") }
                            busy = false; ctx.toast(if (ok) R.string.saved_gallery else R.string.save_failed)
                        }
                    }) { Text(stringResource(R.string.creator_export)) }
                    Button(enabled = !busy && bounds != null, onClick = {
                        busy = true
                        scope.launch {
                            val bmp = ScreenCapture.capture(ctx, bounds)
                            val ok = bmp != null && withContext(kotlinx.coroutines.Dispatchers.IO) { Images.setWallpaper(ctx, bmp, 2) }
                            busy = false; ctx.toast(if (ok) R.string.wallpaper_set else R.string.wallpaper_failed)
                        }
                    }) { Text(stringResource(R.string.set_wallpaper)) }
                }
                OutlinedButton(onClick = {
                    val src = photo ?: com.fareshelmy.auraglass.data.Walls.thumb(bgCat * 100 + bgVar)
                    val r = com.fareshelmy.auraglass.util.MagicColors.analyze(src)
                    Store.updateClock(st.copy(color = r.text, accent = r.accent)); ctx.toast(R.string.clock_colors_matched)
                }) { Text(stringResource(R.string.clock_match_colors)) }
                Text(stringResource(R.string.clock_capture_note), fontSize = 12.sp, color = Pal.muted)
            }
        }
        item { Text(stringResource(R.string.clock_preview_note), fontSize = 12.sp, color = Pal.muted) }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(clockNames) { i, r ->
                    Column(
                        Modifier.width(112.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF16161A))
                            .border(if (st.design == i) 2.dp else 1.dp, if (st.design == i) Pal.accent else Color(0x33FFFFFF), RoundedCornerShape(16.dp))
                            .clickable { Store.updateClock(st.copy(design = i)) }.padding(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Box(Modifier.height(86.dp), contentAlignment = Alignment.Center) { ClockFace(st.copy(design = i, scale = 0.28f), now) }
                        Text(stringResource(r), fontSize = 11.sp, maxLines = 1)
                    }
                }
            }
        }
        item {
            Section {
                Text(stringResource(R.string.clock_color)); ColorRow(st.color) { Store.updateClock(st.copy(color = it)) }
                Text(stringResource(R.string.clock_accent)); ColorRow(st.accent) { Store.updateClock(st.copy(accent = it)) }
                Text(stringResource(R.string.clock_size)); Slider(st.scale, { Store.updateClock(st.copy(scale = it)) }, valueRange = 0.5f..1.6f)
                Text(stringResource(R.string.clock_bg)); Slider(st.bgAlpha, { Store.updateClock(st.copy(bgAlpha = it)) }, valueRange = 0f..0.9f)
                Text(stringResource(R.string.clock_align))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(R.string.align_start, R.string.align_center, R.string.align_end).forEachIndexed { i, r ->
                        FilterChip(selected = st.align == i, onClick = { Store.updateClock(st.copy(align = i)) }, label = { Text(stringResource(r)) })
                    }
                }
                Text(stringResource(R.string.clock_font))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(fontNames) { i, r -> FilterChip(selected = st.font == i, onClick = { Store.updateClock(st.copy(font = i)) }, label = { Text(stringResource(r)) }) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.clock_24h), Modifier.weight(1f)); Switch(st.hour24, { Store.updateClock(st.copy(hour24 = it)) })
                }
            }
        }
        item {
            Section {
                Text(stringResource(R.string.presets), fontWeight = FontWeight.Bold)
                Button(onClick = { Store.savePreset("#" + (Store.presets.size + 1) + " " + stringResource0(ctx, clockNames[st.design]), st) }) { Text(stringResource(R.string.save_preset)) }
                Store.presets.toList().forEach { p ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(p.name, Modifier.weight(1f))
                        TextButton(onClick = { Store.updateClock(p.style) }) { Text(stringResource(R.string.apply)) }
                        TextButton(onClick = { Store.deletePreset(p) }) { Text(stringResource(R.string.remove)) }
                    }
                }
            }
        }
        item {
            Section {
                Text(stringResource(R.string.real_widgets), fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.real_widgets_note), fontSize = 12.sp, color = Pal.muted)
                Button(onClick = { Widgets.updateAll(ctx); ctx.toast(R.string.widgets_updated) }) { Text(stringResource(R.string.apply_widgets)) }
                OutlinedButton(onClick = { ctx.toast(if (Widgets.pin(ctx, ClockDigitalWidget::class.java)) R.string.pin_requested else R.string.pin_unsupported) }) { Text(stringResource(R.string.pin_digital)) }
                OutlinedButton(onClick = { ctx.toast(if (Widgets.pin(ctx, ClockAnalogWidget::class.java)) R.string.pin_requested else R.string.pin_unsupported) }) { Text(stringResource(R.string.pin_analog)) }
                Text(stringResource(R.string.lockscreen_note), fontSize = 12.sp, color = Pal.muted)
            }
        }
    }
}

private fun stringResource0(ctx: android.content.Context, id: Int) = ctx.getString(id)


/** Text stretched vertically (tall numerals) while reserving the stretched height in the layout. */
@Composable
private fun TallText(text: String, size: Float, vScale: Float, color: Color, weight: FontWeight, ff: FontFamily) {
    Text(
        text, color = color, fontFamily = ff, fontSize = size.sp, fontWeight = weight, lineHeight = size.sp,
        modifier = Modifier
            .layout { m, c ->
                val p = m.measure(c)
                val h = (p.height * vScale).toInt()
                layout(p.width, h) { p.place(0, (h - p.height) / 2) }
            }
            .graphicsLayer { scaleY = vScale },
    )
}
