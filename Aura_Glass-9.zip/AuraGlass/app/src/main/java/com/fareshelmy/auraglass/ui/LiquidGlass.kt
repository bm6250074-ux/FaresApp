package com.fareshelmy.auraglass.ui

import android.os.Build
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.fareshelmy.auraglass.data.Store

/** Space the floating bar occupies at the bottom (0 when hidden). Screens add it as bottom padding. */
val LocalBarInset = compositionLocalOf { 0.dp }

/**
 * Records the wrapped content into a GraphicsLayer (and still draws it normally) so floating glass surfaces that sit
 * ABOVE it (the navigation bar) can draw a real, blurred copy of what is behind them.
 */
fun Modifier.backdropSource(layer: GraphicsLayer): Modifier = this.drawWithContent {
    layer.record(this, layoutDirection, IntSize(size.width.toInt(), size.height.toInt())) {
        this@drawWithContent.drawContent()
    }
    drawLayer(layer)
}

/**
 * Real backdrop blur (RenderEffect, Android 12+/API 31+): draws the recorded backdrop, blurred, clipped to a pill.
 * Below API 31 this does nothing and the surface falls back to plain translucency.
 */
fun Modifier.backdropBlurPill(source: GraphicsLayer?, radiusPx: Float): Modifier = composed {
    if (source == null || Build.VERSION.SDK_INT < 31 || radiusPx <= 0f) {
        this
    } else {
        val blurLayer = rememberGraphicsLayer()
        var origin by remember { mutableStateOf(Offset.Zero) }
        this
            .onGloballyPositioned { origin = it.positionInRoot() }
            .drawWithContent {
                val w = size.width
                val h = size.height
                blurLayer.renderEffect = BlurEffect(radiusPx, radiusPx, TileMode.Clamp)
                blurLayer.record(this, layoutDirection, IntSize(w.toInt(), h.toInt())) {
                    translate(-origin.x, -origin.y) { drawLayer(source) }
                }
                val r = h / 2f
                val path = Path().apply { addRoundRect(RoundRect(0f, 0f, w, h, CornerRadius(r, r))) }
                clipPath(path) { drawLayer(blurLayer) }
                drawContent()
            }
    }
}

/**
 * Liquid Glass surface for cards, panels and floating controls.
 *  ON : translucent layered fill + specular highlight + gradient rim light + soft depth shadow.
 *  OFF: plain solid surface with a thin outline (no transparency left behind).
 * Honest note: refraction is simulated with highlights/rim light; real backdrop blur is used on the navigation bar.
 */
fun Modifier.liquidGlass(shape: Shape? = null): Modifier = composed {
    val g = Store.glass
    val l = Store.liquid
    val pal = LocalPalette.current
    val s = shape ?: RoundedCornerShape(g.corner.dp)
    if (!l.on) {
        // Liquid Glass OFF: plain solid surface, no transparency, no blur, no highlights.
        this
            .clip(s)
            .background(if (pal.dark) Color(0xFF17171B) else Color.White)
            .border(1.dp, pal.onSurface.copy(alpha = 0.14f), s)
    } else {
        val rim = if (pal.dark) Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.15f + 0.55f * l.reflect),
                Color.White.copy(alpha = 0.04f),
                Color.White.copy(alpha = 0.10f + 0.35f * l.reflect),
            )
        ) else Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.55f + 0.4f * l.reflect),
                Color.Black.copy(alpha = 0.07f),
                Color.White.copy(alpha = 0.35f + 0.4f * l.reflect),
            )
        )
        val fillTop = if (pal.dark) (g.alpha + 0.04f) else (0.50f + g.alpha * 0.6f)
        val fillBottom = if (pal.dark) (g.alpha * 0.4f) else (0.28f + g.alpha * 0.4f)
        this
            .shadow((l.depth * (if (pal.dark) 14f else 10f)).dp, s, clip = false, ambientColor = Color.Black, spotColor = Color.Black)
            .clip(s)
            .background(
                Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = fillTop.coerceIn(0f, 1f)), Color.White.copy(alpha = fillBottom.coerceIn(0f, 1f)))
                )
            )
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        listOf(Color.White.copy(alpha = (if (pal.dark) 0.22f else 0.5f) * l.reflect), Color.Transparent),
                        center = Offset(size.width * 0.18f, 0f),
                        radius = size.minDimension * 1.1f,
                    )
                )
            }
            .drawBehind {
                // soft bottom shade gives the pane thickness (frosted depth) without any opaque block
                drawRect(Brush.verticalGradient(listOf(Color.Transparent, (if (pal.dark) Color.Black else Color(0xFF8899AA)).copy(alpha = 0.10f + 0.10f * l.depth)), startY = size.height * 0.45f))
            }
            .border(l.borderWidth.dp, rim, s)
    }
}

/** Spring press feedback (scale) + click. Skips the scale when reduced motion is on. */
fun Modifier.pressClickable(onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val reduced = rememberAppReducedMotion()
    val sc by animateFloatAsState(
        if (pressed && !reduced) 0.95f else 1f,
        spring(dampingRatio = 0.55f, stiffness = 520f),
        label = "press",
    )
    this
        .graphicsLayer { scaleX = sc; scaleY = sc }
        .clickable(interactionSource = src, indication = null, onClick = onClick)
}

/** Animation duration honouring the user's speed setting and Android's reduced-motion setting. */
@androidx.compose.runtime.Composable
fun animMs(base: Int): Int = if (rememberAppReducedMotion()) 0 else (base / Store.liquid.animSpeed).toInt()
