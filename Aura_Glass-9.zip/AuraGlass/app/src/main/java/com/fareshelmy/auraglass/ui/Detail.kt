package com.fareshelmy.auraglass.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.data.LocalCatalog
import com.fareshelmy.auraglass.data.Session
import com.fareshelmy.auraglass.data.Sources
import com.fareshelmy.auraglass.data.Store
import com.fareshelmy.auraglass.data.Wallpaper
import com.fareshelmy.auraglass.util.Images
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun DetailScreen(nav: NavController) {
    val wp = Session.selected
    if (wp == null) { LaunchedEffect(Unit) { nav.popBackStack() }; return }
    key(wp.id) { DetailContent(nav, wp) }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DetailContent(nav: NavController, wp: Wallpaper) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var showSet by remember { mutableStateOf(false) }
    var showCollect by remember { mutableStateOf(false) }
    val fav = Store.isFav(wp.id)

    fun doSave() {
        scope.launch {
            busy = true
            val bmp = Images.load(ctx, wp)
            val ok = bmp != null && withContext(Dispatchers.IO) { Images.saveToGallery(ctx, bmp, wp.title) }
            busy = false
            if (ok) Store.addDownload(wp)
            ctx.toast(if (ok) R.string.saved_gallery else R.string.save_failed)
        }
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) doSave() else ctx.toast(R.string.perm_denied)
    }

    val relQuery = remember(wp.id) { wp.tags.firstOrNull() ?: wp.title.split(" ").take(2).joinToString(" ") }
    val rel = remember(relQuery) { if (wp.isLocal || wp.isGen || wp.isImported) null else Sources.get(relQuery) }
    LaunchedEffect(rel) { rel?.let { if (it.items.isEmpty() && !it.loading) it.load() } }
    val related: List<Wallpaper> = when {
        wp.isGen -> com.fareshelmy.auraglass.data.Walls.inCategory(wp.tags.firstOrNull() ?: "").filter { it.id != wp.id }.take(12)
        wp.isLocal -> LocalCatalog.items.filter { it.id != wp.id }.take(12)
        rel != null -> rel.items.filter { it.id != wp.id }.take(14)
        else -> emptyList()
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) }
            }
            Box(Modifier.fillMaxWidth(0.78f).align(Alignment.CenterHorizontally).aspectRatio(9f / 16f).clip(RoundedCornerShape(26.dp)).background(Color(0xFF151515))) {
                WallpaperImage(wp, Modifier.fillMaxSize(), full = true)
            }
            Row(Modifier.fillMaxWidth().padding(top = 16.dp).liquidGlass().padding(8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                ActionButton(if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder, if (fav) R.string.unfavorite else R.string.favorite, if (fav) Color(0xFFFF5C7A) else Pal.onSurface) { Store.toggleFav(wp) }
                ActionButton(Icons.Default.KeyboardArrowDown, R.string.download, Pal.onSurface) {
                    if (Build.VERSION.SDK_INT < 29 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                        permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE) else doSave()
                }
                if (!wp.isLocal && !wp.isGen && !wp.isImported) {
                    val saved = Store.isOffline(wp.id)
                    ActionButton(if (saved) Icons.Default.Check else Icons.Default.Add, if (saved) R.string.offline_remove else R.string.offline_save, if (saved) Pal.accent else Pal.onSurface) {
                        if (saved) {
                            Store.offline.firstOrNull { it.id == "off:" + wp.id }?.let { Store.removeOffline(it) }
                            ctx.toast(R.string.offline_removed)
                        } else scope.launch {
                            busy = true
                            val bmp = Images.load(ctx, wp)
                            val copy = bmp?.let { Images.saveOffline(ctx, it, wp) }
                            busy = false
                            if (copy != null) { Store.addOffline(copy); ctx.toast(R.string.offline_saved) } else ctx.toast(R.string.save_failed)
                        }
                    }
                }
                ActionButton(Icons.Default.Add, R.string.collect, Pal.onSurface) { showCollect = true }
                ActionButton(Icons.Default.Settings, R.string.adjust_size, Pal.onSurface) { Session.editWallpaper = wp; nav.navigate("editor") }
                ActionButton(Icons.Default.Share, R.string.share, Pal.onSurface) {
                    val text = buildString {
                        append(wp.title)
                        if (wp.creator.isNotBlank()) append(" — ${wp.creator}")
                        if (wp.license.isNotBlank()) append(" (${wp.license})")
                        if (wp.sourceUrl.isNotBlank()) append("\n${wp.sourceUrl}")
                    }
                    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), null))
                }
                ActionButton(Icons.Default.Star, R.string.set_wallpaper, Pal.accent) { showSet = true }
            }
            if (busy) Box(Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }

            Text(wp.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp))
            if (wp.creator.isNotBlank()) Text(stringResource(R.string.by_creator, wp.creator), color = Pal.muted)
            if (wp.license.isNotBlank()) {
                Text(
                    stringResource(R.string.license_label, wp.license), color = Pal.accent,
                    modifier = Modifier.clickable(enabled = wp.licenseUrl.startsWith("http")) {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(wp.licenseUrl)))
                    },
                )
            }
            if (wp.sourceUrl.startsWith("http")) {
                Text(stringResource(R.string.view_source), color = Pal.accent, modifier = Modifier.padding(top = 4.dp).clickable {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(wp.sourceUrl)))
                })
            }
            androidx.compose.material3.OutlinedButton(
                onClick = {
                    scope.launch {
                        val bmp = Images.load(ctx, wp, 256)
                        if (bmp == null) { ctx.toast(R.string.image_load_failed); return@launch }
                        val r = com.fareshelmy.auraglass.util.MagicColors.analyze(bmp)
                        Store.updateGlass(Store.glass.copy(tint = r.accent))
                        Store.updateBackground(Store.background.copy(mode = 1, c1 = r.dark, c2 = r.darker))
                        ctx.toast(R.string.magic_applied)
                    }
                },
                modifier = Modifier.padding(top = 10.dp),
            ) { Text(stringResource(R.string.magic_colors)) }
            if (wp.tags.isNotEmpty()) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 10.dp)) {
                    wp.tags.take(6).forEach { t -> AssistChip(onClick = { nav.navigate(resultsRoute(t)) }, label = { Text(t) }) }
                }
            }
            if (related.isNotEmpty()) {
                Text(stringResource(R.string.related), fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 20.dp, bottom = 8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(related, key = { it.id }) { r ->
                        WallCard(r, modifier = Modifier.width(120.dp), onClick = { Session.selected = it; Store.addRecent(it) })
                    }
                }
            }
        }
    }
    if (showSet) SetWallpaperDialog(wp) { showSet = false }
    if (showCollect) CollectDialog(wp) { showCollect = false }
}

@Composable
private fun ActionButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: Int, tint: Color, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, stringResource(label), tint = tint, modifier = Modifier.size(28.dp))
        Text(stringResource(label), fontSize = 11.sp, color = tint, maxLines = 1)
    }
}

@Composable
fun SetWallpaperDialog(wp: Wallpaper, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var failed by remember { mutableStateOf(false) }
    var target by remember { mutableIntStateOf(2) }
    var pos by remember { mutableFloatStateOf(0.5f) }
    var working by remember { mutableStateOf(false) }
    LaunchedEffect(wp.id) { bmp = Images.load(ctx, wp); failed = bmp == null }
    val dm = ctx.resources.displayMetrics
    val aspect = dm.widthPixels.toFloat() / dm.heightPixels
    val cropped = remember(bmp, pos) { bmp?.let { Images.cropToAspect(it, aspect, pos) } }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.set_wallpaper)) },
        text = {
            Column {
                Box(Modifier.fillMaxWidth().height(260.dp), contentAlignment = Alignment.Center) {
                    when {
                        cropped != null -> Image(cropped.asImageBitmap(), null, Modifier.height(260.dp).aspectRatio(aspect).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop)
                        failed -> Text(stringResource(R.string.image_load_failed), color = Pal.error)
                        else -> CircularProgressIndicator()
                    }
                }
                Text(stringResource(R.string.position), modifier = Modifier.padding(top = 8.dp), fontSize = 13.sp)
                Slider(value = pos, onValueChange = { pos = it })
                listOf(R.string.target_home, R.string.target_lock, R.string.target_both).forEachIndexed { i, r ->
                    Row(Modifier.fillMaxWidth().clickable { target = i }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = target == i, onClick = { target = i }); Text(stringResource(r))
                    }
                }
                Text(stringResource(R.string.set_note), fontSize = 12.sp, color = Pal.muted, modifier = Modifier.padding(top = 6.dp))
            }
        },
        confirmButton = {
            Button(enabled = cropped != null && !working, onClick = {
                val b = bmp ?: return@Button
                scope.launch {
                    working = true
                    val ok = withContext(Dispatchers.IO) { Images.setWallpaper(ctx, Images.cropToAspect(b, aspect, pos), target) }
                    working = false
                    ctx.toast(if (ok) R.string.wallpaper_set else R.string.wallpaper_failed)
                    if (ok) onDismiss()
                }
            }) { Text(stringResource(R.string.apply)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}


@Composable
fun CollectDialog(wp: Wallpaper, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.collect)) },
        text = {
            Column {
                if (Store.collections.isEmpty()) Text(stringResource(R.string.collections_empty), color = Pal.muted, fontSize = 13.sp)
                Store.collections.toList().forEach { c ->
                    val inside = Store.inCollection(c.name, wp.id)
                    Row(Modifier.fillMaxWidth().clickable { Store.toggleInCollection(c.name, wp) }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.Checkbox(checked = inside, onCheckedChange = { Store.toggleInCollection(c.name, wp) })
                        Text(c.name + " (" + c.items.size + ")")
                    }
                }
                androidx.compose.material3.OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true, placeholder = { Text(stringResource(R.string.collection_name)) })
                TextButton(onClick = { if (Store.createCollection(name)) { Store.toggleInCollection(name.trim().take(40), wp); name = "" } else ctx.toast(R.string.collection_invalid) }) { Text(stringResource(R.string.collection_new)) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.done)) } },
    )
}
