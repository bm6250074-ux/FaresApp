package com.fareshelmy.auraglass.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import androidx.compose.foundation.Canvas as ComposeCanvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.data.Session
import com.fareshelmy.auraglass.data.Store
import com.fareshelmy.auraglass.util.Images
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Gallery import editor. Any image / any aspect ratio. Pinch to zoom, drag to move, Fill (cover) or Fit (contain),
 * choose the output frame (screen / 9:16 / 16:9 / 4:3 / 1:1 / original). The original is never forced to 9:16 and the
 * image never leaves the device.
 */
@Composable
fun ImportEditorScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val uri = Session.importUri
    val wpToEdit = Session.editWallpaper
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var failed by remember { mutableStateOf(false) }
    var rot by remember { mutableIntStateOf(0) }                 // 0 / 90 / 180 / 270
    var lockRatio by remember { mutableStateOf(true) }
    var customW by remember { mutableIntStateOf(1080) }
    var customH by remember { mutableIntStateOf(1920) }
    LaunchedEffect(uri, wpToEdit) {
        if (wpToEdit != null) {
            bmp = Images.load(ctx, wpToEdit, 4096)     // original quality (never upscaled), max 4096 px to protect memory
        } else if (uri != null) {
            bmp = Images.loadUri(ctx, uri, 4096)
        } else { nav.popBackStack(); return@LaunchedEffect }
        if (bmp == null) { failed = true; ctx.toast(R.string.import_invalid) }
    }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { Session.editWallpaper = null; Session.importUri = null } }
    val rotated = remember(bmp, rot) {
        bmp?.let { src -> if (rot == 0) src else Bitmap.createBitmap(src, 0, 0, src.width, src.height, Matrix().apply { postRotate(rot.toFloat()) }, true) }
    }

    val dm = ctx.resources.displayMetrics
    val screenAspect = dm.widthPixels.toFloat() / dm.heightPixels
    var ratioIdx by remember { mutableIntStateOf(0) }       // 0 screen, 1 9:16, 2 16:9, 3 4:3, 4 1:1, 5 original(auto), 6 4:5, 7 3:4, 8 custom
    var fill by remember { mutableStateOf(true) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var ox by remember { mutableFloatStateOf(0f) }
    var oy by remember { mutableFloatStateOf(0f) }
    var fitBg by remember { mutableIntStateOf(0xFF000000.toInt()) }
    var frame by remember { mutableStateOf(IntSize.Zero) }
    var busy by remember { mutableStateOf(false) }
    var showTarget by remember { mutableStateOf(false) }
    var target by remember { mutableIntStateOf(2) }

    val b = rotated
    val aspect = when (ratioIdx) {
        0 -> screenAspect; 1 -> 9f / 16f; 2 -> 16f / 9f; 3 -> 4f / 3f; 4 -> 1f; 6 -> 4f / 5f; 7 -> 3f / 4f
        8 -> customW.toFloat() / customH
        else -> if (b != null) b.width.toFloat() / b.height else 1f
    }

    fun baseScale(fw: Float, fh: Float, bw: Float, bh: Float): Float =
        if (fill) max(fw / bw, fh / bh) else min(fw / bw, fh / bh)

    fun clamp(fw: Float, fh: Float) {
        val bb = rotated ?: return
        val s = baseScale(fw, fh, bb.width.toFloat(), bb.height.toFloat()) * zoom
        val mx = max(0f, (bb.width * s - fw) / 2f)
        val my = max(0f, (bb.height * s - fh) / 2f)
        ox = ox.coerceIn(-mx, mx); oy = oy.coerceIn(-my, my)
    }

    /** Renders exactly what the preview shows into a full-resolution bitmap (long side <= 2400 px, never upscaled beyond the source). */
    fun render(): Bitmap? {
        val bb = rotated ?: return null
        val fw = frame.width.toFloat(); val fh = frame.height.toFloat()
        if (fw <= 0f || fh <= 0f) return null
        val base = baseScale(fw, fh, bb.width.toFloat(), bb.height.toFloat())
        // output scale: try to keep source pixels 1:1 (k = 1/base), but cap the long side at 2400 px
        var k = 1f / (base * zoom)
        val longSide = max(fw, fh) * k
        if (ratioIdx == 8) k = customW / fw else if (longSide > 4096f) k *= 4096f / longSide
        val ow = if (ratioIdx == 8) customW else (fw * k).toInt().coerceAtLeast(1)
        val oh = if (ratioIdx == 8) customH else (fh * k).toInt().coerceAtLeast(1)
        val out = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(if (fill) android.graphics.Color.BLACK else fitBg)
        val s = base * zoom * k
        val m = Matrix()
        m.postScale(s, s)
        m.postTranslate(ow / 2f + ox * k - bb.width * s / 2f, oh / 2f + oy * k - bb.height * s / 2f)
        c.drawBitmap(bb, m, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        return out
    }

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 40.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { BackTitle(nav, stringResource(R.string.editor_title)) }
        item {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                val frameMod = (if (aspect >= 1f) Modifier.fillMaxWidth() else Modifier.fillMaxWidth(0.62f)).aspectRatio(aspect)
                Box(frameMod.clip(RoundedCornerShape(18.dp)).border(1.dp, Pal.outline, RoundedCornerShape(18.dp)).onSizeChanged { frame = it }, contentAlignment = Alignment.Center) {
                    if (b != null && frame.width > 0) {
                        val img = remember(b) { b.asImageBitmap() }
                        ComposeCanvas(
                            Modifier.fillMaxSize().pointerInput(frame, fill, ratioIdx, b) {
                                detectTransformGestures { _, pan, gz, _ ->
                                    zoom = (zoom * gz).coerceIn(1f, 8f)
                                    ox += pan.x; oy += pan.y
                                    clamp(frame.width.toFloat(), frame.height.toFloat())
                                }
                            },
                        ) {
                            drawRect(if (fill) Color.Black else Color(fitBg))
                            val s = baseScale(size.width, size.height, b.width.toFloat(), b.height.toFloat()) * zoom
                            withTransform({
                                translate(size.width / 2f + ox, size.height / 2f + oy)
                                scale(s, s, Offset.Zero)
                            }) { drawImage(img, topLeft = Offset(-b.width / 2f, -b.height / 2f)) }
                        }
                    } else if (failed) Text(stringResource(R.string.image_load_failed), color = Pal.error)
                    else CircularProgressIndicator()
                }
            }
        }
        item { Text(stringResource(R.string.ed_hint), fontSize = 12.sp, color = Pal.muted) }
        item {
            Section {
                Text(stringResource(R.string.ed_frame), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                val names = listOf(R.string.ed_screen, R.string.ed_916, R.string.ed_169, R.string.ed_43, R.string.ed_11, R.string.ed_orig, R.string.ed_45, R.string.ed_34, R.string.ed_custom)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(names) { i, r -> FilterChip(selected = ratioIdx == i, onClick = { ratioIdx = i; zoom = 1f; ox = 0f; oy = 0f }, label = { Text(stringResource(r)) }) }
                }
                if (ratioIdx == 8) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Text(stringResource(R.string.ed_lock_ratio), Modifier.weight(1f)); androidx.compose.material3.Switch(lockRatio, { lockRatio = it }) }
                    Text(stringResource(R.string.ed_width) + ": " + customW + " px")
                    Slider(customW.toFloat(), { v -> val old = customW; customW = v.toInt().coerceIn(256, 4096); if (lockRatio) customH = (customH.toFloat() * customW / old).toInt().coerceIn(256, 4096) }, valueRange = 256f..4096f)
                    Text(stringResource(R.string.ed_height) + ": " + customH + " px")
                    Slider(customH.toFloat(), { v -> val old = customH; customH = v.toInt().coerceIn(256, 4096); if (lockRatio) customW = (customW.toFloat() * customH / old).toInt().coerceIn(256, 4096) }, valueRange = 256f..4096f)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { rot = (rot + 270) % 360; zoom = 1f; ox = 0f; oy = 0f }) { Text("⟲ 90°") }
                    OutlinedButton(onClick = { rot = (rot + 90) % 360; zoom = 1f; ox = 0f; oy = 0f }) { Text("⟳ 90°") }
                }
                rotated?.let { src ->
                    Text(stringResource(R.string.ed_source_res, src.width, src.height), fontSize = 12.sp, color = Pal.muted)
                    if (ratioIdx == 8 && frame.width > 0) {
                        // source pixels actually visible inside the frame at the current zoom
                        val visibleW = frame.width / (baseScale(frame.width.toFloat(), frame.height.toFloat(), src.width.toFloat(), src.height.toFloat()) * zoom)
                        if (customW > visibleW * 1.02f) Text(stringResource(R.string.ed_upscale_warn), fontSize = 12.sp, color = Pal.warn)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = fill, onClick = { fill = true; ox = 0f; oy = 0f }, label = { Text(stringResource(R.string.ed_fill)) })
                    FilterChip(selected = !fill, onClick = { fill = false; ox = 0f; oy = 0f }, label = { Text(stringResource(R.string.ed_fit)) })
                }
                if (!fill) { Text(stringResource(R.string.ed_bg_color)); ColorRow(fitBg) { fitBg = it } }
                Text(stringResource(R.string.ed_zoom))
                Slider(zoom, { zoom = it; clamp(frame.width.toFloat(), frame.height.toFloat()) }, valueRange = 1f..8f)
                OutlinedButton(onClick = { zoom = 1f; ox = 0f; oy = 0f }) { Text(stringResource(R.string.ed_reset)) }
            }
        }
        item {
            Section {
                if (busy) CircularProgressIndicator()
                Button(enabled = b != null && !busy, onClick = { showTarget = true }) { Text(stringResource(R.string.set_wallpaper)) }
                OutlinedButton(enabled = b != null && !busy, onClick = {
                    scope.launch {
                        busy = true
                        val out = withContext(Dispatchers.Default) { render() }
                        val w = out?.let { Images.addBitmapToLibrary(ctx, it, "Imported " + java.text.SimpleDateFormat("MMM d HH:mm", java.util.Locale.getDefault()).format(java.util.Date())) }
                        busy = false
                        if (w != null) { Store.addImported(w); ctx.toast(R.string.import_ok) } else ctx.toast(R.string.save_failed)
                    }
                }) { Text(stringResource(R.string.ed_save_library)) }
                OutlinedButton(enabled = b != null && !busy, onClick = {
                    scope.launch {
                        busy = true
                        val ok = withContext(Dispatchers.Default) { render() }?.let { withContext(Dispatchers.IO) { Images.saveToGallery(ctx, it, "edited") } } ?: false
                        busy = false
                        ctx.toast(if (ok) R.string.saved_gallery else R.string.save_failed)
                    }
                }) { Text(stringResource(R.string.download)) }
                Text(stringResource(R.string.set_note), fontSize = 12.sp, color = Pal.muted)
            }
        }
    }

    if (showTarget) {
        AlertDialog(
            onDismissRequest = { showTarget = false },
            title = { Text(stringResource(R.string.set_wallpaper)) },
            text = {
                androidx.compose.foundation.layout.Column {
                    listOf(R.string.target_home, R.string.target_lock, R.string.target_both).forEachIndexed { i, r ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                            RadioButton(selected = target == i, onClick = { target = i }); Text(stringResource(r))
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    showTarget = false
                    scope.launch {
                        busy = true
                        val ok = withContext(Dispatchers.Default) { render() }?.let { withContext(Dispatchers.IO) { Images.setWallpaper(ctx, it, target) } } ?: false
                        busy = false
                        ctx.toast(if (ok) R.string.wallpaper_set else R.string.wallpaper_failed)
                    }
                }) { Text(stringResource(R.string.apply)) }
            },
            dismissButton = { TextButton(onClick = { showTarget = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}
