package com.fareshelmy.auraglass.util

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.fareshelmy.auraglass.BuildConfig
import com.fareshelmy.auraglass.data.Store
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

fun Context.findActivity(): Activity? {
    var c = this
    while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }
    return null
}

/**
 * Google Sign-In through Credential Manager. It is only active when GOOGLE_WEB_CLIENT_ID is configured at build time.
 * The ID token is kept in memory only and is sent solely to YOUR backend, which must verify it
 * (signature, audience, expiry) before doing anything. A client-side "success" is NOT authentication.
 */
object Auth {
    val enabled: Boolean get() = BuildConfig.GOOGLE_WEB_CLIENT_ID.isNotBlank()
    var idToken by mutableStateOf<String?>(null)
    /** "owner" or "user". Comes ONLY from the backend (/me verifies the Google token and the owner configured on the server). */
    var role by mutableStateOf("user")
        private set

    /** Asks the backend who this account is. No backend / no token / any failure => plain "user". */
    suspend fun refreshRole() {
        val base = BuildConfig.AURA_BACKEND_URL.trimEnd('/')
        val token = idToken
        role = if (base.isBlank() || token == null) "user" else try {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                val j = org.json.JSONObject(com.fareshelmy.auraglass.data.Net.getJson("$base/me", token, 15000))
                if (j.optString("role") == "owner") "owner" else "user"
            }
        } catch (e: Exception) { "user" }
    }

    suspend fun signIn(activity: Activity, silent: Boolean): Result<Unit> {
        val option = GetGoogleIdOption.Builder()
            .setServerClientId(BuildConfig.GOOGLE_WEB_CLIENT_ID)
            .setFilterByAuthorizedAccounts(silent)
            .setAutoSelectEnabled(silent)
            .build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        return try {
            val res = CredentialManager.create(activity).getCredential(activity, request)
            val cred = res.credential
            if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val g = GoogleIdTokenCredential.createFrom(cred.data)
                idToken = g.idToken
                Store.setAccount(g.displayName ?: "", g.id)
                refreshRole()
                Result.success(Unit)
            } else Result.failure(IllegalStateException("unsupported credential"))
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun signOut(ctx: Context) {
        try { CredentialManager.create(ctx).clearCredentialState(ClearCredentialStateRequest()) } catch (_: Exception) {}
        idToken = null
        role = "user"   // owner access disappears immediately on sign-out / account switch
        Store.clearAccount()
    }
}
