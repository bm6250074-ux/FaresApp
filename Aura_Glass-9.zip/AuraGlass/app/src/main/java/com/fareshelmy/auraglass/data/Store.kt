package com.fareshelmy.auraglass.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class HistoryItem(val query: String, val thumb: String)

data class GlassSettings(
    val alpha: Float = 0.22f,
    val border: Float = 0.35f,
    val corner: Float = 24f,
    val tint: Int = 0xFF7CF4C8.toInt(),
)

/** Liquid Glass rendering options (kept separate from GlassSettings so the start screen is unaffected). */
data class LiquidSettings(
    val on: Boolean = true,
    val blur: Float = 24f,        // backdrop blur radius (dp) - real blur on Android 12+
    val reflect: Float = 0.6f,    // strength of specular highlights / rim light
    val depth: Float = 0.5f,      // shadow / surface depth
    val borderWidth: Float = 1.2f,
    val animSpeed: Float = 1f,    // 0.5 = slow, 2 = fast
    val transition: Int = 0,      // 0 = fade+scale, 1 = slide, 2 = none
    val reduceMotion: Boolean = false, // in-app switch; Android's own reduced-motion setting is always respected too
)

data class AppearanceSettings(
    val themeMode: String = "dark",   // "dark" | "light" | "system"
    val amoled: Boolean = true,       // dark mode uses pure black when true
    val fontIdx: Int = 0,
    val fontScale: Float = 1f,
    val numerals: Int = 0,            // 0 = Latin 0-9, 1 = Arabic-Indic, 2 = follow app language
)

data class LayoutSettings(
    val minCard: Float = 165f,        // minimum card width (dp) -> number of columns
    val spacing: Float = 10f,
    val cardCorner: Float = 18f,
    val showTitles: Boolean = true,
    val barIcon: Float = 24f,         // navigation bar icon size (dp)
    val barLabels: Boolean = true,
    val indicator: Int = 0,           // 0 = lens bubble, 1 = solid pill, 2 = none
)

data class BgSettings(
    val mode: Int = 0,                // 0 = theme background, 1 = gradient, 2 = gallery image
    val c1: Int = 0xFF0B0B10.toInt(),
    val c2: Int = 0xFF1B1030.toInt(),
    val blur: Float = 16f,
    val dim: Float = 0.35f,
    val zoom: Float = 1f,
    val bias: Float = 0f,             // -1..1 horizontal position of the image
    val imageVersion: Int = 0,        // bumps when a new image is saved
)

data class WpCollection(val name: String, val items: List<Wallpaper>)

data class NamedTheme(val name: String, val json: String)

data class ClockStyle(
    val design: Int = 0,
    val color: Int = 0xFFFFFFFF.toInt(),
    val accent: Int = 0xFF7CF4C8.toInt(),
    val scale: Float = 1f,
    val align: Int = 1,          // 0 start, 1 center, 2 end
    val font: Int = 0,
    val bgAlpha: Float = 0f,
    val hour24: Boolean = true,
) {
    fun toJson(): JSONObject = JSONObject().put("design", design).put("color", color).put("accent", accent)
        .put("scale", scale.toDouble()).put("align", align).put("font", font)
        .put("bgAlpha", bgAlpha.toDouble()).put("hour24", hour24)

    companion object {
        fun fromJson(o: JSONObject) = ClockStyle(
            o.optInt("design"), o.optInt("color", 0xFFFFFFFF.toInt()), o.optInt("accent", 0xFF7CF4C8.toInt()),
            o.optDouble("scale", 1.0).toFloat(), o.optInt("align", 1), o.optInt("font"),
            o.optDouble("bgAlpha", 0.0).toFloat(), o.optBoolean("hour24", true),
        )
    }
}

data class NamedClock(val name: String, val style: ClockStyle)
data class WidgetStyle(val textColor: Int = 0xFFFFFFFF.toInt(), val bgAlpha: Float = 0.5f, val scale: Float = 1f, val bgColor: Int = 0xFF000000.toInt())

/**
 * All persisted, local-only app data (SharedPreferences). Nothing here is ever uploaded.
 * Compose-observable state so every screen updates live.
 */
object Store {
    private lateinit var sp: SharedPreferences

    val history = mutableStateListOf<HistoryItem>()
    val favorites = mutableStateListOf<Wallpaper>()
    val recents = mutableStateListOf<Wallpaper>()
    val imported = mutableStateListOf<Wallpaper>()
    val presets = mutableStateListOf<NamedClock>()

    var onboardingDone by mutableStateOf(false)
        private set
    var showIntro by mutableStateOf(false)
    var language by mutableStateOf("system")
        private set
    var catalogSource by mutableStateOf("commons")
        private set
    var glass by mutableStateOf(GlassSettings())
        private set
    val themePresets = mutableStateListOf<NamedTheme>()
    val downloads = mutableStateListOf<Wallpaper>()
    val offline = mutableStateListOf<Wallpaper>()
    val collections = mutableStateListOf<WpCollection>()
    val clockDesigns = mutableStateListOf<ClockDesign>()
    val savedSearches = mutableStateListOf<String>()
    var appearance by mutableStateOf(AppearanceSettings())
        private set
    var layout by mutableStateOf(LayoutSettings())
        private set
    var background by mutableStateOf(BgSettings())
        private set
    var liquid by mutableStateOf(LiquidSettings())
        private set
    var devUnlocked by mutableStateOf(false)
        private set
    var widgetText by mutableStateOf("")
        private set
    var widgetNote by mutableStateOf("")
        private set
    var weatherJson by mutableStateOf("")
        private set
    var weatherAt by mutableStateOf(0L)
        private set
    var widgetVariants by mutableStateOf<Map<String, Int>>(emptyMap())
        private set
    var clockStyle by mutableStateOf(ClockStyle())
        private set
    var widgetStyle by mutableStateOf(WidgetStyle())
        private set
    var tasbih by mutableStateOf(0)
        private set
    var tasbihTarget by mutableStateOf(33)
        private set
    var cityIndex by mutableStateOf(0)
        private set
    var methodIndex by mutableStateOf(0)
        private set
    var accountName by mutableStateOf("")
        private set
    var accountEmail by mutableStateOf("")
        private set

    fun ensure(ctx: Context) { if (!::sp.isInitialized) init(ctx) }

    fun init(ctx: Context) {
        sp = ctx.applicationContext.getSharedPreferences("aura_glass", Context.MODE_PRIVATE)
        onboardingDone = sp.getBoolean("onboarding", false)
        language = sp.getString("language", "system") ?: "system"
        catalogSource = sp.getString("source", "commons") ?: "commons"
        glass = GlassSettings(sp.getFloat("g_alpha", 0.22f), sp.getFloat("g_border", 0.35f),
            sp.getFloat("g_corner", 24f), sp.getInt("g_tint", 0xFF7CF4C8.toInt()))
        liquid = LiquidSettings(sp.getBoolean("lq_on", true), sp.getFloat("lq_blur", 24f), sp.getFloat("lq_reflect", 0.6f),
            sp.getFloat("lq_depth", 0.5f), sp.getFloat("lq_border", 1.2f), sp.getFloat("lq_speed", 1f), sp.getInt("lq_trans", 0), sp.getBoolean("lq_reduce", false))
        devUnlocked = sp.getBoolean("dev", false)
        appearance = AppearanceSettings(sp.getString("ap_theme", "dark") ?: "dark", sp.getBoolean("ap_amoled", true), sp.getInt("ap_font", 0),
            sp.getFloat("ap_fscale", 1f), sp.getInt("ap_num", 0))
        layout = LayoutSettings(sp.getFloat("ly_min", 165f), sp.getFloat("ly_space", 10f), sp.getFloat("ly_corner", 18f), sp.getBoolean("ly_titles", true),
            sp.getFloat("ly_baricon", 24f), sp.getBoolean("ly_barlabels", true), sp.getInt("ly_indicator", 0))
        background = BgSettings(sp.getInt("bg_mode", 0), sp.getInt("bg_c1", 0xFF0B0B10.toInt()), sp.getInt("bg_c2", 0xFF1B1030.toInt()),
            sp.getFloat("bg_blur", 16f), sp.getFloat("bg_dim", 0.35f), sp.getFloat("bg_zoom", 1f), sp.getFloat("bg_bias", 0f), sp.getInt("bg_ver", 0))
        themePresets.clear(); readList("themes").forEach { themePresets.add(NamedTheme(it.optString("name"), it.optString("json"))) }
        downloads.clear(); readList("downloads").forEach { downloads.add(Wallpaper.fromJson(it)) }
        savedSearches.clear(); readList("saved_searches").forEach { savedSearches.add(it.optString("q")) }
        clockDesigns.clear(); readList("clock_designs").forEach { clockDesigns.add(ClockDesign.fromJson(it)) }
        collections.clear()
        readList("collections").forEach { c ->
            val a = c.optJSONArray("items") ?: JSONArray()
            collections.add(WpCollection(c.optString("name"), List(a.length()) { i -> Wallpaper.fromJson(a.getJSONObject(i)) }))
        }
        offline.clear(); readList("offline").forEach { offline.add(Wallpaper.fromJson(it)) }
        clockStyle = readObj("clock")?.let { ClockStyle.fromJson(it) } ?: ClockStyle()
        widgetStyle = WidgetStyle(sp.getInt("w_color", 0xFFFFFFFF.toInt()), sp.getFloat("w_alpha", 0.5f), sp.getFloat("w_scale", 1f), sp.getInt("w_bg", 0xFF000000.toInt()))
        widgetText = sp.getString("w_text", "") ?: ""; widgetNote = sp.getString("w_note", "") ?: ""
        weatherJson = sp.getString("weather_json", "") ?: ""; weatherAt = sp.getLong("weather_at", 0L)
        widgetVariants = try { JSONObject(sp.getString("w_variants", "{}") ?: "{}").let { o -> o.keys().asSequence().associateWith { k -> o.optInt(k) } } } catch (e: Exception) { emptyMap() }
        tasbih = sp.getInt("tasbih", 0); tasbihTarget = sp.getInt("tasbih_target", 33)
        cityIndex = sp.getInt("city", 0); methodIndex = sp.getInt("method", 0)
        accountName = sp.getString("acc_name", "") ?: ""; accountEmail = sp.getString("acc_email", "") ?: ""
        history.clear(); readList("history").forEach { history.add(HistoryItem(it.optString("q"), it.optString("t"))) }
        favorites.clear(); readList("favorites").forEach { favorites.add(Wallpaper.fromJson(it)) }
        recents.clear(); readList("recents").forEach { recents.add(Wallpaper.fromJson(it)) }
        imported.clear(); readList("imported").forEach { imported.add(Wallpaper.fromJson(it)) }
        presets.clear(); readList("presets").forEach { presets.add(NamedClock(it.optString("name"), ClockStyle.fromJson(it.getJSONObject("style")))) }
    }

    // ---- helpers
    private fun readList(key: String): List<JSONObject> {
        val a = try { JSONArray(sp.getString(key, "[]")) } catch (e: Exception) { JSONArray() }
        return List(a.length()) { a.getJSONObject(it) }
    }
    private fun writeList(key: String, items: List<JSONObject>) { sp.edit().putString(key, JSONArray(items).toString()).apply() }
    private fun readObj(key: String): JSONObject? = try { sp.getString(key, null)?.let { JSONObject(it) } } catch (e: Exception) { null }

    // ---- onboarding / prefs
    fun finishOnboarding() { onboardingDone = true; showIntro = false; sp.edit().putBoolean("onboarding", true).apply() }
    @JvmName("changeLanguage") fun setLanguage(code: String) { language = code; sp.edit().putString("language", code).apply() }
    /** The source actually used by the app: ordinary users always get the default; only the server-verified owner can switch. */
    val activeSource: String get() = if (com.fareshelmy.auraglass.util.Auth.role == "owner") catalogSource else "commons"
    @JvmName("changeCatalogSource") fun setCatalogSource(s: String) { if (com.fareshelmy.auraglass.util.Auth.role != "owner") return; catalogSource = s; sp.edit().putString("source", s).apply() }

    // ---- search history
    fun addHistory(q: String) {
        history.removeAll { it.query.equals(q, ignoreCase = true) }
        history.add(0, HistoryItem(q, ""))
        while (history.size > 30) history.removeAt(history.size - 1)
        saveHistory()
    }
    fun setHistoryThumb(q: String, thumb: String) {
        val i = history.indexOfFirst { it.query.equals(q, ignoreCase = true) }
        if (i >= 0 && history[i].thumb != thumb) { history[i] = history[i].copy(thumb = thumb); saveHistory() }
    }
    fun removeHistory(item: HistoryItem) { history.remove(item); saveHistory() }
    fun clearHistory() { history.clear(); saveHistory() }
    private fun saveHistory() = writeList("history", history.map { JSONObject().put("q", it.query).put("t", it.thumb) })

    // ---- favorites / recents / imported
    fun isFav(id: String) = favorites.any { it.id == id }
    fun toggleFav(w: Wallpaper) {
        val i = favorites.indexOfFirst { it.id == w.id }
        if (i >= 0) favorites.removeAt(i) else favorites.add(0, w)
        writeList("favorites", favorites.map { it.toJson() })
    }
    fun addRecent(w: Wallpaper) {
        recents.removeAll { it.id == w.id }
        recents.add(0, w)
        while (recents.size > 40) recents.removeAt(recents.size - 1)
        writeList("recents", recents.map { it.toJson() })
    }
    fun addImported(w: Wallpaper) { imported.add(0, w); writeList("imported", imported.map { it.toJson() }) }
    fun removeImported(w: Wallpaper) {
        imported.removeAll { it.id == w.id }
        favorites.removeAll { it.id == w.id }; recents.removeAll { it.id == w.id }
        writeList("imported", imported.map { it.toJson() })
        writeList("favorites", favorites.map { it.toJson() }); writeList("recents", recents.map { it.toJson() })
        try { File(android.net.Uri.parse(w.full).path ?: "").delete() } catch (_: Exception) {}
    }

    // ---- glass (reset touches ONLY glass settings)
    fun updateGlass(g: GlassSettings) {
        glass = g
        sp.edit().putFloat("g_alpha", g.alpha).putFloat("g_border", g.border).putFloat("g_corner", g.corner).putInt("g_tint", g.tint).apply()
    }
    fun resetGlass() { updateGlass(GlassSettings()); updateLiquid(LiquidSettings()) }
    /** Restores every visual setting to its default. Favorites, history, imported photos, chats and account are NOT touched. */
    fun resetAllAppearance() {
        updateGlass(GlassSettings()); updateLiquid(LiquidSettings()); updateAppearance(AppearanceSettings())
        updateLayout(LayoutSettings()); updateBackground(BgSettings())
    }
    fun updateLiquid(l: LiquidSettings) {
        liquid = l
        sp.edit().putBoolean("lq_on", l.on).putFloat("lq_blur", l.blur).putFloat("lq_reflect", l.reflect)
            .putFloat("lq_depth", l.depth).putFloat("lq_border", l.borderWidth).putFloat("lq_speed", l.animSpeed)
            .putInt("lq_trans", l.transition).putBoolean("lq_reduce", l.reduceMotion).apply()
    }
    fun updateAppearance(a: AppearanceSettings) {
        appearance = a
        sp.edit().putString("ap_theme", a.themeMode).putBoolean("ap_amoled", a.amoled).putInt("ap_font", a.fontIdx)
            .putFloat("ap_fscale", a.fontScale).putInt("ap_num", a.numerals).apply()
    }
    fun updateLayout(l: LayoutSettings) {
        layout = l
        sp.edit().putFloat("ly_min", l.minCard).putFloat("ly_space", l.spacing).putFloat("ly_corner", l.cardCorner).putBoolean("ly_titles", l.showTitles)
            .putFloat("ly_baricon", l.barIcon).putBoolean("ly_barlabels", l.barLabels).putInt("ly_indicator", l.indicator).apply()
    }
    fun updateBackground(b: BgSettings) {
        background = b
        sp.edit().putInt("bg_mode", b.mode).putInt("bg_c1", b.c1).putInt("bg_c2", b.c2).putFloat("bg_blur", b.blur)
            .putFloat("bg_dim", b.dim).putFloat("bg_zoom", b.zoom).putFloat("bg_bias", b.bias).putInt("bg_ver", b.imageVersion).apply()
    }
    fun addDownload(w: Wallpaper) {
        downloads.removeAll { it.id == w.id }; downloads.add(0, w)
        while (downloads.size > 100) downloads.removeAt(downloads.size - 1)
        writeList("downloads", downloads.map { it.toJson() })
    }
    fun isOffline(origId: String) = offline.any { it.id == "off:$origId" }
    fun addOffline(w: Wallpaper) { offline.removeAll { it.id == w.id }; offline.add(0, w); writeList("offline", offline.map { it.toJson() }) }
    fun removeOffline(w: Wallpaper) {
        offline.removeAll { it.id == w.id }; writeList("offline", offline.map { it.toJson() })
        try { File(android.net.Uri.parse(w.full).path ?: "").delete() } catch (_: Exception) {}
    }
    fun toggleSavedSearch(q: String) {
        val i = savedSearches.indexOfFirst { it.equals(q, true) }
        if (i >= 0) savedSearches.removeAt(i) else savedSearches.add(0, q)
        writeList("saved_searches", savedSearches.map { JSONObject().put("q", it) })
    }
    fun isSavedSearch(q: String) = savedSearches.any { it.equals(q, true) }
    fun saveClockDesign(d: ClockDesign) {
        val i = clockDesigns.indexOfFirst { it.name == d.name }
        if (i >= 0) clockDesigns[i] = d else clockDesigns.add(0, d)
        writeList("clock_designs", clockDesigns.map { it.toJson() })
    }
    fun deleteClockDesign(d: ClockDesign) { clockDesigns.remove(d); writeList("clock_designs", clockDesigns.map { it.toJson() }) }
    private fun saveCollections() = writeList("collections", collections.map { c -> JSONObject().put("name", c.name).put("items", JSONArray(c.items.map { it.toJson() })) })
    fun createCollection(name: String): Boolean {
        val n = name.trim().take(40)
        if (n.isEmpty() || collections.any { it.name.equals(n, true) }) return false
        collections.add(0, WpCollection(n, emptyList())); saveCollections(); return true
    }
    fun deleteCollection(name: String) { collections.removeAll { it.name == name }; saveCollections() }
    fun inCollection(name: String, id: String) = collections.firstOrNull { it.name == name }?.items?.any { it.id == id } == true
    fun toggleInCollection(name: String, w: Wallpaper) {
        val i = collections.indexOfFirst { it.name == name }; if (i < 0) return
        val c = collections[i]
        collections[i] = c.copy(items = if (c.items.any { it.id == w.id }) c.items.filter { it.id != w.id } else listOf(w) + c.items)
        saveCollections()
    }
    fun clearDownloads() { downloads.clear(); writeList("downloads", emptyList()) }

    /** Everything visual in one JSON document (no personal data, no image file). Used for presets and import/export. */
    fun exportConfig(): String = JSONObject()
        .put("version", 1)
        .put("glass", JSONObject().put("alpha", glass.alpha.toDouble()).put("border", glass.border.toDouble()).put("corner", glass.corner.toDouble()).put("tint", glass.tint))
        .put("liquid", JSONObject().put("on", liquid.on).put("blur", liquid.blur.toDouble()).put("reflect", liquid.reflect.toDouble())
            .put("depth", liquid.depth.toDouble()).put("borderWidth", liquid.borderWidth.toDouble()).put("animSpeed", liquid.animSpeed.toDouble())
            .put("transition", liquid.transition).put("reduceMotion", liquid.reduceMotion))
        .put("appearance", JSONObject().put("themeMode", appearance.themeMode).put("amoled", appearance.amoled).put("fontIdx", appearance.fontIdx)
            .put("fontScale", appearance.fontScale.toDouble()).put("numerals", appearance.numerals))
        .put("layout", JSONObject().put("minCard", layout.minCard.toDouble()).put("spacing", layout.spacing.toDouble())
            .put("cardCorner", layout.cardCorner.toDouble()).put("showTitles", layout.showTitles)
            .put("barIcon", layout.barIcon.toDouble()).put("barLabels", layout.barLabels).put("indicator", layout.indicator))
        .put("background", JSONObject().put("mode", if (background.mode == 2) 0 else background.mode).put("c1", background.c1).put("c2", background.c2)
            .put("blur", background.blur.toDouble()).put("dim", background.dim.toDouble()))
        .toString(2)

    /** Returns false (and changes nothing) if the text is not a valid Aura Glass configuration. */
    fun importConfig(text: String): Boolean {
        return try {
            val o = JSONObject(text)
            if (o.optInt("version", 0) != 1) return false
            o.optJSONObject("glass")?.let { g -> updateGlass(GlassSettings(g.optDouble("alpha", 0.22).toFloat().coerceIn(0.04f, 0.6f), g.optDouble("border", 0.35).toFloat().coerceIn(0f, 1f),
                g.optDouble("corner", 24.0).toFloat().coerceIn(0f, 40f), g.optInt("tint", glass.tint))) }
            o.optJSONObject("liquid")?.let { l -> updateLiquid(LiquidSettings(l.optBoolean("on", true), l.optDouble("blur", 24.0).toFloat().coerceIn(0f, 40f),
                l.optDouble("reflect", 0.6).toFloat().coerceIn(0f, 1f), l.optDouble("depth", 0.5).toFloat().coerceIn(0f, 1f),
                l.optDouble("borderWidth", 1.2).toFloat().coerceIn(0.5f, 3f), l.optDouble("animSpeed", 1.0).toFloat().coerceIn(0.5f, 2f),
                l.optInt("transition", 0).coerceIn(0, 2), l.optBoolean("reduceMotion", false))) }
            o.optJSONObject("appearance")?.let { a -> updateAppearance(AppearanceSettings(a.optString("themeMode", "dark").takeIf { it in listOf("dark", "light", "system") } ?: "dark",
                a.optBoolean("amoled", true), a.optInt("fontIdx", 0).coerceIn(0, 4), a.optDouble("fontScale", 1.0).toFloat().coerceIn(0.8f, 1.4f), a.optInt("numerals", 0).coerceIn(0, 2))) }
            o.optJSONObject("layout")?.let { l -> updateLayout(LayoutSettings(l.optDouble("minCard", 165.0).toFloat().coerceIn(110f, 300f),
                l.optDouble("spacing", 10.0).toFloat().coerceIn(2f, 24f), l.optDouble("cardCorner", 18.0).toFloat().coerceIn(0f, 32f), l.optBoolean("showTitles", true),
                l.optDouble("barIcon", 24.0).toFloat().coerceIn(18f, 32f), l.optBoolean("barLabels", true), l.optInt("indicator", 0).coerceIn(0, 2))) }
            o.optJSONObject("background")?.let { b -> updateBackground(background.copy(mode = b.optInt("mode", 0).coerceIn(0, 1), c1 = b.optInt("c1", background.c1), c2 = b.optInt("c2", background.c2),
                blur = b.optDouble("blur", 16.0).toFloat().coerceIn(0f, 40f), dim = b.optDouble("dim", 0.35).toFloat().coerceIn(0f, 0.9f))) }
            true
        } catch (e: Exception) { false }
    }
    fun saveThemePreset(name: String) {
        themePresets.add(0, NamedTheme(name, exportConfig()))
        writeList("themes", themePresets.map { JSONObject().put("name", it.name).put("json", it.json) })
    }
    fun applyThemePreset(t: NamedTheme) { importConfig(t.json) }
    fun deleteThemePreset(t: NamedTheme) {
        themePresets.remove(t)
        writeList("themes", themePresets.map { JSONObject().put("name", it.name).put("json", it.json) })
    }

    fun unlockDev() { devUnlocked = true; sp.edit().putBoolean("dev", true).apply() }
    fun lockDev() { devUnlocked = false; sp.edit().putBoolean("dev", false).apply() }

    // ---- clock
    fun updateClock(s: ClockStyle) { clockStyle = s; sp.edit().putString("clock", s.toJson().toString()).apply() }
    fun savePreset(name: String, s: ClockStyle) { presets.add(0, NamedClock(name, s)); writePresets() }
    fun deletePreset(p: NamedClock) { presets.remove(p); writePresets() }
    private fun writePresets() = writeList("presets", presets.map { JSONObject().put("name", it.name).put("style", it.style.toJson()) })

    // ---- islamic widgets
    fun updateWidgetStyle(w: WidgetStyle) { widgetStyle = w; sp.edit().putInt("w_color", w.textColor).putFloat("w_alpha", w.bgAlpha).putFloat("w_scale", w.scale).putInt("w_bg", w.bgColor).apply() }
    @JvmName("changeWidgetText") fun setWidgetText(t: String) { widgetText = t.take(200); sp.edit().putString("w_text", widgetText).apply() }
    @JvmName("changeWidgetNote") fun setWidgetNote(t: String) { widgetNote = t.take(600); sp.edit().putString("w_note", widgetNote).apply() }
    fun saveWeather(json: String) { weatherJson = json; weatherAt = System.currentTimeMillis(); sp.edit().putString("weather_json", json).putLong("weather_at", weatherAt).apply() }
    fun widgetVariant(key: String): Int = widgetVariants[key] ?: 0
    fun setWidgetVariant(key: String, v: Int) {
        widgetVariants = widgetVariants + (key to v)
        sp.edit().putString("w_variants", JSONObject(widgetVariants as Map<*, *>).toString()).apply()
    }
    fun incTasbih() { tasbih += 1; sp.edit().putInt("tasbih", tasbih).apply() }
    fun resetTasbih() { tasbih = 0; sp.edit().putInt("tasbih", 0).apply() }
    @JvmName("changeTasbihTarget") fun setTasbihTarget(t: Int) { tasbihTarget = t; sp.edit().putInt("tasbih_target", t).apply() }
    fun setCity(i: Int) { cityIndex = i; sp.edit().putInt("city", i).apply() }
    fun setMethod(i: Int) { methodIndex = i; sp.edit().putInt("method", i).apply() }

    // ---- account (display info only; never the token)
    fun setAccount(name: String, email: String) {
        accountName = name; accountEmail = email
        sp.edit().putString("acc_name", name).putString("acc_email", email).apply()
    }
    fun clearAccount() = setAccount("", "")
}
