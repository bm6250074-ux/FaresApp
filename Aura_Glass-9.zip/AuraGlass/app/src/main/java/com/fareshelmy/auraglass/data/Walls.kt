package com.fareshelmy.auraglass.data

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.util.LruCache
import com.fareshelmy.auraglass.R
import java.util.Locale
import java.util.Random
import kotlin.math.cos
import kotlin.math.sin

/**
 * Built-in wallpaper library: 11 categories x 12 designs = 132 ORIGINAL wallpapers generated on the device
 * (real bitmaps, 1080x1920, 9:16). They work offline, need no licence attribution and are never duplicates
 * (each design has its own structure + seeded variation). They complement the online sources.
 */
object Walls {
    data class Cat(val id: String, val titleRes: Int, val en: String, val ar: String, val aliases: List<String>)

    const val PER = 12

    val cats = listOf(
        Cat("amoled", R.string.t_amoled, "AMOLED", "AMOLED", listOf("amoled", "oled", "pure amoled")),
        Cat("black", R.string.t_black, "Pure black", "أسود نقي", listOf("pure black", "black", "dark black", "أسود", "اسود", "سوداء")),
        Cat("minimal", R.string.t_minimal, "Minimal", "بسيط", listOf("minimal", "minimalist", "simple", "بسيط", "ميني")),
        Cat("abstract", R.string.t_abstract, "Abstract", "تجريدي", listOf("abstract", "art", "تجريدي", "فن")),
        Cat("gradient", R.string.t_gradient, "Gradient", "تدرج", listOf("gradient", "gradients", "colorful", "تدرج", "تدرجات")),
        Cat("dark", R.string.t_dark, "Dark", "داكن", listOf("dark", "night", "داكن", "ليل")),
        Cat("luxury", R.string.t_luxury, "Luxury", "فخم", listOf("luxury", "gold", "golden", "premium", "فخم", "ذهبي", "فاخر")),
        Cat("islamic", R.string.t_islamic, "Islamic", "إسلامي", listOf("islamic", "islam", "muslim", "geometric", "إسلامي", "اسلامي", "اسلام", "زخرفة")),
        Cat("glass", R.string.t_glass, "Glass", "زجاج", listOf("glass", "glassy", "frosted", "blur", "زجاج")),
        Cat("space", R.string.t_space, "Space", "فضاء", listOf("space", "galaxy", "galaxies", "stars", "nebula", "planet", "فضاء", "مجرة", "نجوم")),
        Cat("tech", R.string.t_tech, "Technology", "تقنية", listOf("tech", "technology", "cyber", "circuit", "digital", "تقنية", "تكنولوجيا")),
    )

    private var cachedLang = ""
    private var cached: List<Wallpaper> = emptyList()

    /** All built-in wallpapers (titles follow the app language). */
    fun all(): List<Wallpaper> {
        val lang = Locale.getDefault().language
        if (lang != cachedLang || cached.isEmpty()) {
            cached = cats.flatMapIndexed { ci, c ->
                (0 until PER).map { v ->
                    Wallpaper(
                        id = "gen:${c.id}:$v", title = "${if (lang == "ar") c.ar else c.en} ${v + 1}", thumb = "", full = "",
                        creator = "Aura Glass", license = "Original (built-in)", tags = listOf(c.id) + c.aliases,
                        source = "gen", seed = ci * 100 + v, width = 1080, height = 1920,
                    )
                }
            }
            cachedLang = lang
        }
        return cached
    }

    fun inCategory(id: String): List<Wallpaper> = all().filter { it.tags.firstOrNull() == id }

    /** Local search over category names/aliases (English + Arabic). */
    fun search(q: String): List<Wallpaper> {
        val tokens = q.lowercase().split(' ', '-', '_').map { it.trim() }.filter { it.length >= 2 }
        if (tokens.isEmpty()) return emptyList()
        val hit = cats.filter { c -> tokens.any { t -> c.aliases.any { a -> a.lowercase() == t || (t.length >= 3 && (a.lowercase().contains(t) || t.contains(a.lowercase()))) } } }
        return hit.flatMap { inCategory(it.id) }
    }

    private val thumbCache = object : LruCache<Int, Bitmap>(40) {}
    /** Small render for cards (270x480), cached. */
    fun thumb(seed: Int): Bitmap = thumbCache.get(seed) ?: render(seed, 270, 480).also { thumbCache.put(seed, it) }

    private fun hsv(h: Float, s: Float, v: Float) = Color.HSVToColor(floatArrayOf(((h % 360f) + 360f) % 360f, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f)))
    private fun al(c: Int, a: Int) = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)
    private fun fill(c: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c }
    private fun line(c: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c; style = Paint.Style.STROKE; strokeWidth = w; strokeCap = Paint.Cap.ROUND }
    private fun glow(c: Int, blur: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c; maskFilter = BlurMaskFilter(blur, BlurMaskFilter.Blur.NORMAL) }
    private fun radial(c: Canvas, cx: Float, cy: Float, r: Float, color: Int, a: Int, w: Float, h: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG); p.shader = RadialGradient(cx, cy, r, al(color, a), al(color, 0), Shader.TileMode.CLAMP); c.drawRect(0f, 0f, w, h, p)
    }

    fun render(seed: Int, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val W = w.toFloat(); val H = h.toFloat()
        val ci = (seed / 100).coerceIn(0, cats.lastIndex); val v = seed % 100
        val r = Random(seed * 7919L + 13)
        val hue = (v * 29f + ci * 47f) % 360f
        val k = W / 270f // stroke scale relative to thumbnail
        when (cats[ci].id) {
            "amoled" -> {
                c.drawColor(Color.BLACK)
                val accent = hsv(hue, 0.85f, 1f)
                when (v % 4) {
                    0 -> radial(c, W * (0.2f + r.nextFloat() * 0.6f), H * (0.15f + r.nextFloat() * 0.5f), W * 0.85f, accent, 200, W, H)
                    1 -> { val cx = W / 2f; val cy = H * (0.35f + r.nextFloat() * 0.2f); c.drawCircle(cx, cy, W * 0.32f, glow(al(accent, 220), 28f * k)); c.drawCircle(cx, cy, W * 0.32f, line(accent, 3f * k)) }
                    2 -> { radial(c, W * 0.25f, H * 0.3f, W * 0.6f, accent, 190, W, H); radial(c, W * 0.8f, H * 0.7f, W * 0.7f, hsv(hue + 60f, 0.8f, 1f), 170, W, H) }
                    else -> { val p = Paint(Paint.ANTI_ALIAS_FLAG); p.shader = LinearGradient(0f, H, 0f, H * 0.55f, al(accent, 230), al(accent, 0), Shader.TileMode.CLAMP); c.drawRect(0f, H * 0.5f, W, H, p) }
                }
            }
            "black" -> {
                c.drawColor(Color.BLACK)
                when (v % 6) {
                    0 -> c.drawCircle(W / 2f, H / 2f, 3f * k, fill(al(Color.WHITE, 90)))
                    1 -> c.drawLine(W * 0.15f, H / 3f, W * 0.85f, H / 3f, line(al(Color.WHITE, 55), 1f * k))
                    2 -> { val s = 26f * k; var y = s; while (y < H) { var x = s; while (x < W) { c.drawCircle(x, y, 0.9f * k, fill(al(Color.WHITE, 28))); x += s }; y += s } }
                    3 -> radial(c, 0f, 0f, W * 1.1f, Color.WHITE, 22, W, H)
                    4 -> c.drawLine(W / 2f, H * 0.2f, W / 2f, H * 0.8f, line(al(Color.WHITE, 45), 1f * k))
                    else -> { val rc = RectF(W * 0.18f, H * 0.4f, W * 0.82f, H * 0.6f); c.drawRoundRect(rc, 30f * k, 30f * k, line(al(Color.WHITE, 38), 1.2f * k)) }
                }
            }
            "minimal" -> {
                val light = v % 2 == 0
                c.drawColor(if (light) hsv(hue, 0.18f, 0.96f) else hsv(hue, 0.35f, 0.14f))
                val ac = hsv(hue + 25f, if (light) 0.55f else 0.65f, if (light) 0.9f else 0.95f)
                when (v % 4) {
                    0 -> c.drawCircle(W * 0.5f, H * 0.62f, W * 0.34f, fill(ac))
                    1 -> c.drawCircle(W * 0.9f, H * 0.18f, W * 0.55f, fill(al(ac, 235)))
                    2 -> { c.drawRoundRect(RectF(W * 0.2f, H * 0.3f, W * 0.8f, H * 0.7f), W * 0.3f, W * 0.3f, fill(al(ac, 230))) }
                    else -> { val pth = Path(); pth.moveTo(0f, H * 0.7f); pth.quadTo(W * 0.5f, H * 0.5f, W, H * 0.72f); pth.lineTo(W, H); pth.lineTo(0f, H); pth.close(); c.drawPath(pth, fill(ac)) }
                }
            }
            "abstract" -> {
                val bg = Paint(); bg.shader = LinearGradient(0f, 0f, W, H, hsv(hue, 0.6f, 0.14f), hsv(hue + 50f, 0.7f, 0.05f), Shader.TileMode.CLAMP); c.drawRect(0f, 0f, W, H, bg)
                for (i in 0 until 7) {
                    val cx = r.nextFloat() * W; val cy = r.nextFloat() * H; val rad = W * (0.15f + r.nextFloat() * 0.4f)
                    val col = hsv(hue + i * 22f, 0.75f, 0.95f)
                    if (i % 3 == 0) c.drawCircle(cx, cy, rad, line(al(col, 170), 3f * k)) else c.drawCircle(cx, cy, rad, fill(al(col, 80 + r.nextInt(60))))
                }
                radial(c, W * r.nextFloat(), H * r.nextFloat(), W * 0.9f, hsv(hue + 120f, 0.8f, 1f), 120, W, H)
            }
            "gradient" -> {
                val c1 = hsv(hue, 0.8f, 0.95f); val c2 = hsv(hue + 70f, 0.75f, 0.95f); val c3 = hsv(hue + 150f, 0.7f, 0.9f)
                val p = Paint()
                p.shader = when (v % 4) {
                    0 -> LinearGradient(0f, 0f, 0f, H, intArrayOf(c1, c2, c3), null, Shader.TileMode.CLAMP)
                    1 -> LinearGradient(0f, 0f, W, H, c1, c3, Shader.TileMode.CLAMP)
                    2 -> RadialGradient(W * 0.5f, H * 0.4f, H * 0.7f, intArrayOf(c2, c1, hsv(hue, 0.9f, 0.25f)), null, Shader.TileMode.CLAMP)
                    else -> SweepGradient(W * 0.5f, H * 0.5f, intArrayOf(c1, c2, c3, c1), null)
                }
                c.drawRect(0f, 0f, W, H, p)
            }
            "dark" -> {
                val p = Paint(); p.shader = LinearGradient(0f, 0f, 0f, H, hsv(hue, 0.55f, 0.16f), hsv(hue + 30f, 0.6f, 0.03f), Shader.TileMode.CLAMP); c.drawRect(0f, 0f, W, H, p)
                val beam = Path(); val bx = W * (0.2f + r.nextFloat() * 0.5f)
                beam.moveTo(bx, 0f); beam.lineTo(bx + W * 0.35f, 0f); beam.lineTo(bx + W * 0.9f, H); beam.lineTo(bx - W * 0.2f, H); beam.close()
                val bp = Paint(Paint.ANTI_ALIAS_FLAG); bp.shader = LinearGradient(0f, 0f, 0f, H, al(hsv(hue, 0.4f, 1f), 55), al(hsv(hue, 0.4f, 1f), 0), Shader.TileMode.CLAMP); c.drawPath(beam, bp)
            }
            "luxury" -> {
                c.drawColor(hsv(30f, 0.3f, 0.05f))
                val gold = Color.parseColor("#D4AF37"); val gold2 = Color.parseColor("#F5E6A8")
                when (v % 4) {
                    0 -> { var x = -H; while (x < W) { c.drawLine(x, H, x + H, 0f, line(al(gold, 150), 1.4f * k)); x += 22f * k } }
                    1 -> { for (i in 1..9) c.drawArc(RectF(W / 2f - i * W * 0.1f, H - i * W * 0.1f, W / 2f + i * W * 0.1f, H + i * W * 0.1f), 180f, 180f, false, line(al(gold, 220 - i * 15), 1.6f * k)) }
                    2 -> { c.drawCircle(W / 2f, H * 0.42f, W * 0.34f, line(gold, 2.4f * k)); c.drawCircle(W / 2f, H * 0.42f, W * 0.28f, line(al(gold2, 160), 1f * k)); radial(c, W / 2f, H * 0.42f, W * 0.6f, gold, 60, W, H) }
                    else -> { val m = 14f * k; c.drawRect(m, m, W - m, H - m, line(gold, 2f * k)); c.drawRect(m * 2f, m * 2f, W - m * 2f, H - m * 2f, line(al(gold2, 140), 1f * k)); val sp = Paint(); sp.shader = LinearGradient(0f, 0f, 0f, H, al(gold, 0), al(gold, 90), Shader.TileMode.CLAMP); c.drawRect(W * 0.46f, 0f, W * 0.54f, H, sp) }
                }
            }
            "islamic" -> {
                val bgp = Paint(); bgp.shader = LinearGradient(0f, 0f, W, H, hsv(150f + (v % 3) * 35f, 0.7f, 0.18f), hsv(200f + (v % 4) * 20f, 0.8f, 0.06f), Shader.TileMode.CLAMP); c.drawRect(0f, 0f, W, H, bgp)
                val stroke = line(if (v % 3 == 0) Color.parseColor("#D4AF37") else if (v % 3 == 1) Color.parseColor("#7CF4C8") else Color.WHITE, 1.4f * k)
                stroke.alpha = 190
                val cell = W / (3 + v % 4)
                var cy = 0f
                while (cy < H + cell) {
                    var cx = 0f
                    while (cx < W + cell) {
                        val rad = cell * 0.46f
                        for (rot in 0..1) {
                            val pth = Path()
                            for (i in 0 until 4) {
                                val ang = Math.toRadians(i * 90.0 + rot * 45.0 + 45.0)
                                val px = cx + (rad * cos(ang)).toFloat(); val py = cy + (rad * sin(ang)).toFloat()
                                if (i == 0) pth.moveTo(px, py) else pth.lineTo(px, py)
                            }
                            pth.close(); c.drawPath(pth, stroke)
                        }
                        c.drawCircle(cx, cy, rad * 0.32f, stroke)
                        cx += cell
                    }
                    cy += cell
                }
                radial(c, W / 2f, H / 2f, W * 0.9f, Color.BLACK, 0, W, H)
            }
            "glass" -> {
                val bgp = Paint(); bgp.shader = LinearGradient(0f, 0f, W, H, hsv(hue, 0.85f, 0.5f), hsv(hue + 90f, 0.85f, 0.35f), Shader.TileMode.CLAMP); c.drawRect(0f, 0f, W, H, bgp)
                for (i in 0 until 3) c.drawCircle(r.nextFloat() * W, r.nextFloat() * H, W * (0.3f + r.nextFloat() * 0.25f), glow(hsv(hue + i * 55f, 0.9f, 1f), 40f * k))
                for (i in 0 until 3) {
                    val x = W * (0.08f + r.nextFloat() * 0.35f); val y = H * (0.1f + i * 0.28f + r.nextFloat() * 0.06f)
                    val rc = RectF(x, y, x + W * (0.45f + r.nextFloat() * 0.3f), y + H * 0.2f)
                    c.drawRoundRect(rc, 28f * k, 28f * k, fill(al(Color.WHITE, 42)))
                    c.drawRoundRect(rc, 28f * k, 28f * k, line(al(Color.WHITE, 140), 1.4f * k))
                }
            }
            "space" -> {
                c.drawColor(hsv(230f, 0.6f, 0.04f))
                radial(c, W * r.nextFloat(), H * r.nextFloat(), W * 0.9f, hsv(hue, 0.8f, 1f), 110, W, H)
                radial(c, W * r.nextFloat(), H * r.nextFloat(), W * 0.8f, hsv(hue + 90f, 0.8f, 1f), 90, W, H)
                for (i in 0 until 260) { val s = (0.4f + r.nextFloat() * 1.3f) * k; c.drawCircle(r.nextFloat() * W, r.nextFloat() * H, s, fill(al(Color.WHITE, 90 + r.nextInt(165)))) }
                if (v % 3 == 0) {
                    val cx = W * 0.62f; val cy = H * 0.38f; val rad = W * 0.2f
                    val pp = Paint(Paint.ANTI_ALIAS_FLAG); pp.shader = RadialGradient(cx - rad * 0.3f, cy - rad * 0.3f, rad * 1.3f, hsv(hue, 0.5f, 1f), hsv(hue + 20f, 0.8f, 0.15f), Shader.TileMode.CLAMP)
                    c.drawCircle(cx, cy, rad, pp)
                    c.save(); c.rotate(-18f, cx, cy); c.drawOval(RectF(cx - rad * 1.7f, cy - rad * 0.3f, cx + rad * 1.7f, cy + rad * 0.3f), line(al(Color.WHITE, 150), 2f * k)); c.restore()
                }
            }
            else -> { // tech
                c.drawColor(hsv(215f, 0.7f, 0.07f))
                val g = line(al(hsv(190f, 0.6f, 1f), 26), 1f * k); val sp = 30f * k
                var x = 0f; while (x < W) { c.drawLine(x, 0f, x, H, g); x += sp }
                var y = 0f; while (y < H) { c.drawLine(0f, y, W, y, g); y += sp }
                val trace = line(al(hsv(hue % 80f + 170f, 0.8f, 1f), 190), 2f * k)
                for (i in 0 until 9) {
                    var px = (r.nextInt((W / sp).toInt()) * sp); var py = (r.nextInt((H / sp).toInt()) * sp)
                    val pth = Path(); pth.moveTo(px, py)
                    for (s in 0 until 4) { if (s % 2 == 0) px += (r.nextInt(5) - 2) * sp else py += (r.nextInt(7) - 3) * sp; pth.lineTo(px, py) }
                    c.drawPath(pth, trace); c.drawCircle(px, py, 4f * k, glow(hsv(190f, 0.7f, 1f), 6f * k))
                    c.drawCircle(px, py, 2.4f * k, fill(Color.WHITE))
                }
            }
        }
        return bmp
    }
}
