package com.fareshelmy.auraglass.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridItemSpanScope
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.material3.FilterChip
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.data.HistoryItem
import com.fareshelmy.auraglass.data.Sources
import com.fareshelmy.auraglass.data.Store
import com.fareshelmy.auraglass.data.Wallpaper

@Composable
fun SearchScreen(nav: NavController) {
    var text by rememberSaveable { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }

    fun submit(q: String) {
        val t = q.trim()
        if (t.isNotEmpty()) { Store.addHistory(t); nav.navigate(resultsRoute(t)) }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding().padding(horizontal = 12.dp)) {
        Row(Modifier.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.weight(1f).height(56.dp).clip(RoundedCornerShape(32.dp))
                    .border(2.dp, Pal.onSurface, RoundedCornerShape(32.dp)).padding(horizontal = 18.dp),
                contentAlignment = Alignment.CenterStart,
            ) {
                BasicTextField(
                    value = text, onValueChange = { text = it }, singleLine = true,
                    textStyle = TextStyle(color = Pal.onSurface, fontSize = 18.sp),
                    cursorBrush = SolidColor(Pal.onSurface),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { submit(text) }),
                    modifier = Modifier.fillMaxWidth().focusRequester(focus),
                    decorationBox = { inner ->
                        Box { if (text.isEmpty()) Text(stringResource(R.string.search_hint), color = Pal.muted, fontSize = 18.sp); inner() }
                    },
                )
            }
            TextButton(onClick = { nav.popBackStack() }) { Text(stringResource(R.string.cancel), fontSize = 17.sp, color = Pal.onSurface) }
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            if (text.isNotBlank()) {
                val sugg = Suggest.suggest(text, Store.history.map { it.query })
                if (sugg.isNotEmpty()) {
                    item { Text(stringResource(R.string.suggestions), fontSize = 13.sp, color = Pal.muted, modifier = Modifier.padding(top = 8.dp)) }
                    items(sugg) { sg -> Row(Modifier.fillMaxWidth().clickable { submit(sg) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Search, null, tint = Pal.muted); Text(sg, fontSize = 17.sp, modifier = Modifier.padding(start = 12.dp)) } }
                }
                item {
                    Row(Modifier.fillMaxWidth().clickable { submit(text) }.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Search, null)
                        Text(stringResource(R.string.search_for, text.trim()), fontSize = 18.sp, modifier = Modifier.padding(start = 12.dp))
                    }
                }
            }
            if (Store.savedSearches.isNotEmpty() && text.isBlank()) {
                item { Text(stringResource(R.string.saved_searches), fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
                item {
                    androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                        items(Store.savedSearches.toList()) { sv -> androidx.compose.material3.AssistChip(onClick = { submit(sv) }, label = { Text(sv) }) }
                    }
                }
            }
            if (Store.history.isEmpty()) {
                item { Text(stringResource(R.string.no_history), color = Pal.muted, modifier = Modifier.padding(vertical = 24.dp)) }
            } else {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.recent_searches), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { Store.clearHistory() }) { Text(stringResource(R.string.clear_all)) }
                    }
                }
                items(Store.history.toList(), key = { it.query }) { h -> HistoryRow(h, onClick = { submit(h.query) }) }
            }
        }
    }
}

@Composable
private fun HistoryRow(h: HistoryItem, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(72.dp).clip(RoundedCornerShape(18.dp)).background(Color(0xFF1B1B1F)), contentAlignment = Alignment.Center) {
            if (h.thumb.isNotBlank()) AsyncImage(h.thumb, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Icon(Icons.Default.Search, null, tint = Color(0xFF8A8A92))
        }
        Text(h.query, fontSize = 22.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(horizontal = 16.dp))
        IconButton(onClick = { Store.toggleSavedSearch(h.query) }) { Icon(if (Store.isSavedSearch(h.query)) Icons.Default.Star else Icons.Default.Add, stringResource(if (Store.isSavedSearch(h.query)) R.string.unsave_search else R.string.save_search), tint = Pal.muted) }
        IconButton(onClick = { Store.removeHistory(h) }) { Icon(Icons.Default.Close, stringResource(R.string.remove), tint = Pal.muted) }
    }
}

private val chipColors = listOf(Color(0xFFB71C1C), Color(0xFF8E24AA), Color(0xFF283593), Color(0xFF00695C), Color(0xFFE65100), Color(0xFF37474F))

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ResultsScreen(nav: NavController, q: String) {
    var refine by rememberSaveable(q) { mutableStateOf<String?>(null) }
    var sort by rememberSaveable { mutableStateOf(0) }       // 0 relevance, 1 resolution, 2 title
    var hdOnly by rememberSaveable { mutableStateOf(false) }
    var showFilters by remember { mutableStateOf(false) }
    var mode by rememberSaveable { mutableStateOf(0) }   // 0 All, 1 Images, 2 Wallpapers
    val portraitOnly = mode == 2

    val base = remember(q, mode, Store.activeSource) { Sources.get(q, portraitOnly) }
    val activeQuery = refine?.let { "$q $it" } ?: q
    val source = remember(activeQuery, mode, Store.activeSource) { Sources.get(activeQuery, portraitOnly) }
    val gridState = androidx.compose.foundation.lazy.staggeredgrid.rememberLazyStaggeredGridState()

    LaunchedEffect(base) { if (base.items.isEmpty() && !base.loading) base.load() }
    LaunchedEffect(source) { if (source.items.isEmpty() && !source.loading) source.load() }
    LaunchedEffect(base.items.firstOrNull()?.id) { base.items.firstOrNull()?.let { Store.setHistoryThumb(q, it.thumb) } }
    LaunchedEffect(gridState, source) {
        snapshotFlow { val li = gridState.layoutInfo; (li.visibleItemsInfo.lastOrNull()?.index ?: 0) to li.totalItemsCount }
            .collect { (last, total) -> if (total > 0 && last >= total - 6) source.loadMore() }
    }

    // Related topics = real category/tag data attached to the results (never invented).
    val chips = remember(base.items.size) {
        val qWords = q.lowercase().split(' ').filter { it.isNotBlank() }
        base.items.flatMap { it.tags }.groupingBy { it }.eachCount().entries
            .filter { e -> !e.key.equals(q, true) && qWords.none { w -> e.key.equals(w, true) } }
            .sortedByDescending { it.value }.take(10).map { it.key }
    }
    fun thumbFor(tag: String) = base.items.firstOrNull { tag in it.tags }

    val localMatches = remember(activeQuery, mode) { if (mode == 1) emptyList() else com.fareshelmy.auraglass.data.Walls.search(activeQuery) }
    var list: List<Wallpaper> = localMatches + source.items.toList()
    if (hdOnly) list = list.filter { it.height >= 1920 || it.isGen }
    list = when (sort) { 1 -> list.sortedByDescending { it.width.toLong() * it.height }; 2 -> list.sortedBy { it.title.lowercase() }; else -> list }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) }
            Box(
                Modifier.weight(1f).height(56.dp).clip(RoundedCornerShape(32.dp)).border(1.5.dp, Color(0x99FFFFFF), RoundedCornerShape(32.dp))
                    .clickable { nav.popBackStack() }.padding(horizontal = 20.dp),
                contentAlignment = Alignment.CenterStart,
            ) { Text(activeQuery, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            IconButton(onClick = { showFilters = true }) { Icon(Icons.Default.Menu, stringResource(R.string.filters)) }
        }
        Row(Modifier.padding(horizontal = 12.dp).padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(R.string.all_label, R.string.filter_images, R.string.filter_wallpapers).forEachIndexed { i, r ->
                FilterChip(selected = mode == i, onClick = { mode = i; refine = null }, label = { Text(stringResource(r)) })
            }
        }
        if (chips.isNotEmpty()) {
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 10.dp)) {
                items(chips.size) { i ->
                    val tag = chips[i]
                    val sel = refine == tag
                    Row(
                        Modifier.height(54.dp).clip(RoundedCornerShape(18.dp)).background(chipColors[i % chipColors.size])
                            .border(if (sel) 2.dp else 0.dp, Color.White, RoundedCornerShape(18.dp))
                            .clickable { refine = if (sel) null else tag },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        thumbFor(tag)?.let { AsyncImage(it.thumb, null, Modifier.size(54.dp), contentScale = ContentScale.Crop) }
                        Text(tag, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1, modifier = Modifier.padding(horizontal = 14.dp))
                    }
                }
            }
        }
        androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid(
            columns = androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells.Fixed(2), state = gridState,
            contentPadding = PaddingValues(start = 4.dp, end = 4.dp, bottom = 130.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp), verticalItemSpacing = 4.dp,
            modifier = Modifier.fillMaxSize(),
        ) {
            items(list, key = { it.id }) { MasonryCard(it) { w -> openWallpaper(nav, w) } }
            item(span = androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan.FullLine) {
                when {
                    source.error != null -> ErrorBlock(source.error!!, onRetry = { source.retry() })
                    source.loading -> Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    source.loaded && list.isEmpty() -> Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(stringResource(R.string.no_results_for, activeQuery), textAlign = TextAlign.Center, fontSize = 17.sp)
                        Text(stringResource(R.string.no_results_hint), textAlign = TextAlign.Center, color = Pal.muted, modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
        }
    }

    if (showFilters) {
        AlertDialog(
            onDismissRequest = { showFilters = false },
            title = { Text(stringResource(R.string.filters)) },
            text = {
                Column {
                    Text(stringResource(R.string.sort_by), fontWeight = FontWeight.Bold)
                    listOf(R.string.sort_relevance, R.string.sort_resolution, R.string.sort_title).forEachIndexed { i, r ->
                        Row(Modifier.fillMaxWidth().clickable { sort = i }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = sort == i, onClick = { sort = i }); Text(stringResource(r))
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.hd_only), modifier = Modifier.weight(1f)); Switch(checked = hdOnly, onCheckedChange = { hdOnly = it })
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showFilters = false }) { Text(stringResource(R.string.done)) } },
        )
    }
}


/** Local query suggestions: previous searches + a lexicon of common visual subjects (suggestions only, never results). */
object Suggest {
    private val lexicon = listOf(
        "BMW", "Mercedes", "Audi", "Porsche", "Ferrari", "Lamborghini", "Tesla", "Toyota Supra", "Nissan GTR", "Mustang",
        "Redmi Note 14", "Xiaomi 15", "Galaxy S25", "iPhone 16", "Pixel 9", "OnePlus 13",
        "Naruto", "One Piece", "Demon Slayer", "Attack on Titan", "Jujutsu Kaisen", "Goku", "Studio Ghibli",
        "Minecraft", "GTA", "Valorant", "Cyberpunk", "Spider-Man", "Batman",
        "Mountains", "Ocean", "Forest", "Waterfall", "Desert", "Sunset", "Northern lights", "Galaxy", "Nebula", "Moon", "Planet",
        "Mosque", "Kaaba", "Islamic architecture", "Architecture", "City night", "Skyscraper", "Bridge",
        "AMOLED", "Pure black", "Minimal", "Abstract", "Gradient", "Luxury", "Technology", "Robot", "Football", "Basketball", "Photography",
    )
    fun suggest(text: String, history: List<String>): List<String> {
        val t = text.trim().lowercase()
        if (t.length < 1) return emptyList()
        val all = (history + lexicon).distinctBy { it.lowercase() }
        val starts = all.filter { it.lowercase().startsWith(t) }
        val contains = all.filter { !it.lowercase().startsWith(t) && it.lowercase().contains(t) }
        return (starts + contains).filter { !it.equals(text.trim(), true) }.take(6)
    }
}
