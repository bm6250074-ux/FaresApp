package com.fareshelmy.auraglass.ui

import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Density
import com.fareshelmy.auraglass.data.Store
import com.fareshelmy.auraglass.util.findActivity

/** One palette for the whole app (dark + light share the same shapes/layout; only colours change). */
data class Palette(
    val dark: Boolean,
    val bg: Color,
    val surface: Color,
    val onSurface: Color,
    val muted: Color,
    val outline: Color,
    val error: Color,
    val warn: Color,
    val accent: Color,
)

fun makePalette(dark: Boolean, amoled: Boolean, tint: Color): Palette =
    if (dark) Palette(true, if (amoled) Color.Black else Color(0xFF121316), Color(0xFF17171B), Color.White, Color(0xFFB0B0B8),
        Color(0x66FFFFFF), Color(0xFFFFB4AB), Color(0xFFFFD54F), tint)
    else Palette(false, Color(0xFFF2F3F7), Color.White, Color(0xFF121216), Color(0xFF5C5C66),
        Color(0x4D000000), Color(0xFFB3261E), Color(0xFF8A5A00), lerp(tint, Color.Black, 0.5f))

val LocalPalette = staticCompositionLocalOf { makePalette(true, true, Color(0xFF7CF4C8)) }

/** Theme-aware colours: use inside composables instead of hard-coded greys. */
object Pal {
    val dark: Boolean @Composable get() = LocalPalette.current.dark
    val bg: Color @Composable get() = LocalPalette.current.bg
    val surface: Color @Composable get() = LocalPalette.current.surface
    val onSurface: Color @Composable get() = LocalPalette.current.onSurface
    val muted: Color @Composable get() = LocalPalette.current.muted
    val outline: Color @Composable get() = LocalPalette.current.outline
    val error: Color @Composable get() = LocalPalette.current.error
    val warn: Color @Composable get() = LocalPalette.current.warn
    val accent: Color @Composable get() = LocalPalette.current.accent
}

val AppFonts = listOf(FontFamily.Default, FontFamily.SansSerif, FontFamily.Serif, FontFamily.Monospace, FontFamily.Cursive)

fun Typography.withFamily(f: FontFamily): Typography = if (f == FontFamily.Default) this else Typography(
    displayLarge = displayLarge.copy(fontFamily = f), displayMedium = displayMedium.copy(fontFamily = f), displaySmall = displaySmall.copy(fontFamily = f),
    headlineLarge = headlineLarge.copy(fontFamily = f), headlineMedium = headlineMedium.copy(fontFamily = f), headlineSmall = headlineSmall.copy(fontFamily = f),
    titleLarge = titleLarge.copy(fontFamily = f), titleMedium = titleMedium.copy(fontFamily = f), titleSmall = titleSmall.copy(fontFamily = f),
    bodyLarge = bodyLarge.copy(fontFamily = f), bodyMedium = bodyMedium.copy(fontFamily = f), bodySmall = bodySmall.copy(fontFamily = f),
    labelLarge = labelLarge.copy(fontFamily = f), labelMedium = labelMedium.copy(fontFamily = f), labelSmall = labelSmall.copy(fontFamily = f),
)

/** The exact colour scheme the approved start screen was designed with. Never changes with the user's theme. */
fun legacyDarkScheme(): ColorScheme {
    val accent = Color(Store.glass.tint)
    return darkColorScheme(
        primary = accent, onPrimary = Color.Black, secondary = accent,
        background = Color.Black, surface = Color(0xFF0E0E10), surfaceVariant = Color(0xFF1B1B1F),
        onSurface = Color.White, onBackground = Color.White, onSurfaceVariant = Color(0xFFC4C4CC), outline = Color(0x66FFFFFF),
    )
}

@Composable
fun SystemBars(dark: Boolean) {
    val ctx = LocalContext.current
    DisposableEffect(dark) {
        val act = ctx.findActivity() as? ComponentActivity
        val t = android.graphics.Color.TRANSPARENT
        act?.enableEdgeToEdge(
            statusBarStyle = if (dark) SystemBarStyle.dark(t) else SystemBarStyle.light(t, t),
            navigationBarStyle = if (dark) SystemBarStyle.dark(t) else SystemBarStyle.light(t, t),
        )
        onDispose { }
    }
}

/**
 * Wrapper for the START SCREEN only. It reproduces the environment the approved start screen always had
 * (the original dark scheme, default black content colour, default font/density), so it looks exactly as before
 * regardless of the user's Light/Dark, font or customization settings.
 */
@Composable
fun LegacyDarkTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = legacyDarkScheme()) {
        CompositionLocalProvider(
            LocalContentColor provides Color.Black,
            LocalPalette provides makePalette(true, true, Color(Store.glass.tint)),
        ) {
            SystemBars(true)
            content()
        }
    }
}

/** Applies the content colour, user font scale and system-bar icon style for the real app screens. */
@Composable
fun AuraSurface(content: @Composable () -> Unit) {
    val pal = LocalPalette.current
    val d = LocalDensity.current
    CompositionLocalProvider(
        LocalContentColor provides pal.onSurface,
        LocalDensity provides Density(d.density, d.fontScale * Store.appearance.fontScale),
    ) {
        SystemBars(pal.dark)
        content()
    }
}

@Composable
fun resolveDark(): Boolean = when (Store.appearance.themeMode) {
    "dark" -> true
    "light" -> false
    else -> isSystemInDarkTheme()
}

/** Applies the user's numeral style (Latin / Arabic-Indic / follow language) to any display string. */
fun localizeDigits(s: String): String {
    val arabic = when (Store.appearance.numerals) {
        1 -> true
        2 -> java.util.Locale.getDefault().language == "ar"
        else -> false
    }
    return if (!arabic) s else s.map { if (it in '0'..'9') '\u0660' + (it - '0') else it }.joinToString("")
}
