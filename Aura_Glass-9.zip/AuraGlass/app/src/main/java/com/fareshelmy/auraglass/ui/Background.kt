package com.fareshelmy.auraglass.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.fareshelmy.auraglass.data.Store
import java.io.File

fun backgroundFile(ctx: android.content.Context) = File(ctx.filesDir, "app_background.jpg")

/** App-wide background: theme colour, gradient, or an image from the gallery (blur/dim/zoom/position adjustable). */
@Composable
fun AppBackground(modifier: Modifier = Modifier) {
    val b = Store.background
    val pal = LocalPalette.current
    val ctx = LocalContext.current
    val file = backgroundFile(ctx)
    Box(modifier.fillMaxSize().background(pal.bg).clipToBounds()) {
        when {
            b.mode == 1 -> Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(b.c1), Color(b.c2)))))
            b.mode == 2 && file.exists() -> {
                AsyncImage(
                    model = ImageRequest.Builder(ctx).data(file).memoryCacheKey("bg${b.imageVersion}").diskCacheKey("bg${b.imageVersion}").build(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    alignment = BiasAlignment(b.bias, 0f),
                    modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = b.zoom; scaleY = b.zoom }.blur(b.blur.dp),
                )
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = if (pal.dark) b.dim else b.dim * 0.35f)))
            }
        }
    }
}
