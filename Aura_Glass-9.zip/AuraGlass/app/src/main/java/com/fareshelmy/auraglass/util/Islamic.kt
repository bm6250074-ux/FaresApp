package com.fareshelmy.auraglass.util

import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField
import java.util.Locale

object Hijri {
    private val ar = listOf("محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة")
    private val en = listOf("Muharram", "Safar", "Rabi' al-awwal", "Rabi' al-thani", "Jumada al-awwal", "Jumada al-thani", "Rajab", "Sha'ban", "Ramadan", "Shawwal", "Dhu al-Qi'dah", "Dhu al-Hijjah")

    /** Umm al-Qura calendar (Saudi civil calendar). Local moon-sighting dates may differ by a day. */
    fun format(date: LocalDate = LocalDate.now()): String {
        val h = HijrahDate.from(date)
        val isAr = Locale.getDefault().language == "ar"
        val month = (if (isAr) ar else en)[h.get(ChronoField.MONTH_OF_YEAR) - 1]
        val day = h.get(ChronoField.DAY_OF_MONTH); val year = h.get(ChronoField.YEAR)
        return if (isAr) "$day $month $year هـ" else "$day $month $year AH"
    }
}

data class Quote(val ar: String, val ref: String)

/**
 * Religious texts. Quran verses are written without altering the wording; always verify against a printed Mushaf
 * (e.g. the King Fahd Complex edition). Hadith-based adhkar list their collection only where it is well established.
 */
object IslamicContent {
    val verses = listOf(
        Quote("فَإِنَّ مَعَ الْعُسْرِ يُسْرًا ۝ إِنَّ مَعَ الْعُسْرِ يُسْرًا", "القرآن الكريم — الشرح ٥-٦"),
        Quote("أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ", "القرآن الكريم — الرعد ٢٨"),
        Quote("لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا", "القرآن الكريم — البقرة ٢٨٦"),
        Quote("وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ", "القرآن الكريم — الطلاق ٣"),
        Quote("فَاذْكُرُونِي أَذْكُرْكُمْ وَاشْكُرُوا لِي وَلَا تَكْفُرُونِ", "القرآن الكريم — البقرة ١٥٢"),
        Quote("وَلَا تَهِنُوا وَلَا تَحْزَنُوا وَأَنتُمُ الْأَعْلَوْنَ إِن كُنتُم مُّؤْمِنِينَ", "القرآن الكريم — آل عمران ١٣٩"),
        Quote("قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ", "القرآن الكريم — الإخلاص"),
    )

    val adhkar = listOf(
        Quote("سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ", "متفق عليه (البخاري ومسلم)"),
        Quote("لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", "متفق عليه (البخاري ومسلم)"),
        Quote("لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ", "متفق عليه (البخاري ومسلم)"),
        Quote("أَسْتَغْفِرُ اللَّهَ", ""),
        Quote("الْحَمْدُ لِلَّهِ", ""),
    )

    val duas = listOf(
        Quote("رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ", "القرآن الكريم — البقرة ٢٠١"),
        Quote("رَّبِّ زِدْنِي عِلْمًا", "القرآن الكريم — طه ١١٤"),
        Quote("رَبَّنَا ظَلَمْنَا أَنفُسَنَا وَإِن لَّمْ تَغْفِرْ لَنَا وَتَرْحَمْنَا لَنَكُونَنَّ مِنَ الْخَاسِرِينَ", "القرآن الكريم — الأعراف ٢٣"),
        Quote("لَّا إِلَٰهَ إِلَّا أَنتَ سُبْحَانَكَ إِنِّي كُنتُ مِنَ الظَّالِمِينَ", "القرآن الكريم — الأنبياء ٨٧"),
    )

    val greetings = listOf("جمعة مباركة", "رمضان كريم", "عيد مبارك، تقبل الله منا ومنكم", "كل عام وأنتم بخير", "صباح الخير", "مساء الخير")

    fun pick(list: List<Quote>, offset: Int = 0): Quote =
        list[((LocalDate.now().dayOfYear + offset) % list.size + list.size) % list.size]
}
