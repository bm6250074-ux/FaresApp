package com.fareshelmy.auraglass.ui

import android.net.Uri
import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.compose.foundation.layout.Box
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.data.Store
import com.fareshelmy.auraglass.util.Auth
import com.fareshelmy.auraglass.util.findActivity
import kotlinx.coroutines.launch

@Composable
fun AuraRoot() {
    if (!Store.onboardingDone || Store.showIntro) {
        // The approved start screen: rendered in its original (frozen) environment.
        LegacyDarkTheme { OnboardingScreen(onDone = { Store.finishOnboarding() }) }
    } else {
        AuraSurface {
            if (Auth.enabled && Auth.idToken == null) SignInGate() else MainScaffold()
        }
    }
}

/** Only shown when GOOGLE_WEB_CLIENT_ID is configured at build time. */
@Composable
fun SignInGate() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var failed by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(true) }
    // First try a silent sign-in with an account already authorized for this app.
    LaunchedEffect(Unit) {
        val act = ctx.findActivity()
        if (act != null) Auth.signIn(act, silent = true)
        busy = false
    }
    Column(
        Modifier.fillMaxSize().background(Pal.bg).padding(32.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(painterResource(R.drawable.aura_identity), null, Modifier.size(140.dp).clip(RoundedCornerShape(28.dp)))
        Text(stringResource(R.string.signin_title), fontSize = 26.sp, modifier = Modifier.padding(top = 20.dp), textAlign = TextAlign.Center)
        Text(stringResource(R.string.signin_body), modifier = Modifier.padding(vertical = 12.dp), textAlign = TextAlign.Center, color = Pal.muted)
        if (failed) Text(stringResource(R.string.signin_failed), color = Pal.error, modifier = Modifier.padding(bottom = 8.dp))
        Button(enabled = !busy, onClick = {
            busy = true; failed = false
            scope.launch {
                val act = ctx.findActivity()
                val r = if (act != null) Auth.signIn(act, silent = false) else Result.failure(IllegalStateException())
                failed = r.isFailure; busy = false
            }
        }) { Text(stringResource(R.string.signin_google)) }
    }
}

private fun tabFor(route: String?): String = when {
    route == null -> "home"
    route == "home" -> "home"
    route == "search" || route.startsWith("results") -> "search"
    route == "library" || route == "editor" -> "library"
    route == "profile" || route == "about" || route == "owner" -> "profile"
    route in setOf("studio", "clocks", "creator", "depth", "islamic", "widgets", "glass") -> "studio"
    else -> "home"
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MainScaffold() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val showBar = route != "detail" && route != "search" && route != "editor"
    val imeVisible = WindowInsets.isImeVisible
    val barVisible = showBar && !imeVisible
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val inset = if (barVisible) 92.dp + navBottom else 0.dp
    val backdrop = rememberGraphicsLayer()
    val dur = animMs(240)
    val useBackdrop = Store.liquid.on && Build.VERSION.SDK_INT >= 31

    CompositionLocalProvider(LocalBarInset provides inset) {
        Box(Modifier.fillMaxSize().background(Pal.bg)) {
          Box(Modifier.fillMaxSize().then(if (useBackdrop) Modifier.backdropSource(backdrop) else Modifier), contentAlignment = Alignment.TopCenter) {
            AppBackground()
            NavHost(
                nav, startDestination = "home",
                modifier = Modifier.widthIn(max = 960.dp).fillMaxSize(),
                enterTransition = {
                    when (Store.liquid.transition) {
                        1 -> slideInHorizontally(tween(dur)) { it / 5 } + fadeIn(tween(dur))
                        2 -> EnterTransition.None
                        else -> fadeIn(tween(dur)) + scaleIn(initialScale = 0.97f, animationSpec = tween(dur))
                    }
                },
                exitTransition = { if (Store.liquid.transition == 2) ExitTransition.None else fadeOut(tween(dur / 2)) },
                popEnterTransition = { if (Store.liquid.transition == 2) EnterTransition.None else fadeIn(tween(dur)) },
                popExitTransition = {
                    when (Store.liquid.transition) {
                        1 -> slideOutHorizontally(tween(dur)) { it / 5 } + fadeOut(tween(dur))
                        2 -> ExitTransition.None
                        else -> fadeOut(tween(dur)) + scaleOut(targetScale = 0.97f, animationSpec = tween(dur))
                    }
                },
            ) {
                composable("home") { HomeScreen(nav) }
                composable("search") { SearchScreen(nav) }
                composable("results/{q}", arguments = listOf(navArgument("q") { type = NavType.StringType })) {
                    ResultsScreen(nav, it.arguments?.getString("q").orEmpty())
                }
                composable("detail") { DetailScreen(nav) }
                composable("library") { LibraryScreen(nav) }
                composable("studio") { StudioScreen(nav) }
                composable("clocks") { ClocksScreen(nav) }
                composable("creator") { ClockCreatorScreen(nav) }
                composable("depth") { DepthScreen(nav) }
                composable("islamic") { IslamicScreen(nav) }
                composable("widgets") { WidgetStudioScreen(nav) }
                composable("glass") { CustomizeScreen(nav) }
                composable("profile") { ProfileScreen(nav) }
                composable("about") { AboutScreen(nav) }
                composable("owner") { OwnerScreen(nav) }
                composable("editor") { ImportEditorScreen(nav) }
            }
          }
            AnimatedVisibility(
                visible = barVisible,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = fadeIn(tween(dur)) + slideInVertically(tween(dur)) { it / 2 },
                exit = fadeOut(tween(dur)) + slideOutVertically(tween(dur)) { it / 2 },
            ) {
                GlassBar(
                    selected = tabFor(route),
                    backdrop = if (useBackdrop) backdrop else null,
                    onSelect = { r ->
                        nav.navigate(r) {
                            popUpTo("home") { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                )
            }
        }
    }
}

fun resultsRoute(q: String) = "results/${Uri.encode(q)}"
