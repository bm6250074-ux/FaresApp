package com.fareshelmy.auraglass.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridItemSpanScope
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.data.Session
import com.fareshelmy.auraglass.data.Store
import com.fareshelmy.auraglass.data.Walls
import com.fareshelmy.auraglass.data.Wallpaper

@Composable
fun LibraryScreen(nav: NavController) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var genCat by rememberSaveable { mutableStateOf<String?>(null) }
    var selColl by rememberSaveable { mutableStateOf<String?>(null) }
    // 0 favorites, 1 recent, 2 my photos, 3 offline, 4 built-in, 5 downloads
    val tabs = listOf(R.string.lib_favorites, R.string.lib_recent, R.string.lib_imported, R.string.lib_offline, R.string.lib_builtin, R.string.lib_downloads, R.string.lib_collections)

    // Photo Picker: no storage permission. The image opens in the editor (zoom / crop / fit / fill) before anything is saved.
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) { Session.importUri = uri; nav.navigate("editor") }
    }
    val full: LazyGridItemSpanScope.() -> GridItemSpan = { GridItemSpan(maxLineSpan) }
    val list: List<Wallpaper> = when (tab) {
        0 -> Store.favorites.toList()
        1 -> Store.recents.toList()
        2 -> Store.imported.toList()
        3 -> Store.offline.toList()
        4 -> if (genCat == null) Walls.all() else Walls.inCategory(genCat!!)
        5 -> Store.downloads.toList()
        else -> (Store.collections.firstOrNull { it.name == selColl } ?: Store.collections.firstOrNull())?.items ?: emptyList()
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        ScreenTitle(stringResource(R.string.tab_library), Modifier.padding(horizontal = 16.dp))
        ScrollableTabRow(selectedTabIndex = tab, containerColor = Color.Transparent, edgePadding = 8.dp) {
            tabs.forEachIndexed { i, r -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(stringResource(r)) }) }
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(Store.layout.minCard.dp),
            contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 130.dp),
            horizontalArrangement = Arrangement.spacedBy(Store.layout.spacing.dp), verticalArrangement = Arrangement.spacedBy(Store.layout.spacing.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            if (tab == 2) item(span = full) {
                Button(onClick = { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, null); Text(stringResource(R.string.import_image), modifier = Modifier.padding(start = 8.dp))
                }
            }
            if (tab == 6) item(span = full) {
                Column {
                    if (Store.collections.isEmpty()) Text(stringResource(R.string.collections_empty), color = Pal.muted, fontSize = 13.sp)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(Store.collections.toList()) { c ->
                            val sel = (selColl ?: Store.collections.firstOrNull()?.name) == c.name
                            FilterChip(selected = sel, onClick = { selColl = c.name }, label = { Text(c.name + " (" + c.items.size + ")") })
                        }
                    }
                    (selColl ?: Store.collections.firstOrNull()?.name)?.let { n ->
                        androidx.compose.material3.TextButton(onClick = { Store.deleteCollection(n); selColl = null }) { Text(stringResource(R.string.delete_collection)) }
                    }
                }
            }
            if (tab == 4) {
                item(span = full) {
                    Column {
                        Text(stringResource(R.string.builtin_hint), fontSize = 12.sp, color = Pal.muted, modifier = Modifier.padding(bottom = 8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            item { FilterChip(selected = genCat == null, onClick = { genCat = null }, label = { Text(stringResource(R.string.all_label)) }) }
                            items(Walls.cats) { c -> FilterChip(selected = genCat == c.id, onClick = { genCat = c.id }, label = { Text(stringResource(c.titleRes)) }) }
                        }
                    }
                }
            }
            if (list.isEmpty()) item(span = full) {
                Text(
                    stringResource(when (tab) { 0 -> R.string.empty_fav; 1 -> R.string.empty_recent; 3 -> R.string.empty_offline; 5 -> R.string.empty_downloads; 6 -> R.string.collection_empty_one; else -> R.string.empty_imported }),
                    textAlign = TextAlign.Center, color = Pal.muted, modifier = Modifier.fillMaxWidth().padding(32.dp),
                )
            }
            items(list, key = { it.id }) { w ->
                Box {
                    WallCard(w, showTitle = true, onClick = { openWallpaper(nav, it) })
                    if (tab == 2 || tab == 3 || tab == 6) IconButton(
                        onClick = { when (tab) { 2 -> Store.removeImported(w); 3 -> Store.removeOffline(w); else -> (selColl ?: Store.collections.firstOrNull()?.name)?.let { Store.toggleInCollection(it, w) } } },
                        modifier = Modifier.align(Alignment.TopStart).padding(4.dp).size(36.dp).clip(CircleShape).background(Color(0xAA000000)),
                    ) { Icon(Icons.Default.Close, stringResource(R.string.remove), tint = Color.White, modifier = Modifier.size(18.dp)) }
                }
            }
        }
    }
}
