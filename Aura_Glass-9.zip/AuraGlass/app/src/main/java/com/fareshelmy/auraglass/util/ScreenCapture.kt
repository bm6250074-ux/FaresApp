package com.fareshelmy.auraglass.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.PixelCopy
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/** Copies the real on-screen pixels of a rectangle (window coordinates) so an exported clock is identical to its preview. */
object ScreenCapture {
    suspend fun capture(ctx: Context, rect: Rect?): Bitmap? {
        val activity = ctx.findActivity() ?: return null
        if (rect == null || rect.width() <= 0 || rect.height() <= 0) return null
        return try {
            suspendCancellableCoroutine { cont ->
                val bmp = Bitmap.createBitmap(rect.width(), rect.height(), Bitmap.Config.ARGB_8888)
                PixelCopy.request(activity.window, rect, bmp, { code -> if (cont.isActive) cont.resume(if (code == PixelCopy.SUCCESS) bmp else null) }, Handler(Looper.getMainLooper()))
            }
        } catch (e: Exception) { null }
    }
}
