package com.fareshelmy.auraglass.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.data.Store
import com.fareshelmy.auraglass.util.Images
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class PaletteDef(val nameRes: Int, val accent: Int, val c1: Int, val c2: Int)

private val palettes = listOf(
    PaletteDef(R.string.pal_mint, 0xFF7CF4C8.toInt(), 0xFF0B0B10.toInt(), 0xFF0F2A24.toInt()),
    PaletteDef(R.string.pal_ocean, 0xFF64B5F6.toInt(), 0xFF050B18.toInt(), 0xFF0D2B4F.toInt()),
    PaletteDef(R.string.pal_sunset, 0xFFFF8A65.toInt(), 0xFF140806.toInt(), 0xFF4A1E2E.toInt()),
    PaletteDef(R.string.pal_orchid, 0xFFBA68C8.toInt(), 0xFF0D0614.toInt(), 0xFF2D1245.toInt()),
    PaletteDef(R.string.pal_rose, 0xFFFF5C7A.toInt(), 0xFF120508.toInt(), 0xFF3A0F20.toInt()),
    PaletteDef(R.string.pal_gold, 0xFFFFD54F.toInt(), 0xFF0F0C03.toInt(), 0xFF3A2E08.toInt()),
    PaletteDef(R.string.pal_graphite, 0xFFB0BEC5.toInt(), 0xFF0A0A0B.toInt(), 0xFF1D1F22.toInt()),
    PaletteDef(R.string.pal_forest, 0xFF9CCC65.toInt(), 0xFF050A05.toInt(), 0xFF12301A.toInt()),
)

/** Colour picker (hue / saturation / brightness). Works for the accent and for background colours. */
@Composable
fun HsvPicker(color: Int, onChange: (Int) -> Unit) {
    val tmp = FloatArray(3)
    android.graphics.Color.colorToHSV(color, tmp)
    var h by remember { mutableFloatStateOf(tmp[0]) }
    var sat by remember { mutableFloatStateOf(tmp[1]) }
    var v by remember { mutableFloatStateOf(tmp[2]) }
    val current = android.graphics.Color.HSVToColor(floatArrayOf(h, sat, v))
    val opaque = color or 0xFF000000.toInt()
    LaunchedEffect(color) {
        if (current != opaque) {   // changed from outside (palette / import): resync
            val t = FloatArray(3); android.graphics.Color.colorToHSV(opaque, t); h = t[0]; sat = t[1]; v = t[2]
        }
    }
    fun push() = onChange(android.graphics.Color.HSVToColor(floatArrayOf(h, sat, v)))
    Column {
        Box(Modifier.fillMaxWidth().height(28.dp).clip(RoundedCornerShape(10.dp)).background(Color(current)).border(1.dp, Pal.outline, RoundedCornerShape(10.dp)))
        Text(stringResource(R.string.hue), fontSize = 12.sp, color = Pal.muted); Slider(h, { h = it; push() }, valueRange = 0f..360f)
        Text(stringResource(R.string.saturation), fontSize = 12.sp, color = Pal.muted); Slider(sat, { sat = it; push() }, valueRange = 0f..1f)
        Text(stringResource(R.string.brightness), fontSize = 12.sp, color = Pal.muted); Slider(v, { v = it; push() }, valueRange = 0f..1f)
    }
}

@Composable
private fun Title(text: Int) = Text(stringResource(text), fontWeight = FontWeight.Bold, fontSize = 18.sp)

@Composable
fun CustomizeScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val g = Store.glass; val l = Store.liquid; val ap = Store.appearance; val ly = Store.layout; val bg = Store.background
    var presetName by remember { mutableStateOf("") }
    var showPaste by remember { mutableStateOf(false) }
    var pasteText by remember { mutableStateOf("") }
    var editBg by remember { mutableStateOf(1) }

    val pickBg = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val bmp = Images.loadUri(ctx, uri, 2200)
            if (bmp == null) { ctx.toast(R.string.import_invalid); return@launch }
            val ok = withContext(Dispatchers.IO) {
                try { backgroundFile(ctx).outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }; true } catch (e: Exception) { false }
            }
            if (ok) Store.updateBackground(Store.background.copy(mode = 2, imageVersion = Store.background.imageVersion + 1)) else ctx.toast(R.string.save_failed)
        }
    }
    val exportFile = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val ok = try { ctx.contentResolver.openOutputStream(uri)?.use { it.write(Store.exportConfig().toByteArray()) }; true } catch (e: Exception) { false }
            ctx.toast(if (ok) R.string.cfg_exported else R.string.save_failed)
        }
    }
    val importFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = try { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } } catch (e: Exception) { null }
            ctx.toast(if (text != null && Store.importConfig(text)) R.string.cfg_imported else R.string.cfg_invalid)
        }
    }

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { BackTitle(nav, stringResource(R.string.customize_title)) }

        // ---- live preview (the whole app also updates instantly behind this screen)
        item {
            Column(Modifier.fillMaxWidth().liquidGlass().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(stringResource(R.string.glass_preview), fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(ly.spacing.dp)) {
                    listOf(2, 9, 14).forEach { seed ->
                        Column(Modifier.weight(1f)) {
                            LocalArt(seed, Modifier.fillMaxWidth().aspectRatio(9f / 16f).clip(RoundedCornerShape(ly.cardCorner.dp)))
                            if (ly.showTitles) Text("Aura #$seed", fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = {}) { Text(stringResource(R.string.apply)) }
                    FilterChip(selected = true, onClick = {}, label = { Text("Sample") })
                    Text(com.fareshelmy.auraglass.util.Hijri.format().let { localizeDigits(it) }, fontSize = 14.sp, color = Pal.muted)
                }
            }
        }

        // ---- theme
        item {
            Section {
                Title(R.string.theme_title)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("dark" to R.string.theme_dark, "light" to R.string.theme_light, "system" to R.string.theme_system).forEach { (m, r) ->
                        FilterChip(selected = ap.themeMode == m, onClick = { Store.updateAppearance(ap.copy(themeMode = m)) }, label = { Text(stringResource(r)) })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) { Text(stringResource(R.string.amoled_black), Modifier.weight(1f)); Switch(ap.amoled, { Store.updateAppearance(ap.copy(amoled = it)) }) }
                Text(stringResource(R.string.palettes), color = Pal.muted)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(palettes) { _, p ->
                        Column(
                            Modifier.clip(RoundedCornerShape(14.dp)).border(1.dp, Pal.outline, RoundedCornerShape(14.dp)).pressClickable {
                                Store.updateGlass(g.copy(tint = p.accent))
                                Store.updateBackground(bg.copy(mode = 1, c1 = p.c1, c2 = p.c2))
                            }.padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Box(Modifier.size(44.dp).clip(CircleShape).background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color(p.c1), Color(p.c2)))).border(3.dp, Color(p.accent), CircleShape))
                            Text(stringResource(p.nameRes), fontSize = 11.sp)
                        }
                    }
                }
                Text(stringResource(R.string.accent_color), color = Pal.muted)
                HsvPicker(g.tint) { Store.updateGlass(g.copy(tint = it)) }
            }
        }

        // ---- background
        item {
            Section {
                Title(R.string.background_title)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = bg.mode == 0, onClick = { Store.updateBackground(bg.copy(mode = 0)) }, label = { Text(stringResource(R.string.bg_theme)) })
                    FilterChip(selected = bg.mode == 1, onClick = { Store.updateBackground(bg.copy(mode = 1)) }, label = { Text(stringResource(R.string.bg_gradient)) })
                    FilterChip(selected = bg.mode == 2, enabled = backgroundFile(ctx).exists(), onClick = { Store.updateBackground(bg.copy(mode = 2)) }, label = { Text(stringResource(R.string.bg_image)) })
                }
                if (bg.mode == 1) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = editBg == 1, onClick = { editBg = 1 }, label = { Text(stringResource(R.string.bg_top)) })
                        FilterChip(selected = editBg == 2, onClick = { editBg = 2 }, label = { Text(stringResource(R.string.bg_bottom)) })
                    }
                    if (editBg == 1) HsvPicker(bg.c1) { Store.updateBackground(bg.copy(c1 = it)) } else HsvPicker(bg.c2) { Store.updateBackground(bg.copy(c2 = it)) }
                }
                OutlinedButton(onClick = { pickBg.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text(stringResource(R.string.bg_pick)) }
                if (bg.mode == 2) {
                    Text(stringResource(R.string.bg_blur)); Slider(bg.blur, { Store.updateBackground(bg.copy(blur = it)) }, valueRange = 0f..40f)
                    Text(stringResource(R.string.bg_dim)); Slider(bg.dim, { Store.updateBackground(bg.copy(dim = it)) }, valueRange = 0f..0.9f)
                    Text(stringResource(R.string.bg_zoom)); Slider(bg.zoom, { Store.updateBackground(bg.copy(zoom = it)) }, valueRange = 1f..2.5f)
                    Text(stringResource(R.string.bg_position)); Slider(bg.bias, { Store.updateBackground(bg.copy(bias = it)) }, valueRange = -1f..1f)
                }
                Text(stringResource(R.string.bg_note), fontSize = 12.sp, color = Pal.muted)
            }
        }

        // ---- liquid glass
        item {
            Section {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Title(R.string.liquid_title); Text(stringResource(R.string.liquid_sub), fontSize = 12.sp, color = Pal.muted) }
                    Switch(l.on, { Store.updateLiquid(l.copy(on = it)) })
                }
                if (l.on) {
                    Text(stringResource(R.string.liquid_reflect)); Slider(l.reflect, { Store.updateLiquid(l.copy(reflect = it)) }, valueRange = 0f..1f)
                    Text(stringResource(R.string.liquid_depth)); Slider(l.depth, { Store.updateLiquid(l.copy(depth = it)) }, valueRange = 0f..1f)
                    Text(stringResource(R.string.liquid_border_w)); Slider(l.borderWidth, { Store.updateLiquid(l.copy(borderWidth = it)) }, valueRange = 0.5f..3f)
                    Text(stringResource(R.string.glass_transparency)); Slider(g.alpha, { Store.updateGlass(g.copy(alpha = it)) }, valueRange = 0.04f..0.6f)
                    Text(stringResource(R.string.glass_border)); Slider(g.border, { Store.updateGlass(g.copy(border = it)) }, valueRange = 0f..1f)
                }
                Text(stringResource(R.string.glass_corner)); Slider(g.corner, { Store.updateGlass(g.copy(corner = it)) }, valueRange = 0f..40f)
                Text(stringResource(R.string.liquid_note), fontSize = 12.sp, color = Pal.muted)
            }
        }

        // ---- typography
        item {
            Section {
                Title(R.string.typography_title)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val names = listOf(R.string.font_default, R.string.font_sans, R.string.font_serif, R.string.font_mono, R.string.font_cursive)
                    itemsIndexed(names) { i, r ->
                        FilterChip(selected = ap.fontIdx == i, onClick = { Store.updateAppearance(ap.copy(fontIdx = i)) },
                            label = { Text(stringResource(r), fontFamily = AppFonts[i]) })
                    }
                }
                Text(stringResource(R.string.font_size)); Slider(ap.fontScale, { Store.updateAppearance(ap.copy(fontScale = it)) }, valueRange = 0.8f..1.4f)
                Text(stringResource(R.string.numerals_title), color = Pal.muted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(R.string.num_latin, R.string.num_arabic, R.string.num_auto).forEachIndexed { i, r ->
                        FilterChip(selected = ap.numerals == i, onClick = { Store.updateAppearance(ap.copy(numerals = i)) }, label = { Text(stringResource(r)) })
                    }
                }
                Text(localizeDigits("0123456789  12:45"), fontSize = 18.sp)
                Text(stringResource(R.string.font_note), fontSize = 12.sp, color = Pal.muted)
            }
        }

        // ---- layout / navigation / animations
        item {
            Section {
                Title(R.string.layout_title)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = false, onClick = { Store.updateLayout(ly.copy(minCard = 130f, spacing = 6f)) }, label = { Text(stringResource(R.string.dens_compact)) })
                    FilterChip(selected = false, onClick = { Store.updateLayout(ly.copy(minCard = 165f, spacing = 10f)) }, label = { Text(stringResource(R.string.dens_normal)) })
                    FilterChip(selected = false, onClick = { Store.updateLayout(ly.copy(minCard = 210f, spacing = 16f)) }, label = { Text(stringResource(R.string.dens_spacious)) })
                }
                Text(stringResource(R.string.card_size)); Slider(ly.minCard, { Store.updateLayout(ly.copy(minCard = it)) }, valueRange = 110f..300f)
                Text(stringResource(R.string.card_spacing)); Slider(ly.spacing, { Store.updateLayout(ly.copy(spacing = it)) }, valueRange = 2f..24f)
                Text(stringResource(R.string.card_corner)); Slider(ly.cardCorner, { Store.updateLayout(ly.copy(cardCorner = it)) }, valueRange = 0f..32f)
                Row(verticalAlignment = Alignment.CenterVertically) { Text(stringResource(R.string.show_titles), Modifier.weight(1f)); Switch(ly.showTitles, { Store.updateLayout(ly.copy(showTitles = it)) }) }
            }
        }
        item {
            Section {
                Title(R.string.nav_title)
                Text(stringResource(R.string.nav_icon_size)); Slider(ly.barIcon, { Store.updateLayout(ly.copy(barIcon = it)) }, valueRange = 18f..32f)
                Row(verticalAlignment = Alignment.CenterVertically) { Text(stringResource(R.string.nav_labels), Modifier.weight(1f)); Switch(ly.barLabels, { Store.updateLayout(ly.copy(barLabels = it)) }) }
                Text(stringResource(R.string.nav_indicator), color = Pal.muted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(R.string.ind_lens, R.string.ind_pill, R.string.ind_none).forEachIndexed { i, r ->
                        FilterChip(selected = ly.indicator == i, onClick = { Store.updateLayout(ly.copy(indicator = i)) }, label = { Text(stringResource(r)) })
                    }
                }
            }
        }
        item {
            Section {
                Title(R.string.anim_title)
                Text(stringResource(R.string.anim_speed)); Slider(l.animSpeed, { Store.updateLiquid(l.copy(animSpeed = it)) }, valueRange = 0.5f..2f)
                Text(stringResource(R.string.transition_type), color = Pal.muted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(R.string.tr_fade, R.string.tr_slide, R.string.tr_none).forEachIndexed { i, r ->
                        FilterChip(selected = l.transition == i, onClick = { Store.updateLiquid(l.copy(transition = i)) }, label = { Text(stringResource(r)) })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) { Text(stringResource(R.string.reduce_motion), Modifier.weight(1f)); Switch(l.reduceMotion, { Store.updateLiquid(l.copy(reduceMotion = it)) }) }
                Text(stringResource(R.string.reduce_motion_note), fontSize = 12.sp, color = Pal.muted)
            }
        }

        // ---- presets / import / export / defaults
        item {
            Section {
                Title(R.string.presets_title)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(presetName, { presetName = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text(stringResource(R.string.preset_name)) })
                    Button(onClick = { Store.saveThemePreset(presetName.trim().ifBlank { "Theme " + (Store.themePresets.size + 1) }); presetName = "" }) { Text(stringResource(R.string.save_preset)) }
                }
                Store.themePresets.toList().forEach { t ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(t.name, Modifier.weight(1f))
                        TextButton(onClick = { Store.applyThemePreset(t) }) { Text(stringResource(R.string.apply)) }
                        TextButton(onClick = { Store.deleteThemePreset(t) }) { Text(stringResource(R.string.remove)) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { exportFile.launch("aura_glass_theme.json") }) { Text(stringResource(R.string.cfg_export)) }
                    OutlinedButton(onClick = { importFile.launch(arrayOf("application/json", "text/plain")) }) { Text(stringResource(R.string.cfg_import)) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Aura Glass theme", Store.exportConfig()))
                        ctx.toast(R.string.cfg_copied)
                    }) { Text(stringResource(R.string.cfg_copy)) }
                    OutlinedButton(onClick = { showPaste = true }) { Text(stringResource(R.string.cfg_paste)) }
                }
                OutlinedButton(onClick = { Store.resetAllAppearance(); ctx.toast(R.string.defaults_restored) }) { Text(stringResource(R.string.restore_defaults)) }
                Text(stringResource(R.string.restore_note), fontSize = 12.sp, color = Pal.muted)
            }
        }
    }

    if (showPaste) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showPaste = false },
            title = { Text(stringResource(R.string.cfg_paste)) },
            text = { OutlinedTextField(pasteText, { pasteText = it }, Modifier.fillMaxWidth().height(180.dp)) },
            confirmButton = { TextButton(onClick = { ctx.toast(if (Store.importConfig(pasteText)) R.string.cfg_imported else R.string.cfg_invalid); showPaste = false; pasteText = "" }) { Text(stringResource(R.string.apply)) } },
            dismissButton = { TextButton(onClick = { showPaste = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}
