package com.fareshelmy.auraglass.ui

import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.lazy.staggeredgrid.rememberLazyStaggeredGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.os.LocaleListCompat
import androidx.navigation.NavController
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.data.Discovery
import com.fareshelmy.auraglass.data.Sources
import com.fareshelmy.auraglass.data.Store
import com.fareshelmy.auraglass.data.Walls
import com.fareshelmy.auraglass.data.Wallpaper

fun applyLanguage(code: String) {
    Store.setLanguage(code)
    AppCompatDelegate.setApplicationLocales(
        if (code == "system") LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(code)
    )
}

/** Card height ratio (h/w) for the masonry: the image's real ratio when known, a stable varied ratio for generated ones. */
private fun masonryRatio(w: Wallpaper): Float {
    if (w.width > 0 && w.height > 0 && !w.isGen) return (w.height.toFloat() / w.width).coerceIn(1.25f, 1.95f)
    val steps = floatArrayOf(16f / 9f, 1.5f, 1.72f, 1.9f, 1.35f)
    return steps[((w.seed % steps.size) + steps.size) % steps.size]
}

/**
 * Pinterest-style discovery: two independently flowing columns, different heights, tiny gaps, NO titles under images.
 * Content = round-robin of several topics (so the feed is varied) + built-in originals; append-only so cards never jump.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(nav: NavController) {
    val state = rememberLazyStaggeredGridState()
    val src = Store.activeSource
    val feedTopics = remember(src) { Discovery.topics.take(10) }
    val sources = remember(src) { feedTopics.map { Sources.get(it.query) } }
    val merged = remember(src) { mutableStateListOf<Wallpaper>() }
    val seen = remember(src) { HashSet<String>() }
    val gen = remember { Walls.all().shuffled(java.util.Random(java.time.LocalDate.now().toEpochDay())) }
    var genUsed by remember(src) { mutableIntStateOf(0) }
    var next by remember(src) { mutableIntStateOf(0) }

    fun addGen(n: Int) {
        var added = 0
        while (added < n && genUsed < gen.size) { val w = gen[genUsed++]; if (seen.add(w.id)) { merged.add(w); added++ } }
    }
    LaunchedEffect(src) { if (merged.isEmpty()) addGen(6) }
    sources.forEach { s ->
        LaunchedEffect(s.items.size) { for (w in s.items.toList()) if (seen.add(w.id) && !duplicateOf(merged, w)) merged.add(w) }
    }
    LaunchedEffect(src) {
        // first screenful: one page from the first few topics, sequentially (polite to the source)
        for (s in sources.take(4)) if (s.items.isEmpty() && !s.loading) s.load()
        next = 4
    }
    LaunchedEffect(state, src) {
        snapshotFlow { val li = state.layoutInfo; (li.visibleItemsInfo.lastOrNull()?.index ?: 0) to li.totalItemsCount }
            .collect { (last, total) ->
                if (total > 0 && last >= total - 8) {
                    val s = sources[next % sources.size]; next++
                    if (s.items.isEmpty()) s.loadMore() else s.loadMore()
                    addGen(3)
                }
            }
    }
    val anyLoading = sources.any { it.loading }
    val allFailed = sources.all { it.error != null } && sources.none { it.items.isNotEmpty() }
    val gap = (Store.layout.spacing / 2.5f).coerceIn(2f, 8f).dp

    LazyVerticalStaggeredGrid(
        columns = StaggeredGridCells.Fixed(2), state = state,
        contentPadding = PaddingValues(start = gap, end = gap, bottom = 130.dp),
        horizontalArrangement = Arrangement.spacedBy(gap), verticalItemSpacing = gap,
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
    ) {
        item(span = StaggeredGridItemSpan.FullLine) {
            Row(Modifier.padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.aura_identity), null, Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)))
                Text(stringResource(R.string.app_name), fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 10.dp))
            }
        }
        item(span = StaggeredGridItemSpan.FullLine) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(horizontal = 8.dp), modifier = Modifier.padding(bottom = 6.dp)) {
                items(Discovery.topics) { t ->
                    val name = stringResource(t.titleRes)
                    AssistChip(onClick = { nav.navigate(resultsRoute(t.query)) }, label = { Text(name) })
                }
            }
        }
        items(merged, key = { it.id }) { w -> MasonryCard(w) { openWallpaper(nav, it) } }
        item(span = StaggeredGridItemSpan.FullLine) {
            when {
                allFailed -> ErrorBlock(sources.firstNotNullOf { it.error }, onRetry = { sources.forEach { it.retry() } })
                anyLoading -> Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            }
        }
    }
}

/** Visual near-duplicate guard for the merged feed: same creator + same normalized title is dropped. */
private fun duplicateOf(list: List<Wallpaper>, w: com.fareshelmy.auraglass.data.Wallpaper): Boolean {
    val key = com.fareshelmy.auraglass.data.PagedSource.dedupKey(w)
    return key.isNotEmpty() && list.any { com.fareshelmy.auraglass.data.PagedSource.dedupKey(it) == key }
}

@Composable
fun MasonryCard(wp: Wallpaper, onClick: (Wallpaper) -> Unit) {
    Box(
        Modifier.fillMaxWidth().aspectRatio(1f / masonryRatio(wp)).clip(RoundedCornerShape(Store.layout.cardCorner.dp))
            .background(Pal.surface).pressClickable { onClick(wp) }.semantics { contentDescription = wp.title },
    ) {
        WallpaperImage(wp, Modifier.fillMaxSize())
    }
}
