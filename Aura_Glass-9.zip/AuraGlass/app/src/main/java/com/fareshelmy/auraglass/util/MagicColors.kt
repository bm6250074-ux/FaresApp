package com.fareshelmy.auraglass.util

import android.graphics.Bitmap
import android.graphics.Color

/** Extracts a usable palette from a wallpaper (no dependency): used to match the app / clock colours to it. */
object MagicColors {
    data class Result(val accent: Int, val dark: Int, val darker: Int, val isLight: Boolean, val text: Int)

    fun analyze(src: Bitmap): Result {
        val b = Bitmap.createScaledBitmap(src, 48, 48, true)
        val counts = HashMap<Int, Int>()
        var lum = 0.0
        for (y in 0 until 48) for (x in 0 until 48) {
            val c = b.getPixel(x, y)
            lum += (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0
            val key = ((Color.red(c) shr 4) shl 8) or ((Color.green(c) shr 4) shl 4) or (Color.blue(c) shr 4)
            counts[key] = (counts[key] ?: 0) + 1
        }
        val avgLum = lum / (48 * 48)
        val hsv = FloatArray(3)
        fun col(k: Int) = Color.rgb(((k shr 8) and 15) * 17, ((k shr 4) and 15) * 17, (k and 15) * 17)
        // accent = the most frequent colour that is actually colourful and not too dark/light
        val accentKey = counts.entries.sortedByDescending { it.value }.firstOrNull { e ->
            Color.colorToHSV(col(e.key), hsv); hsv[1] > 0.35f && hsv[2] in 0.35f..0.98f
        }?.key
        val accent = if (accentKey != null) col(accentKey) else Color.parseColor("#7CF4C8")
        // lift the accent so it stays readable on dark UI
        Color.colorToHSV(accent, hsv); hsv[1] = hsv[1].coerceIn(0.45f, 0.95f); hsv[2] = hsv[2].coerceIn(0.75f, 1f)
        val acc = Color.HSVToColor(hsv)
        Color.colorToHSV(accent, hsv)
        val h = hsv[0]
        val dark = Color.HSVToColor(floatArrayOf(h, 0.55f, 0.16f))
        val darker = Color.HSVToColor(floatArrayOf((h + 25f) % 360f, 0.6f, 0.05f))
        return Result(acc or 0xFF000000.toInt(), dark, darker, avgLum > 0.55, if (avgLum > 0.55) Color.BLACK else Color.WHITE)
    }
}
