package com.fareshelmy.auraglass.util

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Automatic subject (foreground) cut-out with ML Kit Subject Segmentation.
 *  - Runs on-device; the photo is never uploaded.
 *  - Needs Google Play services; the small model is downloaded by Play services the first time (internet needed once).
 *  - Returns null when unavailable (no Play services, offline first run, unsupported device, or no subject found);
 *    Depth Studio then falls back to the manual "foreground cut-out (PNG)" picker.
 */
object Segmentation {
    suspend fun foreground(bmp: Bitmap): Bitmap? = try {
        suspendCancellableCoroutine<Bitmap?> { cont ->
            val client = SubjectSegmentation.getClient(SubjectSegmenterOptions.Builder().enableForegroundBitmap().build())
            client.process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener { r -> if (cont.isActive) cont.resume(r.foregroundBitmap) }
                .addOnFailureListener { if (cont.isActive) cont.resume(null) }
            cont.invokeOnCancellation { client.close() }
        }
    } catch (e: Throwable) { null }
}
