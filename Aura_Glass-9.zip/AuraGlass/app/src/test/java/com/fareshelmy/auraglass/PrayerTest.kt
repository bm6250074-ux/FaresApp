package com.fareshelmy.auraglass

import com.fareshelmy.auraglass.data.PagedSource
import com.fareshelmy.auraglass.data.Wallpaper
import com.fareshelmy.auraglass.util.Prayer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class PrayerTest {
    private val mecca = Prayer.cities.first { it.en == "Mecca" }

    @Test fun meccaTimesAreOrderedAndPlausible() {
        val t = Prayer.forCity(LocalDate.of(2024, 3, 21), mecca, Prayer.methods[0])
        assertTrue(t.fajr < t.sunrise && t.sunrise < t.dhuhr && t.dhuhr < t.asr && t.asr < t.maghrib && t.maghrib < t.isha)
        assertTrue("dhuhr ${t.dhuhr}", t.dhuhr in 12.2..12.7)      // solar noon in Mecca in March is ~12:25-12:30
        assertTrue("fajr ${t.fajr}", t.fajr in 4.5..5.5)
        assertTrue("maghrib ${t.maghrib}", t.maghrib in 18.0..18.8)
    }

    @Test fun makkahMethodIshaIs90MinAfterMaghrib() {
        val t = Prayer.compute(LocalDate.of(2024, 6, 1), mecca.lat, mecca.lng, 3.0, Prayer.methods.first { it.key == "makkah" })
        assertEquals(1.5, t.isha - t.maghrib, 1e-6)
    }

    @Test fun formatsClock() {
        assertEquals("05:07", Prayer.fmt(5 + 7 / 60.0))
        assertEquals("1:30 PM", Prayer.fmt(13.5, false))
    }

    @Test fun nearDuplicateKeyIgnoresDigitsAndCase() {
        val a = Wallpaper("1", "Mountain Sunrise 01", "", "", creator = "Ann")
        val b = Wallpaper("2", "mountain sunrise 2", "", "", creator = "ann")
        assertEquals(PagedSource.dedupKey(a), PagedSource.dedupKey(b))
    }
}
