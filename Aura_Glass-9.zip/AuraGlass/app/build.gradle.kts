plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Optional fixed signing key (needed for Google Sign-In to work with CI-built APKs: the default debug key changes on every CI run).
// Provided only through environment variables by the GitHub Actions workflow (from repository secrets). Never committed.
val auraKeystorePath: String? = System.getenv("AURA_KEYSTORE_PATH")
val hasAuraKeystore = auraKeystorePath != null && file(auraKeystorePath).exists()

android {
    namespace = "com.fareshelmy.auraglass"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.fareshelmy.auraglass"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1.0-beta"

        // Non-secret deployment settings. Set them as Gradle properties / GitHub repo *variables*.
        // NEVER put API keys here: provider keys live only on your backend.
        val backend = providers.gradleProperty("AURA_BACKEND_URL").getOrElse("")
        val googleClient = providers.gradleProperty("GOOGLE_WEB_CLIENT_ID").getOrElse("")
        buildConfigField("String", "AURA_BACKEND_URL", "\"$backend\"")
        buildConfigField("String", "GOOGLE_WEB_CLIENT_ID", "\"$googleClient\"")
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    signingConfigs {
        if (hasAuraKeystore) {
            create("aura") {
                storeFile = file(auraKeystorePath!!)
                storePassword = System.getenv("AURA_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("AURA_KEY_ALIAS")
                keyPassword = System.getenv("AURA_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        debug {
            if (hasAuraKeystore) signingConfig = signingConfigs.getByName("aura")
        }
        release { isMinifyEnabled = false }
    }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.navigation:navigation-compose:2.8.4")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Google Sign-In via Credential Manager (only active when GOOGLE_WEB_CLIENT_ID is set)
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")

    // Automatic foreground/background separation for Depth Studio (on-device ML via Google Play services; model downloads on first use)
    implementation("com.google.android.gms:play-services-mlkit-subject-segmentation:16.0.0-beta1")

    testImplementation("junit:junit:4.13.2")
}
