// Aura Glass backend (Cloudflare Workers). UNTESTED by the author: deploy, then use Owner Settings > "Test server and providers".
// Secrets : OPENAI_API_KEY, GEMINI_API_KEY (the providers you use), PEXELS_API_KEY (optional "Aura Library")
// Variables: GOOGLE_WEB_CLIENT_ID  required for real authentication (Google ID token is verified on every request)
//            OWNER_SUB or OWNER_EMAIL  who the OWNER is. Set once by you in the dashboard. NOBODY becomes owner automatically.
//            ALLOW_ANON = "true"   TESTING ONLY: skips authentication (anyone with the URL can spend your API credit).
//            OPENAI_MODEL (default gpt-4o-mini), GEMINI_MODEL (default gemini-1.5-flash)
// Endpoints: GET /me, GET /health?provider=gpt|gemini, POST /chat, GET /wallpapers?q=&page=
const SYSTEM = "You are Aura AI, the assistant inside the Aura Glass Android app. Help with the app and wallpaper ideas. Reply in the user's language, short Markdown. " +
  "If the user wants wallpapers, end with one line 'SEARCH: <2-4 english keywords>'. Never invent image URLs. Refuse sexual or explicit content.";
const json = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { "Content-Type": "application/json" } });

async function identify(req, env) {            // -> {ok, sub, email, owner} ; owner decided ONLY by server configuration
  if (env.ALLOW_ANON === "true" && !(req.headers.get("Authorization") || "")) return { ok: true, sub: "anon", email: "", owner: false };
  if (!env.GOOGLE_WEB_CLIENT_ID) return { ok: false };
  const token = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
  if (!token) return { ok: false };
  const r = await fetch("https://oauth2.googleapis.com/tokeninfo?id_token=" + encodeURIComponent(token));
  if (!r.ok) return { ok: false };
  const c = await r.json();
  const valid = c.aud === env.GOOGLE_WEB_CLIENT_ID && Number(c.exp) * 1000 > Date.now() && (c.iss === "https://accounts.google.com" || c.iss === "accounts.google.com");
  if (!valid) return { ok: false };
  const owner = (env.OWNER_SUB && c.sub === env.OWNER_SUB) ||
    (!env.OWNER_SUB && env.OWNER_EMAIL && c.email_verified === "true" && String(c.email).toLowerCase() === env.OWNER_EMAIL.toLowerCase());
  return { ok: true, sub: c.sub, email: c.email || "", owner: !!owner };
}

async function callProvider(provider, msgs, env) {
  const started = Date.now();
  if (provider === "gemini") {
    if (!env.GEMINI_API_KEY) return { error: "GEMINI_API_KEY is not set on the backend" };
    const model = env.GEMINI_MODEL || "gemini-1.5-flash";
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: "POST", headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: SYSTEM }] }, contents: msgs.map(m => ({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content }] })) }),
    });
    if (r.status === 429) return { status: 429, error: "Gemini rate limit / quota reached" };
    if (!r.ok) return { status: 502, error: "Gemini error " + r.status + ": " + (await r.text()).slice(0, 200) };
    const j = await r.json();
    return { text: j.candidates?.[0]?.content?.parts?.map(p => p.text).join("") || "", model, latencyMs: Date.now() - started };
  }
  if (!env.OPENAI_API_KEY) return { error: "OPENAI_API_KEY is not set on the backend" };
  const model = env.OPENAI_MODEL || "gpt-4o-mini";
  const r = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + env.OPENAI_API_KEY },
    body: JSON.stringify({ model, messages: [{ role: "system", content: SYSTEM }, ...msgs.map(m => ({ role: m.role, content: m.content }))] }),
  });
  if (r.status === 429) return { status: 429, error: "OpenAI rate limit / quota reached" };
  if (!r.ok) return { status: 502, error: "OpenAI error " + r.status + ": " + (await r.text()).slice(0, 200) };
  const j = await r.json();
  return { text: j.choices?.[0]?.message?.content || "", model, latencyMs: Date.now() - started };
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const who = await identify(req, env);
    if (!who.ok) return json({ error: "Unauthorized (configure GOOGLE_WEB_CLIENT_ID, or ALLOW_ANON=true for testing)" }, 401);

    if (url.pathname === "/me") return json({ role: who.owner ? "owner" : "user" });

    if (url.pathname === "/health") {
      const provider = url.searchParams.get("provider") === "gemini" ? "gemini" : "gpt";
      const r = await callProvider(provider, [{ role: "user", content: "Reply with the single word: ok" }], env);
      if (r.error || !r.text) return json({ ok: false, provider, error: r.error || "empty response from provider" });
      return json({ ok: true, provider, model: r.model, latencyMs: r.latencyMs });
    }

    if (url.pathname === "/chat" && req.method === "POST") {
      let body; try { body = await req.json(); } catch { return json({ error: "bad json" }, 400); }
      const msgs = (body.messages || []).slice(-20).filter(m => (m.role === "user" || m.role === "assistant") && typeof m.content === "string").map(m => ({ role: m.role, content: m.content.slice(0, 4000) }));
      if (!msgs.length) return json({ error: "no messages" }, 400);
      const r = await callProvider(body.provider === "gemini" ? "gemini" : "gpt", msgs, env);
      if (r.error) return json({ error: r.error }, r.status || 503);
      const m = r.text.match(/^SEARCH:\s*(.+)$/m);
      return json({ reply: r.text.replace(/^SEARCH:.*$/m, "").trim(), search: m ? m[1].trim() : undefined });
    }

    if (url.pathname === "/wallpapers" && req.method === "GET") {
      if (!env.PEXELS_API_KEY) return json({ error: "PEXELS_API_KEY is not set on the backend" }, 503);
      const q = (url.searchParams.get("q") || "wallpaper").slice(0, 80);
      const page = Math.max(1, parseInt(url.searchParams.get("page") || "1", 10));
      const r = await fetch(`https://api.pexels.com/v1/search?query=${encodeURIComponent(q)}&orientation=portrait&per_page=30&page=${page}`, { headers: { Authorization: env.PEXELS_API_KEY }, cf: { cacheTtl: 3600, cacheEverything: true } });
      if (r.status === 429) return json({ error: "Pexels rate limit" }, 429);
      if (!r.ok) return json({ error: "Pexels error " + r.status }, 502);
      const j = await r.json();
      const items = (j.photos || []).map(p => ({ id: String(p.id), title: (p.alt || "Photo " + p.id).slice(0, 80), thumb: p.src.portrait,
        full: p.src.portrait.replace(/h=\d+/, "h=1920").replace(/w=\d+/, "w=1080"), creator: p.photographer, license: "Pexels License",
        licenseUrl: "https://www.pexels.com/license/", sourceUrl: p.url, width: 1080, height: 1920, tags: [] }));
      return json({ items, next: j.next_page ? String(page + 1) : "" });
    }
    return json({ error: "not found" }, 404);
  },
};
