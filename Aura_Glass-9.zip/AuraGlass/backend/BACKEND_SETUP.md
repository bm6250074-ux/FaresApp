# Backend (optional): Aura AI (GPT/Gemini), owner role, Aura Library
1. dash.cloudflare.com > Workers & Pages > Create > Create Worker > Deploy > Edit code > paste `worker.js` > Deploy.
2. Worker > Settings > Variables and secrets:
   - Secrets: `OPENAI_API_KEY` (paid, platform.openai.com) and/or `GEMINI_API_KEY` (aistudio.google.com/apikey, free tier with limits), `PEXELS_API_KEY` (optional, pexels.com/api).
   - Variable `GOOGLE_WEB_CLIENT_ID` (your Google Web OAuth client ID) — required for real authentication.
   - Variable `OWNER_EMAIL` (your Google account email) or, better, `OWNER_SUB` (your Google account id). Only this account is OWNER; nobody becomes owner automatically.
   - For a quick test only: `ALLOW_ANON` = `true` (anyone with the URL can spend your API credit; remove it afterwards).
3. GitHub repo > Settings > Secrets and variables > Actions > Variables: `AURA_BACKEND_URL` (worker URL, no trailing slash) and `GOOGLE_WEB_CLIENT_ID`.
4. Rebuild. Owner Settings (Profile) appears only for the configured owner account; Studio > Aura AI > "Test provider connection" makes a real provider request.
Not implemented on the server yet: purchases/Premium delivery, community uploads, automated moderation, video sources (see README).
