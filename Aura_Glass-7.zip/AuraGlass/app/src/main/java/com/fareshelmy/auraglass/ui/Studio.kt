package com.fareshelmy.auraglass.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import com.fareshelmy.auraglass.BuildConfig
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.data.GlassSettings
import com.fareshelmy.auraglass.data.Store
import com.fareshelmy.auraglass.util.Auth
import kotlinx.coroutines.launch

@Composable
fun BackTitle(nav: NavController, title: String) {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) }
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    }
}

val swatches = listOf(0xFFFFFFFF, 0xFF7CF4C8, 0xFF64B5F6, 0xFFBA68C8, 0xFFFF8A65, 0xFFFFD54F, 0xFFFF5C7A, 0xFF9CCC65, 0xFFB0BEC5, 0xFF000000).map { it.toInt() }

@Composable
fun ColorRow(selected: Int, onPick: (Int) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 4.dp)) {
        items(swatches) { c ->
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(Color(c))
                    .border(if (c == selected) 3.dp else 1.dp, if (c == selected) Color(0xFF7CF4C8) else Color(0x66FFFFFF), CircleShape)
                    .clickable { onPick(c) },
            )
        }
    }
}

@Composable
private fun HubCard(titleRes: Int, bodyRes: Int, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().liquidGlass().pressClickable(onClick).padding(18.dp)) {
        Text(stringResource(titleRes), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(stringResource(bodyRes), color = Pal.muted, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun StudioScreen(nav: NavController) {
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ScreenTitle(stringResource(R.string.tab_studio)) }
        item { HubCard(R.string.clock_universe, R.string.clock_universe_sub) { nav.navigate("clocks") } }
        item { HubCard(R.string.depth_studio, R.string.depth_studio_sub) { nav.navigate("depth") } }
        item { HubCard(R.string.widget_studio, R.string.widget_studio_sub) { nav.navigate("widgets") } }
        item { HubCard(R.string.islamic_widgets, R.string.islamic_widgets_sub) { nav.navigate("islamic") } }
        item { HubCard(R.string.glass_studio, R.string.glass_studio_sub) { nav.navigate("glass") } }
    }
}

@Composable
fun ProfileScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ScreenTitle(stringResource(R.string.tab_profile)) }
        item {
            Section {
                Text(stringResource(R.string.account), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                if (!Auth.enabled) {
                    Text(stringResource(R.string.guest_mode), color = Pal.muted)
                    Text(stringResource(R.string.google_needs_config), fontSize = 12.sp, color = Pal.warn)
                } else if (Auth.idToken != null) {
                    Text(Store.accountName.ifBlank { Store.accountEmail }); Text(Store.accountEmail, color = Pal.muted)
                    OutlinedButton(onClick = { scope.launch { Auth.signOut(ctx) } }) { Text(stringResource(R.string.sign_out)) }
                }
            }
        }
        item {
            Section {
                Text(stringResource(R.string.language), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("system" to R.string.lang_system, "ar" to R.string.lang_ar, "en" to R.string.lang_en).forEach { (code, r) ->
                        FilterChip(selected = Store.language == code, onClick = { applyLanguage(code) }, label = { Text(stringResource(r)) })
                    }
                }
            }
        }
        item { Button(onClick = { Store.showIntro = true }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.replay_intro)) } }
        item { OutlinedButton(onClick = { nav.navigate("glass") }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.glass_studio)) } }
        if (Auth.role == "owner") item { Button(onClick = { nav.navigate("owner") }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.owner_title)) } }
        item { OutlinedButton(onClick = { nav.navigate("about") }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.about_title)) } }
    }
}

@Composable
fun AboutScreen(nav: NavController) {
    val ctx = LocalContext.current
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { BackTitle(nav, stringResource(R.string.about_title)) }
        item {
            Section {
                Text(stringResource(R.string.app_version), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("https://t.me/izxmy", fontSize = 16.sp, color = Pal.accent, modifier = Modifier.clickable { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/izxmy"))) })
                Button(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/izxmy"))) }) { Text(stringResource(R.string.open_telegram)) }
            }
        }
    }
}

/**
 * Owner Settings. The Profile button only appears when the BACKEND says this Google account is the configured owner
 * (OWNER_SUB / OWNER_EMAIL on the server), and this screen re-checks the role. Everything here is read-only information or
 * local technical tools. Server-side administration (moderation, sales, content management) needs backend features that
 * do not exist yet, so nothing for them is shown.
 */
@Composable
fun OwnerScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    if (Auth.role != "owner") { androidx.compose.runtime.LaunchedEffect(Unit) { nav.popBackStack() }; return }
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { BackTitle(nav, stringResource(R.string.owner_title)) }
        item { Section { Text(stringResource(R.string.sources_title), fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(stringResource(R.string.sources_body)) } }
        item { Section { Text(stringResource(R.string.costs_title), fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(stringResource(R.string.costs_body)) } }
        item { Section { Text(stringResource(R.string.privacy_title), fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(stringResource(R.string.privacy_body)) } }
        item {
            Section {
                Text(stringResource(R.string.config_title), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Version: " + BuildConfig.VERSION_NAME + " (" + BuildConfig.VERSION_CODE + ")")
                Text("Backend: " + BuildConfig.AURA_BACKEND_URL.ifBlank { "—" })
                Text("Google Sign-In: " + (if (Auth.enabled) "on" else "off") + " · role: " + Auth.role)
                Text(stringResource(R.string.wallpaper_source) + ": " + Store.catalogSource)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = Store.catalogSource == "commons", onClick = { Store.setCatalogSource("commons") }, label = { Text("Wikimedia Commons") })
                    FilterChip(selected = Store.catalogSource == "openverse", onClick = { Store.setCatalogSource("openverse") }, label = { Text("Openverse") })
                    if (BuildConfig.AURA_BACKEND_URL.isNotBlank()) FilterChip(selected = Store.catalogSource == "aura", onClick = { Store.setCatalogSource("aura") }, label = { Text(stringResource(R.string.source_aura)) })
                }
                Text(stringResource(R.string.source_note), fontSize = 12.sp, color = Pal.muted)
            }
        }
        item {
            Section {
                Text(stringResource(R.string.tech_title), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                OutlinedButton(onClick = {
                    val loader = coil.Coil.imageLoader(ctx)
                    loader.memoryCache?.clear(); loader.diskCache?.clear()
                    ctx.toast(R.string.cache_cleared)
                }) { Text(stringResource(R.string.clear_image_cache)) }
            }
        }
    }
}
