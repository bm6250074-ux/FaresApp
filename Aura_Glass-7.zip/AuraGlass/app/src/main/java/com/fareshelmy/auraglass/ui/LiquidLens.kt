package com.fareshelmy.auraglass.ui

import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp

/**
 * Real "Liquid Glass" panel material (iOS 26 style) for floating panels such as the bottom bar.
 *  API 33+ : AGSL lens (rim refraction, chromatic dispersion, specular rim light, inner glow).
 *  API 31-32: 5 magnified clipped bands + saturation/blur + gradient rim lights.
 *  < 31 or no backdrop: translucent tint + gradient border.
 * [backdrop] is the GraphicsLayer that records everything BEHIND the panel (see backdropSource).
 * Use it on a SIBLING layer (Box(Modifier.matchParentSize().liquidLens(...))) when the panel has animated children.
 */
fun Modifier.liquidLens(
    backdrop: GraphicsLayer?,
    shape: Shape,
    strength: Float = 0.6f,
    dark: Boolean,
): Modifier = composed {
    val lens = remember { if (Build.VERSION.SDK_INT >= 33) LiquidShader() else null }

    if (backdrop != null && lens != null) {
        // ---------- API 33+: real AGSL lens ----------
        val panelLayer = rememberGraphicsLayer()
        val pos = remember { mutableStateOf(Offset.Zero) }
        this
            .onGloballyPositioned { pos.value = it.positionInRoot() }
            .clip(shape)
            .drawWithContent {
                val p = pos.value
                val pad = (64f * density).toInt()
                panelLayer.record(
                    size = IntSize(size.width.toInt() + 2 * pad, size.height.toInt() + 2 * pad)
                ) {
                    translate(pad - p.x, pad - p.y) {
                        drawLayer(backdrop)
                    }
                }
                val outline = shape.createOutline(size, layoutDirection, this)
                val r = when (outline) {
                    is Outline.Rounded -> outline.roundRect.topLeftCornerRadius.x
                    is Outline.Rectangle -> 0f
                    else -> minOf(size.width, size.height) / 2f
                }
                val pf = pad.toFloat()
                panelLayer.renderEffect = lens.effect(pf, pf, pf + size.width, pf + size.height, r, density, strength, dark)
                translate(-pf, -pf) { drawLayer(panelLayer) }
                drawContent()
            }
    } else if (backdrop != null && Build.VERSION.SDK_INT >= 31) {
        // ---------- API 31-32: approximate the lens ----------
        val panelLayer = rememberGraphicsLayer()
        val pos = remember { mutableStateOf(Offset.Zero) }
        this
            .onGloballyPositioned { pos.value = it.positionInRoot() }
            .clip(shape)
            .drawWithContent {
                val p = pos.value
                val pad = (64f * density).toInt()
                val pf = pad.toFloat()
                val outline = shape.createOutline(size, layoutDirection, this)
                val r = when (outline) {
                    is Outline.Rounded -> outline.roundRect.topLeftCornerRadius.x
                    is Outline.Rectangle -> 0f
                    else -> minOf(size.width, size.height) / 2f
                }
                val bezel = (10f + 16f * strength) * density
                val step = 0.016f * (0.4f + strength)
                val pw = size.width
                val ph = size.height
                val center = Offset(pf + pw / 2f, pf + ph / 2f)
                panelLayer.record(size = IntSize(pw.toInt() + 2 * pad, ph.toInt() + 2 * pad)) {
                    for (j in 0..4) {
                        val inset = j * bezel / 4f
                        val rr = RoundRect(
                            pf + inset, pf + inset, pf + pw - inset, pf + ph - inset,
                            CornerRadius((r - inset).coerceAtLeast(0f))
                        )
                        val path = Path().apply { addRoundRect(rr) }
                        val sc = 1f + step * (4 - j)
                        clipPath(path) {
                            withTransform({
                                scale(sc, sc, center)
                                translate(pad - p.x, pad - p.y)
                            }) {
                                drawLayer(backdrop)
                            }
                        }
                    }
                }
                val sat = RenderEffect.createColorFilterEffect(
                    android.graphics.ColorMatrixColorFilter(
                        android.graphics.ColorMatrix().apply { setSaturation(1f + 0.35f * strength) }
                    )
                )
                val sigma = (4f + 5f * (1f - strength)) * density
                val blur = RenderEffect.createBlurEffect(sigma, sigma, Shader.TileMode.CLAMP)
                panelLayer.renderEffect = RenderEffect.createChainEffect(sat, blur).asComposeRenderEffect()
                translate(-pf, -pf) { drawLayer(panelLayer) }
                drawRoundRect(Color.White.copy(alpha = if (dark) 0.06f else 0.18f), cornerRadius = CornerRadius(r))
                drawRoundRect(
                    brush = Brush.linearGradient(
                        listOf(Color.White.copy(alpha = 0.28f * (0.4f + strength)), Color.Transparent),
                        start = Offset.Zero, end = Offset(size.width * 0.65f, size.height * 0.65f)
                    ),
                    cornerRadius = CornerRadius(r),
                    style = Stroke(bezel * 0.9f)
                )
                drawRoundRect(
                    brush = Brush.linearGradient(
                        listOf(Color.White.copy(alpha = 0.9f), Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.38f)),
                        start = Offset.Zero, end = Offset(size.width, size.height)
                    ),
                    cornerRadius = CornerRadius(r),
                    style = Stroke(1.6f * density)
                )
                drawContent()
            }
    } else {
        // ---------- below API 31 / no backdrop: translucent tint ----------
        this.clip(shape)
            .background(
                Brush.verticalGradient(
                    if (dark) listOf(Color.White.copy(alpha = 0.16f), Color.White.copy(alpha = 0.07f))
                    else listOf(Color.White.copy(alpha = 0.68f), Color.White.copy(alpha = 0.42f))
                )
            )
            .border(
                1.dp,
                Brush.linearGradient(listOf(Color.White.copy(alpha = if (dark) 0.32f else 0.9f), Color.White.copy(alpha = 0.05f))),
                shape
            )
    }
}
