package com.fareshelmy.auraglass.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import com.fareshelmy.auraglass.BuildConfig
import com.fareshelmy.auraglass.R
import com.fareshelmy.auraglass.data.GlassSettings
import com.fareshelmy.auraglass.data.Store
import com.fareshelmy.auraglass.data.Net
import com.fareshelmy.auraglass.util.Auth
import com.fareshelmy.auraglass.util.findActivity
import kotlinx.coroutines.launch

@Composable
fun BackTitle(nav: NavController, title: String) {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) }
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    }
}

val swatches = listOf(0xFFFFFFFF, 0xFF7CF4C8, 0xFF64B5F6, 0xFFBA68C8, 0xFFFF8A65, 0xFFFFD54F, 0xFFFF5C7A, 0xFF9CCC65, 0xFFB0BEC5, 0xFF000000).map { it.toInt() }

@Composable
fun ColorRow(selected: Int, onPick: (Int) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 4.dp)) {
        items(swatches) { c ->
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(Color(c))
                    .border(if (c == selected) 3.dp else 1.dp, if (c == selected) Color(0xFF7CF4C8) else Color(0x66FFFFFF), CircleShape)
                    .clickable { onPick(c) },
            )
        }
    }
}

@Composable
private fun HubCard(titleRes: Int, bodyRes: Int, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().liquidGlass().pressClickable(onClick).padding(18.dp)) {
        Text(stringResource(titleRes), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(stringResource(bodyRes), color = Pal.muted, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun StudioScreen(nav: NavController) {
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ScreenTitle(stringResource(R.string.tab_studio)) }
        item { HubCard(R.string.clock_universe, R.string.clock_universe_sub) { nav.navigate("clocks") } }
        item { HubCard(R.string.depth_studio, R.string.depth_studio_sub) { nav.navigate("depth") } }
        item { HubCard(R.string.widget_studio, R.string.widget_studio_sub) { nav.navigate("widgets") } }
        item { HubCard(R.string.islamic_widgets, R.string.islamic_widgets_sub) { nav.navigate("islamic") } }
        item { HubCard(R.string.glass_studio, R.string.glass_studio_sub) { nav.navigate("glass") } }
    }
}

@Composable
private fun GroupLabel(text: String) {
    Text(text, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Pal.muted, modifier = Modifier.padding(start = 6.dp, top = 6.dp))
}

@Composable
private fun RowDivider() {
    androidx.compose.foundation.layout.Spacer(Modifier.fillMaxWidth().height(1.dp).background(Pal.muted.copy(alpha = 0.18f)))
}

/** One tappable settings line: title + optional subtitle, with a direction-aware chevron (same size in Arabic and English). */
@Composable
private fun SettingsRow(title: String, subtitle: String? = null, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).pressClickable(onClick).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            if (subtitle != null) Text(subtitle, fontSize = 12.sp, lineHeight = 16.sp, color = Pal.muted)
        }
        Icon(
            Icons.AutoMirrored.Filled.ArrowBack, null, tint = Pal.muted,
            modifier = Modifier.size(16.dp).graphicsLayer { rotationZ = 180f },
        )
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Pal.muted, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun ProfileScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    // If the backend could not be reached at sign-in, ask again when the profile opens (the role is never guessed locally).
    androidx.compose.runtime.LaunchedEffect(Auth.idToken) { if (Auth.idToken != null && !Auth.roleResolved) Auth.refreshRole() }
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ScreenTitle(stringResource(R.string.tab_profile)) }
        // ---- header: app identity + account state
        item {
            Section {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    androidx.compose.foundation.Image(
                        androidx.compose.ui.res.painterResource(R.drawable.aura_identity), null,
                        Modifier.size(64.dp).clip(RoundedCornerShape(18.dp)),
                    )
                    Column(Modifier.weight(1f)) {
                        Text("Aura Glass", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text(stringResource(R.string.app_version), fontSize = 13.sp, color = Pal.muted)
                    }
                }
                RowDivider()
                Text(stringResource(R.string.account), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Pal.muted)
                if (!Auth.enabled) {
                    Text(stringResource(R.string.guest_mode), fontSize = 14.sp, lineHeight = 20.sp)
                    Text(stringResource(R.string.google_needs_config), fontSize = 12.sp, lineHeight = 16.sp, color = Pal.warn)
                } else if (Auth.idToken != null) {
                    Text(Store.accountName.ifBlank { Store.accountEmail }, fontWeight = FontWeight.Medium)
                    Text(Store.accountEmail, color = Pal.muted, fontSize = 13.sp)
                    val isOwner = Auth.role == "owner"
                    Text(
                        stringResource(R.string.account_type) + ": " + stringResource(if (isOwner) R.string.role_owner else R.string.role_member),
                        fontSize = 14.sp, fontWeight = FontWeight.Medium, color = if (isOwner) Pal.accent else Pal.muted,
                    )
                    if (BuildConfig.AURA_BACKEND_URL.isBlank()) Text(stringResource(R.string.backend_missing), fontSize = 12.sp, lineHeight = 16.sp, color = Pal.warn)
                    else if (!Auth.roleResolved) Text(stringResource(R.string.role_unverified), fontSize = 12.sp, lineHeight = 16.sp, color = Pal.warn)
                    OutlinedButton(onClick = { scope.launch { Auth.signOut(ctx) } }) { Text(stringResource(R.string.sign_out)) }
                }
            }
        }
        // ---- general
        item { GroupLabel(stringResource(R.string.pf_group_general)) }
        item {
            Section {
                Text(stringResource(R.string.language), fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("system" to R.string.lang_system, "ar" to R.string.lang_ar, "en" to R.string.lang_en).forEach { (code, r) ->
                        FilterChip(selected = Store.language == code, onClick = { applyLanguage(code) }, label = { Text(stringResource(r)) })
                    }
                }
            }
        }
        // ---- appearance
        item { GroupLabel(stringResource(R.string.pf_group_look)) }
        item {
            Section {
                SettingsRow(stringResource(R.string.glass_studio), stringResource(R.string.glass_studio_sub)) { nav.navigate("glass") }
                RowDivider()
                SettingsRow(stringResource(R.string.replay_intro)) { Store.showIntro = true }
            }
        }
        // ---- app
        item { GroupLabel(stringResource(R.string.pf_group_app)) }
        item {
            Section {
                if (Auth.role == "owner") {
                    SettingsRow(stringResource(R.string.owner_title)) { nav.navigate("owner") }
                    RowDivider()
                }
                SettingsRow(stringResource(R.string.about_title), stringResource(R.string.about_desc)) { nav.navigate("about") }
            }
        }
    }
}

@Composable
fun AboutScreen(nav: NavController) {
    val ctx = LocalContext.current
    val open = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/izxmy"))) }
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { BackTitle(nav, stringResource(R.string.about_title)) }
        // ---- hero
        item {
            Section {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    androidx.compose.foundation.Image(
                        androidx.compose.ui.res.painterResource(R.drawable.aura_identity), null,
                        Modifier.size(96.dp).clip(RoundedCornerShape(26.dp)),
                    )
                    Text("Aura Glass", fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                    Text(stringResource(R.string.app_version), fontSize = 13.sp, color = Pal.muted)
                    Text(
                        stringResource(R.string.about_desc), fontSize = 14.sp, lineHeight = 20.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.padding(top = 4.dp),
                    )
                }
            }
        }
        // ---- who made it
        item { GroupLabel(stringResource(R.string.about_made_by)) }
        item {
            Section {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(48.dp).clip(CircleShape).background(Pal.accent.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
                        Text("iz", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Pal.accent)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("@izxmy", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(stringResource(R.string.about_role), fontSize = 13.sp, color = Pal.muted)
                    }
                }
                Button(onClick = { open() }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.open_telegram)) }
                Text(stringResource(R.string.about_follow), fontSize = 12.sp, lineHeight = 16.sp, color = Pal.muted)
            }
        }
        // ---- details
        item { GroupLabel(stringResource(R.string.about_details)) }
        item {
            Section {
                InfoLine(stringResource(R.string.about_version), BuildConfig.VERSION_NAME)
                RowDivider()
                InfoLine(stringResource(R.string.about_channel), "t.me/izxmy")
            }
        }
    }
}

private data class AdminUser(val name: String, val email: String, val role: String, val createdAt: Long)
private data class AdminData(val total: Int, val emailOn: Boolean, val users: List<AdminUser>)

private suspend fun loadAdmin(ctx: android.content.Context): AdminData {
    val base = BuildConfig.AURA_BACKEND_URL.trimEnd('/')
    val txt = Auth.authed(ctx.findActivity()) { t -> Net.getJson("$base/admin/users", t, 20000) }
    val j = org.json.JSONObject(txt)
    val arr = j.optJSONArray("users") ?: org.json.JSONArray()
    val list = (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        AdminUser(o.optString("name"), o.optString("email"), o.optString("role"), o.optLong("createdAt"))
    }
    return AdminData(j.optInt("total", list.size), j.optBoolean("emailConfigured", false), list)
}

/**
 * Owner Settings. The Profile button only appears when the BACKEND says this Google account is the configured owner
 * (OWNER_SUB / OWNER_EMAIL on the server), and this screen re-checks the role. Everything here is read-only information or
 * local technical tools. Server-side administration (moderation, sales, content management) needs backend features that
 * do not exist yet, so nothing for them is shown.
 */
@Composable
fun OwnerScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    if (Auth.role != "owner") { androidx.compose.runtime.LaunchedEffect(Unit) { nav.popBackStack() }; return }
    var admin by remember { mutableStateOf<AdminData?>(null) }
    var adminFailed by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf(false) }
    val sentMsg = stringResource(R.string.test_email_sent)
    val failMsg = stringResource(R.string.test_email_failed)
    androidx.compose.runtime.LaunchedEffect(Unit) {
        try { admin = loadAdmin(ctx); adminFailed = false } catch (e: Exception) { adminFailed = true }
    }
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { BackTitle(nav, stringResource(R.string.owner_title)) }
        // ---- developer options (server-enforced: these endpoints answer only to the stored owner account)
        item {
            Section {
                Text(stringResource(R.string.dev_options), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                val a = admin
                Text(
                    stringResource(R.string.registered_accounts) + (if (a != null) ": " + a.total else ""),
                    fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Pal.muted,
                )
                when {
                    adminFailed -> Text(stringResource(R.string.accounts_error), fontSize = 12.sp, lineHeight = 16.sp, color = Pal.warn)
                    a == null -> Text(stringResource(R.string.accounts_loading), fontSize = 13.sp, color = Pal.muted)
                    else -> a.users.take(50).forEach { u ->
                        RowDivider()
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(u.name.ifBlank { u.email }, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                Text(u.email + " · " + java.text.DateFormat.getDateInstance().format(java.util.Date(u.createdAt)), fontSize = 12.sp, color = Pal.muted, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                            }
                            Text(
                                stringResource(if (u.role == "owner") R.string.role_owner else R.string.role_member), fontSize = 12.sp,
                                color = if (u.role == "owner") Pal.accent else Pal.muted, modifier = Modifier.padding(start = 8.dp),
                            )
                        }
                    }
                }
                RowDivider()
                Text(stringResource(R.string.email_status) + ": " + stringResource(if (admin?.emailOn == true) R.string.email_on else R.string.email_off), fontSize = 14.sp)
                OutlinedButton(
                    enabled = !testing && admin?.emailOn == true,
                    onClick = {
                        testing = true
                        scope.launch {
                            val base = BuildConfig.AURA_BACKEND_URL.trimEnd('/')
                            val msg = try {
                                val r = Auth.authed(ctx.findActivity()) { t -> Net.postJson("$base/admin/test-email", t, "{}") }
                                val j = org.json.JSONObject(r)
                                if (j.optBoolean("ok")) sentMsg else failMsg + j.optString("error")
                            } catch (e: Exception) { failMsg + (e.message ?: "") }
                            android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_LONG).show()
                            testing = false
                        }
                    },
                ) { Text(stringResource(R.string.send_test_email)) }
            }
        }
        item { Section { Text(stringResource(R.string.sources_title), fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(stringResource(R.string.sources_body)) } }
        item { Section { Text(stringResource(R.string.costs_title), fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(stringResource(R.string.costs_body)) } }
        item { Section { Text(stringResource(R.string.privacy_title), fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(stringResource(R.string.privacy_body)) } }
        item {
            Section {
                Text(stringResource(R.string.config_title), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Version: " + BuildConfig.VERSION_NAME + " (" + BuildConfig.VERSION_CODE + ")")
                Text("Backend: " + BuildConfig.AURA_BACKEND_URL.ifBlank { "—" })
                Text("Google Sign-In: " + (if (Auth.enabled) "on" else "off") + " · role: " + Auth.role)
                Text(stringResource(R.string.wallpaper_source) + ": " + Store.catalogSource)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = Store.catalogSource == "commons", onClick = { Store.setCatalogSource("commons") }, label = { Text("Wikimedia Commons") })
                    FilterChip(selected = Store.catalogSource == "openverse", onClick = { Store.setCatalogSource("openverse") }, label = { Text("Openverse") })
                    if (BuildConfig.AURA_BACKEND_URL.isNotBlank()) FilterChip(selected = Store.catalogSource == "aura", onClick = { Store.setCatalogSource("aura") }, label = { Text(stringResource(R.string.source_aura)) })
                }
                Text(stringResource(R.string.source_note), fontSize = 12.sp, color = Pal.muted)
            }
        }
        item {
            Section {
                Text(stringResource(R.string.tech_title), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                OutlinedButton(onClick = {
                    val loader = coil.Coil.imageLoader(ctx)
                    loader.memoryCache?.clear(); loader.diskCache?.clear()
                    ctx.toast(R.string.cache_cleared)
                }) { Text(stringResource(R.string.clear_image_cache)) }
            }
        }
    }
}
