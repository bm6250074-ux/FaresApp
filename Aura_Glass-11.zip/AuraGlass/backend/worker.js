// Aura Glass backend (Cloudflare Workers + D1). UNTESTED by the author: deploy, then use Owner Settings.
// Bindings : DB (a D1 database)  REQUIRED for accounts. The table is created automatically on first request.
// Variables: GOOGLE_WEB_CLIENT_ID  required: the Google ID token is verified on every request.
//            OWNER_EMAIL           OPTIONAL. If set, ONLY this email can become owner. If empty, the FIRST account that ever registers is the owner.
//            GMAIL_SENDER          the Gmail address that sends the emails (optional; without Gmail settings no emails are sent)
//            ALLOW_ANON = "true"   TESTING ONLY: skips authentication (anyone with the URL can spend your API credit).
//            OPENAI_MODEL (default gpt-4o-mini), GEMINI_MODEL (default gemini-1.5-flash)
// Secrets  : GMAIL_CLIENT_ID, GMAIL_CLIENT_SECRET, GMAIL_REFRESH_TOKEN (send mail through the Gmail API), OPENAI_API_KEY, GEMINI_API_KEY, PEXELS_API_KEY (optional)
// Endpoints: GET /me (registers on first call), GET /admin/users + POST /admin/test-email (owner only),
//            GET /health?provider=gpt|gemini, POST /chat, GET /wallpapers?q=&page=
// Roles are decided ONLY here, once, when the account is first stored. Nothing in the app can send or change a role.
const SYSTEM = "You are Aura AI, the assistant inside the Aura Glass Android app. Help with the app and wallpaper ideas. Reply in the user's language, short Markdown. " +
  "If the user wants wallpapers, end with one line 'SEARCH: <2-4 english keywords>'. Never invent image URLs. Refuse sexual or explicit content.";
const json = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { "Content-Type": "application/json" } });

async function identify(req, env) {            // -> {ok, sub, email, name, verified}; the ROLE comes from the database, never from the token
  if (env.ALLOW_ANON === "true" && !(req.headers.get("Authorization") || "")) return { ok: true, sub: "anon", email: "", name: "", verified: false };
  if (!env.GOOGLE_WEB_CLIENT_ID) return { ok: false };
  const token = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
  if (!token) return { ok: false };
  const r = await fetch("https://oauth2.googleapis.com/tokeninfo?id_token=" + encodeURIComponent(token));
  if (!r.ok) return { ok: false };
  const c = await r.json();
  const valid = c.aud === env.GOOGLE_WEB_CLIENT_ID && Number(c.exp) * 1000 > Date.now() && (c.iss === "https://accounts.google.com" || c.iss === "accounts.google.com");
  if (!valid) return { ok: false };
  return { ok: true, sub: c.sub, email: c.email || "", name: c.name || "", verified: c.email_verified === "true" || c.email_verified === true };
}

// ---------------------------------------------------------------- accounts (D1)
let schemaReady = null;
function ensureSchema(env) {
  if (!env.DB) return Promise.reject(new Error("D1 binding DB is not configured"));
  if (!schemaReady) {
    schemaReady = env.DB.batch([
      env.DB.prepare("CREATE TABLE IF NOT EXISTS users (sub TEXT PRIMARY KEY, email TEXT NOT NULL, name TEXT NOT NULL DEFAULT '', " +
        "role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('owner','member')), created_at INTEGER NOT NULL, last_login_at INTEGER NOT NULL, welcome_sent INTEGER NOT NULL DEFAULT 0, owner_notified INTEGER NOT NULL DEFAULT 0)"),
      // The database itself refuses a second owner, even under a race or a bug.
      env.DB.prepare("CREATE UNIQUE INDEX IF NOT EXISTS one_owner ON users(role) WHERE role = 'owner'"),
    ]).then(async () => {
      // Upgrade path for a table created by an earlier version: add the column once and mark existing accounts as already handled.
      try {
        await env.DB.prepare("ALTER TABLE users ADD COLUMN owner_notified INTEGER NOT NULL DEFAULT 0").run();
        await env.DB.prepare("UPDATE users SET owner_notified = 1").run();
      } catch (e) { /* column already exists */ }
    }).catch(e => { schemaReady = null; throw e; });
  }
  return schemaReady;
}

/** Creates the account on first sight (ONE atomic statement decides the role), otherwise just records the login. The role is never updated afterwards. */
async function registerOrLogin(env, who) {
  await ensureSchema(env);
  const now = Date.now();
  const email = who.email.toLowerCase();
  const name = (who.name || "").slice(0, 120);
  const ownerEmail = (env.OWNER_EMAIL || "").trim().toLowerCase();
  const insertSql =
    "INSERT INTO users (sub, email, name, role, created_at, last_login_at, welcome_sent) " +
    "SELECT ?1, ?2, ?3, " +
    "CASE WHEN ?5 <> '' THEN (CASE WHEN ?2 = ?5 THEN 'owner' ELSE 'member' END) " +
    "     WHEN (SELECT COUNT(*) FROM users) = 0 THEN 'owner' ELSE 'member' END, ?4, ?4, 0 " +
    "WHERE NOT EXISTS (SELECT 1 FROM users WHERE sub = ?1)";
  try {
    await env.DB.prepare(insertSql).bind(who.sub, email, name, now, ownerEmail).run();
  } catch (e) {
    // e.g. OWNER_EMAIL was configured after another owner already existed: the unique index refuses, so this account is stored as a normal member.
    await env.DB.prepare("INSERT OR IGNORE INTO users (sub, email, name, role, created_at, last_login_at, welcome_sent) VALUES (?1, ?2, ?3, 'member', ?4, ?4, 0)")
      .bind(who.sub, email, name, now).run();
  }
  await env.DB.prepare("UPDATE users SET last_login_at = ?2, email = ?3, name = CASE WHEN ?4 <> '' THEN ?4 ELSE name END WHERE sub = ?1")
    .bind(who.sub, now, email, name).run();
  return await env.DB.prepare("SELECT sub, email, name, role, created_at, welcome_sent, owner_notified FROM users WHERE sub = ?1").bind(who.sub).first();
}

// ---------------------------------------------------------------- email through the Gmail API
const mailConfigured = env => !!(env.GMAIL_CLIENT_ID && env.GMAIL_CLIENT_SECRET && env.GMAIL_REFRESH_TOKEN && env.GMAIL_SENDER);
const esc = t => String(t).replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
const b64 = str => { const bytes = new TextEncoder().encode(str); let bin = ""; for (const x of bytes) bin += String.fromCharCode(x); return btoa(bin); };
const b64url = str => b64(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");

async function sendMail(env, to, subject, html) {
  if (!mailConfigured(env)) throw new Error("Gmail is not configured on the backend");
  const tr = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ client_id: env.GMAIL_CLIENT_ID, client_secret: env.GMAIL_CLIENT_SECRET, refresh_token: env.GMAIL_REFRESH_TOKEN, grant_type: "refresh_token" }),
  });
  if (!tr.ok) throw new Error("Gmail token error " + tr.status + ": " + (await tr.text()).slice(0, 160));
  const access = (await tr.json()).access_token;
  const clean = x => String(x).replace(/[\r\n]+/g, " ");
  const body = b64(html).replace(/(.{76})/g, "$1\r\n");
  const mime = [
    "From: Aura Glass <" + clean(env.GMAIL_SENDER) + ">", "To: " + clean(to), "Subject: =?UTF-8?B?" + b64(subject) + "?=",
    "MIME-Version: 1.0", 'Content-Type: text/html; charset="UTF-8"', "Content-Transfer-Encoding: base64", "", body,
  ].join("\r\n");
  const r = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", {
    method: "POST", headers: { Authorization: "Bearer " + access, "Content-Type": "application/json" }, body: JSON.stringify({ raw: b64url(mime) }),
  });
  if (!r.ok) throw new Error("Gmail send error " + r.status + ": " + (await r.text()).slice(0, 160));
}

function welcomeMail(user) {
  const owner = user.role === "owner";
  const date = new Date(user.created_at).toUTCString();
  const row = (k, v) => `<tr><td style="padding:4px 12px;color:#667">${k}</td><td style="padding:4px 12px;font-weight:600">${esc(v)}</td></tr>`;
  const ar = owner
    ? `<p>مرحباً ${esc(user.name || "")}،</p><p>أنت أول من سجّل في <b>Aura Glass</b>، لذلك تم تعيينك <b>المالك</b> لهذا التطبيق. هذا الدور محفوظ في قاعدة البيانات ولا يمكن لأي حساب آخر أن يصبح مالكاً.</p>
       <p>كمالك ستجد في الملف الشخصي &larr; إعدادات المالك خيارات المطوّر: قائمة الحسابات المسجلة وإعدادات السيرفر واختبار البريد.</p>`
    : `<p>مرحباً ${esc(user.name || "")}،</p><p>تم إنشاء حسابك في <b>Aura Glass</b> وحفظه بنجاح. يمكنك تسجيل الدخول في أي وقت بنفس حساب Google.</p>`;
  const en = owner
    ? `<p>Hello ${esc(user.name || "")},</p><p>You are the first person to register in <b>Aura Glass</b>, so you are the <b>Owner</b> of the app. This role is stored in the database and no other account can become owner.</p>
       <p>As owner, Profile &rarr; Owner Settings contains the developer options: the list of registered accounts, server settings and the email test.</p>`
    : `<p>Hello ${esc(user.name || "")},</p><p>Your <b>Aura Glass</b> account was created and saved. You can sign in at any time with the same Google account.</p>`;
  const table = (l) => `<table style="border-collapse:collapse;margin:8px 0">${row(l.n, user.name || "-")}${row(l.e, user.email)}${row(l.t, owner ? l.o : l.m)}${row(l.d, date)}</table>`;
  const html = `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;color:#111">
    <div dir="rtl" style="text-align:right">${ar}${table({ n: "الاسم", e: "البريد", t: "نوع الحساب", o: "المالك", m: "عضو", d: "تاريخ التسجيل" })}</div>
    <hr style="border:none;border-top:1px solid #ddd;margin:18px 0">
    <div dir="ltr" style="text-align:left">${en}${table({ n: "Name", e: "Email", t: "Account type", o: "Owner", m: "Member", d: "Registered" })}</div></div>`;
  return { subject: owner ? "Aura Glass — أنت المالك / You are the Owner" : "Aura Glass — تم إنشاء حسابك / Your account is ready", html };
}

/** Sends the welcome email once per account. The row is "claimed" first so two parallel requests cannot send it twice; a failure releases the claim. */
async function sendWelcomeOnce(env, user) {
  if (user.welcome_sent || !mailConfigured(env)) return;
  const claim = await env.DB.prepare("UPDATE users SET welcome_sent = 2 WHERE sub = ?1 AND welcome_sent = 0").bind(user.sub).run();
  if (!claim.meta || claim.meta.changes !== 1) return;
  try {
    const m = welcomeMail(user);
    await sendMail(env, user.email, m.subject, m.html);
    await env.DB.prepare("UPDATE users SET welcome_sent = 1 WHERE sub = ?1").bind(user.sub).run();
  } catch (e) {
    await env.DB.prepare("UPDATE users SET welcome_sent = 0 WHERE sub = ?1").bind(user.sub).run();   // retried at the next sign-in
  }
}

/** Tells the OWNER that a new account registered. Contains the account NAME only (no email, no date, no other data). Sent once per account. */
async function notifyOwnerOnce(env, user) {
  if (user.owner_notified) return;
  if (user.role === "owner") {                                   // the owner does not get a notice about themselves
    await env.DB.prepare("UPDATE users SET owner_notified = 1 WHERE sub = ?1").bind(user.sub).run();
    return;
  }
  if (!mailConfigured(env)) return;                              // retried later once Gmail is configured
  const claim = await env.DB.prepare("UPDATE users SET owner_notified = 2 WHERE sub = ?1 AND owner_notified = 0").bind(user.sub).run();
  if (!claim.meta || claim.meta.changes !== 1) return;
  try {
    const owner = await env.DB.prepare("SELECT email FROM users WHERE role = 'owner' LIMIT 1").first();
    if (!owner) throw new Error("no owner yet");                 // OWNER_EMAIL mode before the owner has signed in: retried next time
    const n = (user.name || "").trim();
    const ar = esc(n || "مستخدم جديد"), en = esc(n || "a new user");
    await sendMail(env, owner.email, "Aura Glass — تسجيل جديد / New sign-in",
      `<div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;color:#111">
        <p dir="rtl" style="text-align:right">قام <b>${ar}</b> بتسجيل الدخول في تطبيق Aura Glass.</p>
        <p dir="ltr" style="text-align:left"><b>${en}</b> signed in to the Aura Glass app.</p></div>`);
    await env.DB.prepare("UPDATE users SET owner_notified = 1 WHERE sub = ?1").bind(user.sub).run();
  } catch (e) {
    await env.DB.prepare("UPDATE users SET owner_notified = 0 WHERE sub = ?1").bind(user.sub).run();
  }
}

async function callProvider(provider, msgs, env) {
  const started = Date.now();
  if (provider === "gemini") {
    if (!env.GEMINI_API_KEY) return { error: "GEMINI_API_KEY is not set on the backend" };
    const model = env.GEMINI_MODEL || "gemini-1.5-flash";
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: "POST", headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: SYSTEM }] }, contents: msgs.map(m => ({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content }] })) }),
    });
    if (r.status === 429) return { status: 429, error: "Gemini rate limit / quota reached" };
    if (!r.ok) return { status: 502, error: "Gemini error " + r.status + ": " + (await r.text()).slice(0, 200) };
    const j = await r.json();
    return { text: j.candidates?.[0]?.content?.parts?.map(p => p.text).join("") || "", model, latencyMs: Date.now() - started };
  }
  if (!env.OPENAI_API_KEY) return { error: "OPENAI_API_KEY is not set on the backend" };
  const model = env.OPENAI_MODEL || "gpt-4o-mini";
  const r = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + env.OPENAI_API_KEY },
    body: JSON.stringify({ model, messages: [{ role: "system", content: SYSTEM }, ...msgs.map(m => ({ role: m.role, content: m.content }))] }),
  });
  if (r.status === 429) return { status: 429, error: "OpenAI rate limit / quota reached" };
  if (!r.ok) return { status: 502, error: "OpenAI error " + r.status + ": " + (await r.text()).slice(0, 200) };
  const j = await r.json();
  return { text: j.choices?.[0]?.message?.content || "", model, latencyMs: Date.now() - started };
}

export default {
  async fetch(req, env, ctx) {
    const url = new URL(req.url);
    const who = await identify(req, env);
    if (!who.ok) return json({ error: "Unauthorized (configure GOOGLE_WEB_CLIENT_ID, or ALLOW_ANON=true for testing)" }, 401);

    if (url.pathname === "/me") {
      if (who.sub === "anon") return json({ role: "user" });
      if (!who.verified || !who.email) return json({ error: "Google account email is not verified" }, 403);
      try {
        const user = await registerOrLogin(env, who);
        ctx.waitUntil(Promise.all([sendWelcomeOnce(env, user), notifyOwnerOnce(env, user)]).catch(() => {}));
        return json({ role: user.role === "owner" ? "owner" : "user", email: user.email, name: user.name, registeredAt: user.created_at });
      } catch (e) { return json({ error: "Account database error: " + String(e.message || e).slice(0, 160) }, 503); }
    }

    if (url.pathname.startsWith("/admin/")) {          // owner only: the role is read from the database for every call
      let me;
      try { await ensureSchema(env); me = await env.DB.prepare("SELECT sub, email, role FROM users WHERE sub = ?1").bind(who.sub).first(); }
      catch (e) { return json({ error: "Account database error" }, 503); }
      if (!me || me.role !== "owner") return json({ error: "Forbidden" }, 403);
      if (url.pathname === "/admin/users" && req.method === "GET") {
        const rows = await env.DB.prepare("SELECT name, email, role, created_at, last_login_at FROM users ORDER BY created_at ASC LIMIT 500").all();
        const list = (rows.results || []).map(u => ({ name: u.name, email: u.email, role: u.role, createdAt: u.created_at, lastLoginAt: u.last_login_at }));
        return json({ total: list.length, emailConfigured: mailConfigured(env), users: list });
      }
      if (url.pathname === "/admin/test-email" && req.method === "POST") {
        try {
          await sendMail(env, me.email, "Aura Glass — اختبار البريد / Email test",
            '<div style="font-family:Arial,sans-serif"><p dir="rtl">هذه رسالة اختبار: إرسال البريد عبر Gmail يعمل.</p><p>This is a test message: sending through Gmail works.</p></div>');
          return json({ ok: true });
        } catch (e) { return json({ ok: false, error: String(e.message || e).slice(0, 200) }); }
      }
      return json({ error: "not found" }, 404);
    }

    if (url.pathname === "/health") {
      const provider = url.searchParams.get("provider") === "gemini" ? "gemini" : "gpt";
      const r = await callProvider(provider, [{ role: "user", content: "Reply with the single word: ok" }], env);
      if (r.error || !r.text) return json({ ok: false, provider, error: r.error || "empty response from provider" });
      return json({ ok: true, provider, model: r.model, latencyMs: r.latencyMs });
    }

    if (url.pathname === "/chat" && req.method === "POST") {
      let body; try { body = await req.json(); } catch { return json({ error: "bad json" }, 400); }
      const msgs = (body.messages || []).slice(-20).filter(m => (m.role === "user" || m.role === "assistant") && typeof m.content === "string").map(m => ({ role: m.role, content: m.content.slice(0, 4000) }));
      if (!msgs.length) return json({ error: "no messages" }, 400);
      const r = await callProvider(body.provider === "gemini" ? "gemini" : "gpt", msgs, env);
      if (r.error) return json({ error: r.error }, r.status || 503);
      const m = r.text.match(/^SEARCH:\s*(.+)$/m);
      return json({ reply: r.text.replace(/^SEARCH:.*$/m, "").trim(), search: m ? m[1].trim() : undefined });
    }

    if (url.pathname === "/wallpapers" && req.method === "GET") {
      if (!env.PEXELS_API_KEY) return json({ error: "PEXELS_API_KEY is not set on the backend" }, 503);
      const q = (url.searchParams.get("q") || "wallpaper").slice(0, 80);
      const page = Math.max(1, parseInt(url.searchParams.get("page") || "1", 10));
      const r = await fetch(`https://api.pexels.com/v1/search?query=${encodeURIComponent(q)}&orientation=portrait&per_page=30&page=${page}`, { headers: { Authorization: env.PEXELS_API_KEY }, cf: { cacheTtl: 3600, cacheEverything: true } });
      if (r.status === 429) return json({ error: "Pexels rate limit" }, 429);
      if (!r.ok) return json({ error: "Pexels error " + r.status }, 502);
      const j = await r.json();
      const items = (j.photos || []).map(p => ({ id: String(p.id), title: (p.alt || "Photo " + p.id).slice(0, 80), thumb: p.src.portrait,
        full: p.src.portrait.replace(/h=\d+/, "h=1920").replace(/w=\d+/, "w=1080"), creator: p.photographer, license: "Pexels License",
        licenseUrl: "https://www.pexels.com/license/", sourceUrl: p.url, width: 1080, height: 1920, tags: [] }));
      return json({ items, next: j.next_page ? String(page + 1) : "" });
    }
    return json({ error: "not found" }, 404);
  },
};
