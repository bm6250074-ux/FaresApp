# Backend: saved accounts, owner role, welcome emails (Cloudflare Worker + D1 + Gmail)

## 1. Worker
dash.cloudflare.com > Workers & Pages > Create > Create Worker > Deploy > Edit code > paste `worker.js` > Deploy.

## 2. Database for the accounts (required)
1. Storage & Databases > D1 > Create database (any name, e.g. `aura-db`).
2. Worker > Settings > Bindings > Add > **D1 database** > variable name **`DB`** > choose that database.
The table is created automatically on the first sign-in. Accounts live in D1, so they survive redeploys and app updates.

## 3. Variables
Worker > Settings > Variables and secrets:
- `GOOGLE_WEB_CLIENT_ID` = your Google *Web* OAuth client ID (same value as the GitHub variable).
- `OWNER_EMAIL` (optional). Empty = **the first account that ever signs in becomes the owner**. Set = only that email can become owner.

## 4. Who becomes owner
- The role is decided once, by the database, when an account is first stored. It is never changed afterwards, no app request can set it,
  and the database refuses a second owner. A normal member cannot become owner.
- **Sign in yourself first** right after deploying (before sharing the APK), or set `OWNER_EMAIL`, otherwise whoever signs in first is the owner.
- To start over (wrong account became owner): D1 > your database > Console > `DELETE FROM users;`

## 5. Emails through Gmail (optional but needed for the welcome messages)
The app cannot send mail by itself; the Worker sends it through the Gmail API from one Gmail account you choose.
1. console.cloud.google.com > APIs & Services > Library > enable **Gmail API**.
2. OAuth consent screen: set Publishing status to **In production**. (In "Testing" the refresh token expires after 7 days and emails stop.)
3. Credentials > Create OAuth client ID > Web application > Authorized redirect URI `https://developers.google.com/oauthplayground`.
4. developers.google.com/oauthplayground > gear icon > tick "Use your own OAuth credentials" > enter the client ID and secret.
   Step 1: type the scope `https://www.googleapis.com/auth/gmail.send` > Authorize APIs with the Gmail account that will send the mail.
   Step 2: Exchange authorization code for tokens > copy the **Refresh token**.
5. Worker secrets: `GMAIL_CLIENT_ID`, `GMAIL_CLIENT_SECRET`, `GMAIL_REFRESH_TOKEN`. Worker variable: `GMAIL_SENDER` = that Gmail address.
What is sent: on the first sign-in each person gets an email (Arabic + English) with their name, email, account type and date; the owner gets the
"you are the owner" version. Also, every time a NEW account registers, the owner gets a short email saying that "<account name> signed in to the Aura Glass app" (the name only: no email address, no date, nothing else). The owner is not notified about their own account. If sending fails, sign-in still works and the email is retried at the next sign-in. Personal Gmail accounts have a daily sending limit (about 500).
Check it in the app: Profile > Owner Settings > Developer options > "Send a test email to me".

## 6. App build
GitHub repo > Settings > Secrets and variables > Actions > Variables: `AURA_BACKEND_URL` (worker URL, no trailing slash) and `GOOGLE_WEB_CLIENT_ID`; plus the signing-key secrets from README.
Without `AURA_BACKEND_URL` accounts cannot be saved or roles assigned.

## Other optional settings
Secrets `OPENAI_API_KEY`, `GEMINI_API_KEY`, `PEXELS_API_KEY`; `ALLOW_ANON=true` is for quick tests only.
Not implemented on the server yet: purchases/Premium, community uploads, automated moderation, video sources.
